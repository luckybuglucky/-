import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import {
  classifyClear,
  COMMAND_HELP,
  isAdminCommand,
  KICK_SECONDS,
  MAX_CALL_LENGTH,
  MAX_WHISPER_LENGTH,
  nicknameCandidates,
  parseCommand,
  parseSeconds,
  parseTier,
  PLAYER_HELP,
  splitGive,
  splitNickArg,
} from "./commands";
import { ALL_COLOR_IDS, CHAMPION_TITLE, colorLabel, GIVE_ALL_TITLES } from "./cosmetics";
import { activeGameOf, finishGame, grantItems, grantTitle, syncChampion, type Admin } from "./engine";
import { censor } from "./profanity";
import { PLACEMENT_GAMES, rankFromRating } from "./rank";

const NICK_RE = /^[가-힣a-zA-Z0-9_]{2,12}$/;

export type CommandAction = { type: "spectate"; gameId: string } | { type: "hide" };
export type CommandResult = { ok: boolean; message: string; action?: CommandAction };

type Target = { id: string; nickname: string; bp: number; shields: number; rating: number; placement_games: number; mmr: number; equipped_title: string | null; equipped_color: string | null };
const TARGET_COLS = "id, nickname, bp, shields, rating, placement_games, mmr, equipped_title, equipped_color";

async function admin(): Promise<Admin> {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  return supabaseAdmin;
}

/** Profiles whose nickname could be the start of the payload, keyed by lowercase nickname. */
async function lookup(db: Admin, payload: string) {
  const cands = nicknameCandidates(payload).filter((c) => NICK_RE.test(c));
  if (!cands.length) return new Map<string, Target>();
  const { data } = await db
    .from("profiles")
    .select(TARGET_COLS)
    .or(cands.map((c) => `nickname.ilike.${c}`).join(","));
  return new Map((data ?? []).map((p) => [p.nickname.toLowerCase(), p as Target]));
}

async function byNickname(db: Admin, nickname: string): Promise<Target | null> {
  if (!NICK_RE.test(nickname)) return null;
  const { data } = await db.from("profiles").select(TARGET_COLS).ilike("nickname", nickname).maybeSingle();
  return (data as Target | null) ?? null;
}

async function hasRole(db: Admin, userId: string, role: "admin" | "developer") {
  const { data } = await db.from("user_roles").select("id").eq("user_id", userId).eq("role", role).maybeSingle();
  return !!data;
}

const fail = (message: string): CommandResult => ({ ok: false, message });
const done = (message: string, action?: CommandAction): CommandResult => (action ? { ok: true, message, action } : { ok: true, message });

export const runCommand = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ command: z.string().min(1).max(300) }).parse(input))
  .handler(async ({ data, context }): Promise<CommandResult> => {
    const parsed = parseCommand(data.command);
    const me = context.userId;
    const { data: isAdmin } = await context.supabase.rpc("has_role", { _user_id: me, _role: "admin" });

    if (parsed.cmd === "help") return done((isAdmin ? COMMAND_HELP : PLAYER_HELP).join("\n"));
    if (parsed.cmd === "unknown") return fail(`알 수 없는 명령어입니다: ${parsed.name}  (/help 참고)`);
    if (isAdminCommand(parsed) && !isAdmin) return fail("관리자가 아닙니다.");

    const db = await admin();
    const { data: self } = await db.from("profiles").select("nickname, muted_until").eq("id", me).single();
    const myNick = self?.nickname ?? "관리자";

    // ---- whisper (everyone) ----
    if (parsed.cmd === "whisper") {
      if (self?.muted_until && new Date(self.muted_until).getTime() > Date.now()) return fail("채팅 금지 중에는 귓속말을 보낼 수 없습니다.");
      const found = await lookup(db, parsed.payload);
      const split = splitNickArg(parsed.payload, (n) => found.has(n.toLowerCase()), (s) => (s ? s : null));
      if (!split) return fail("사용법: /귓속말닉네임 내용");
      const target = found.get(split.nickname.toLowerCase())!;
      if (target.id === me) return fail("자기 자신에게는 귓속말을 보낼 수 없습니다.");
      const text = censor(split.arg.slice(0, MAX_WHISPER_LENGTH)).text;
      await db.from("notices").insert({ kind: "whisper", from_id: me, from_nickname: myNick, to_id: target.id, to_nickname: target.nickname, content: text });
      return done(`→ ${target.nickname}: ${text}`);
    }

    // ---- admin: no target ----
    if (parsed.cmd === "list") {
      const [{ data: rows, count }, { data: admins }] = await Promise.all([
        db.from("profiles").select("id, nickname, rating, placement_games, bp", { count: "exact" }).order("created_at").limit(500),
        db.from("user_roles").select("user_id").eq("role", "admin"),
      ]);
      const adminIds = new Set((admins ?? []).map((a) => a.user_id));
      const lines = (rows ?? []).map((r, i) => {
        const tier = r.placement_games >= PLACEMENT_GAMES ? rankFromRating(r.rating).label : "언랭";
        return `${i + 1}. ${r.nickname} · ${tier} · ${r.bp} BP${adminIds.has(r.id) ? " · 관리자" : ""}`;
      });
      return done([`가입한 계정 ${count ?? lines.length}개`, ...lines].join("\n"));
    }
    if (parsed.cmd === "call") {
      const text = parsed.text.slice(0, MAX_CALL_LENGTH);
      if (!text) return fail("사용법: /call내용");
      await db.from("notices").insert({ kind: "call", from_id: me, from_nickname: myNick, content: text });
      return done(`공지를 보냈습니다: ${text}`);
    }
    if (parsed.cmd === "hide") return done("관전을 종료했습니다.", { type: "hide" });

    // ---- admin: nickname only ----
    if (parsed.cmd === "op" || parsed.cmd === "unop" || parsed.cmd === "del" || parsed.cmd === "show" || parsed.cmd === "kick") {
      const target = await byNickname(db, parsed.nickname);
      if (!target) return fail("해당 닉네임의 플레이어를 찾을 수 없습니다.");
      const protectedTarget = target.id === me || (await hasRole(db, target.id, "developer"));

      if (parsed.cmd === "op") {
        await db.from("user_roles").upsert({ user_id: target.id, role: "admin" }, { onConflict: "user_id,role", ignoreDuplicates: true });
        return done(`${target.nickname}님에게 관리자 권한을 부여했습니다.`);
      }
      if (parsed.cmd === "unop") {
        if (protectedTarget) return fail("자신 또는 개발자의 관리자 권한은 박탈할 수 없습니다.");
        await db.from("user_roles").delete().eq("user_id", target.id).eq("role", "admin");
        return done(`${target.nickname}님의 관리자 권한을 박탈했습니다.`);
      }
      if (parsed.cmd === "show") {
        const game = await activeGameOf(db, target.id);
        if (!game) return fail(`${target.nickname}님은 대국 중이 아닙니다.`);
        return done(`${target.nickname}님의 대국을 관전합니다.`, { type: "spectate", gameId: game.id });
      }
      if (parsed.cmd === "kick") {
        if (protectedTarget) return fail("자신 또는 개발자는 추방할 수 없습니다.");
        await db.from("profiles").update({ kicked_until: new Date(Date.now() + KICK_SECONDS * 1000).toISOString() }).eq("id", target.id);
        await db.auth.admin.updateUserById(target.id, { ban_duration: `${KICK_SECONDS}s` });
        await db.from("notices").insert({ kind: "kick", from_id: me, from_nickname: myNick, to_id: target.id, to_nickname: target.nickname });
        return done(`${target.nickname}님을 ${KICK_SECONDS}초간 추방했습니다.`);
      }
      // del
      if (protectedTarget) return fail("자신 또는 개발자의 계정은 삭제할 수 없습니다.");
      const game = await activeGameOf(db, target.id);
      if (game) await finishGame(db, game, game.black_id === target.id ? 2 : 1, "leave", { leaverId: target.id });
      await db.from("match_queue").delete().eq("user_id", target.id);
      const { error } = await db.auth.admin.deleteUser(target.id);
      if (error) return fail("계정을 삭제하지 못했습니다.");
      await syncChampion(db);
      return done(`${target.nickname}님의 계정을 삭제했습니다.`);
    }

    // ---- admin: nickname + argument ----
    const found = await lookup(db, parsed.payload);
    const isNick = (n: string) => found.has(n.toLowerCase());
    const get = (n: string) => found.get(n.toLowerCase())!;

    if (parsed.cmd === "give") {
      const split = splitGive(parsed.payload, isNick);
      if (!split) return fail("닉네임 또는 지급 항목을 인식하지 못했습니다. (/help 참고)");
      const t = get(split.nickname);
      const item = split.item;
      if (item.kind === "all") {
        await grantItems(db, t.id, GIVE_ALL_TITLES, ALL_COLOR_IDS);
        return done(`${t.nickname}님에게 모든 칭호와 닉네임 색상을 지급했습니다.`);
      }
      if (item.kind === "bp") {
        await db.from("profiles").update({ bp: t.bp + item.amount }).eq("id", t.id);
        return done(`${t.nickname}님에게 ${item.amount} BP를 지급했습니다.`);
      }
      if (item.kind === "shield") {
        await db.from("profiles").update({ shields: t.shields + item.count }).eq("id", t.id);
        return done(`${t.nickname}님에게 강등 방어권 ${item.count}개를 지급했습니다.`);
      }
      if (item.kind === "color") {
        await db.from("profile_colors").upsert({ user_id: t.id, color: item.color }, { onConflict: "user_id,color", ignoreDuplicates: true });
        return done(`${t.nickname}님에게 '${colorLabel(item.color)}' 닉네임 색상을 지급했습니다.`);
      }
      const added = await grantTitle(db, t.id, item.title);
      return done(added ? `${t.nickname}님에게 '${item.title}' 칭호를 지급했습니다.` : `${t.nickname}님은 이미 '${item.title}' 칭호를 보유하고 있습니다.`);
    }

    if (parsed.cmd === "clear") {
      const whole = parsed.payload.replace(/[()\s]/g, "");
      const split = isNick(whole) ? { nickname: whole, arg: { kind: "all" as const } } : splitNickArg(parsed.payload, isNick, classifyClear);
      if (!split) return fail("사용법: /clear닉네임아이템");
      const t = get(split.nickname);
      const it = split.arg;
      if (it.kind === "all") {
        await Promise.all([
          db.from("profile_titles").delete().eq("user_id", t.id),
          db.from("profile_colors").delete().eq("user_id", t.id),
          db.from("profiles").update({ shields: 0, equipped_title: null, equipped_color: null }).eq("id", t.id),
        ]);
        await syncChampion(db);
        return done(`${t.nickname}님의 칭호, 닉네임 색상, 방어권을 모두 제거했습니다.`);
      }
      if (it.kind === "shield") {
        await db.from("profiles").update({ shields: 0 }).eq("id", t.id);
        return done(`${t.nickname}님의 강등 방어권을 모두 제거했습니다.`);
      }
      if (it.kind === "bp") {
        await db.from("profiles").update({ bp: 0 }).eq("id", t.id);
        return done(`${t.nickname}님의 BP를 0으로 만들었습니다.`);
      }
      if (it.kind === "color") {
        await db.from("profile_colors").delete().eq("user_id", t.id).eq("color", it.color);
        if (t.equipped_color === it.color) await db.from("profiles").update({ equipped_color: null }).eq("id", t.id);
        return done(`${t.nickname}님의 '${colorLabel(it.color)}' 색상을 제거했습니다.`);
      }
      const { data: gone } = await db.from("profile_titles").delete().eq("user_id", t.id).eq("title", it.title).select("title");
      if (!gone?.length) return fail(`${t.nickname}님은 '${it.title}' 칭호가 없습니다.`);
      if (t.equipped_title === it.title) await db.from("profiles").update({ equipped_title: null }).eq("id", t.id);
      return done(`${t.nickname}님의 '${it.title}' 칭호를 제거했습니다.`);
    }

    if (parsed.cmd === "tier") {
      const split = splitNickArg(parsed.payload, isNick, parseTier);
      if (!split) return fail("사용법: /tier닉네임티어 (예: /tier러키골드2)");
      const t = get(split.nickname);
      await db
        .from("profiles")
        .update({ rating: split.arg.rating, placement_games: Math.max(PLACEMENT_GAMES, t.placement_games), mmr: Math.max(t.mmr, split.arg.rating) })
        .eq("id", t.id);
      await syncChampion(db);
      return done(`${t.nickname}님을 ${split.arg.label}(으)로 배정했습니다.`);
    }

    if (parsed.cmd === "untier") {
      const whole = parsed.payload.replace(/[()\s]/g, "");
      const split = isNick(whole) ? { nickname: whole } : splitNickArg(parsed.payload, isNick, (s) => s);
      if (!split) return fail("사용법: /untier닉네임");
      const t = get(split.nickname);
      await db.from("profiles").update({ rating: 0, placement_games: 0, placement_score: 0, placement_perfect: true }).eq("id", t.id);
      await syncChampion(db);
      return done(`${t.nickname}님의 티어를 박탈했습니다. (언랭)`);
    }

    // stop
    const split = splitNickArg(parsed.payload, isNick, parseSeconds);
    if (!split) return fail("사용법: /stop닉네임초 (1~600초)");
    const t = get(split.nickname);
    const game = await activeGameOf(db, t.id);
    if (!game) return fail(`${t.nickname}님은 대국 중이 아닙니다.`);
    if (game.vs_ai === false && !game.black_id) return fail("대국을 찾을 수 없습니다.");
    const now = Date.now();
    const base = game.paused_until && new Date(game.paused_until).getTime() > now ? new Date(game.paused_until).getTime() : now;
    const ms = split.arg * 1000;
    await db
      .from("games")
      .update({
        paused_until: new Date(base + ms).toISOString(),
        turn_started_at: new Date(new Date(game.turn_started_at).getTime() + ms).toISOString(),
      })
      .eq("id", game.id)
      .eq("status", "active");
    await db.from("game_messages").insert({ game_id: game.id, user_id: me, content: `관리자가 대국을 ${split.arg}초간 일시정지했습니다.`, censored: false });
    return done(`${t.nickname}님의 대국을 ${split.arg}초간 일시정지했습니다.`);
  });

export { CHAMPION_TITLE };
