// Server-side game resolution. Pure logic + a passed-in privileged client; no
// server-only imports here so it is safe to be referenced from server functions.
import type { SupabaseClient } from "@supabase/supabase-js";

import type { Database } from "@/integrations/supabase/types";
import { stonesPlayed, type Color, type FoulKind } from "./rules";
import {
  AI_MMR,
  aiRewardScale,
  applyRatingChange,
  gapMultipliers,
  isPerfectPlacementGame,
  LEAVE_PENALTY,
  mmrChange,
  PLACEMENT_GAMES,
  performanceScore,
  placementRating,
  rankedLossRp,
  rankedWinRp,
  winReward,
} from "./rank";
import {
  ALL_COLOR_IDS,
  CHAMPION_TITLE,
  DEVELOPER_TITLES,
  LOSS_STREAK_FOR_TITLE,
  LOSS_STREAK_TITLE,
  WIN_STREAK_FOR_TITLE,
  WIN_STREAK_TITLE,
} from "./cosmetics";

export type Admin = SupabaseClient<Database>;
export type GameRow = Database["public"]["Tables"]["games"]["Row"];
export type ProfileRow = Database["public"]["Tables"]["profiles"]["Row"];

export type EndReason = "five" | "foul" | "timeout" | "leave" | "draw";

export type PlayerResult = {
  userId: string;
  won: boolean;
  draw: boolean;
  left: boolean;
  stones: number;
  perf: number;
  rpDelta: number;
  bp: number;
  jackpot?: boolean;
  shieldUsed: boolean;
  ratingBefore: number;
  ratingAfter: number;
  placementPlayed: number;
  placedNow: boolean;
  ranked: boolean;
  friendly: boolean;
  newTitles: string[];
};

export type GameResult = {
  black?: PlayerResult;
  white?: PlayerResult;
  foul?: FoulKind;
};

export async function grantTitle(admin: Admin, userId: string, title: string) {
  const { data } = await admin
    .from("profile_titles")
    .upsert({ user_id: userId, title }, { onConflict: "user_id,title", ignoreDuplicates: true })
    .select("title");
  return (data ?? []).length > 0;
}

export async function activeGameOf(admin: Admin, userId: string) {
  const { data } = await admin
    .from("games")
    .select("*")
    .eq("status", "active")
    .or(`black_id.eq.${userId},white_id.eq.${userId}`)
    .order("created_at", { ascending: false })
    .limit(1);
  return data?.[0] ?? null;
}

async function developerIds(admin: Admin) {
  const { data } = await admin.from("user_roles").select("user_id").eq("role", "developer");
  return (data ?? []).map((r) => r.user_id);
}

/** Gives 챔피언 to the current #1 and removes it from everyone else (developers keep it). */
export async function syncChampion(admin: Admin) {
  const { data: top } = await admin
    .from("profiles")
    .select("id")
    .gte("placement_games", PLACEMENT_GAMES)
    .order("rating", { ascending: false })
    .order("created_at", { ascending: true })
    .limit(1);
  const topId = top?.[0]?.id ?? null;
  const keep = new Set([...(await developerIds(admin)), ...(topId ? [topId] : [])]);
  const { data: holders } = await admin.from("profile_titles").select("user_id").eq("title", CHAMPION_TITLE);
  const remove = (holders ?? []).map((h) => h.user_id).filter((id) => !keep.has(id));
  if (remove.length) {
    await admin.from("profile_titles").delete().eq("title", CHAMPION_TITLE).in("user_id", remove);
    await admin.from("profiles").update({ equipped_title: null }).eq("equipped_title", CHAMPION_TITLE).in("id", remove);
  }
  if (topId) await grantTitle(admin, topId, CHAMPION_TITLE);
}

/** Grants every title and color the user doesn't own yet. */
export async function grantItems(admin: Admin, userId: string, titles: string[], colors: string[]) {
  await Promise.all([
    titles.length
      ? admin.from("profile_titles").upsert(titles.map((title) => ({ user_id: userId, title })), { onConflict: "user_id,title", ignoreDuplicates: true })
      : null,
    colors.length
      ? admin.from("profile_colors").upsert(colors.map((color) => ({ user_id: userId, color })), { onConflict: "user_id,color", ignoreDuplicates: true })
      : null,
  ]);
}

/** The developer account owns every item; tops up when new items are added. */
export async function ensureDeveloperItems(admin: Admin, userId: string) {
  const [{ count: t }, { count: c }] = await Promise.all([
    admin.from("profile_titles").select("title", { count: "exact", head: true }).eq("user_id", userId),
    admin.from("profile_colors").select("color", { count: "exact", head: true }).eq("user_id", userId),
  ]);
  if ((t ?? 0) < DEVELOPER_TITLES.length || (c ?? 0) < ALL_COLOR_IDS.length) {
    await grantItems(admin, userId, DEVELOPER_TITLES, ALL_COLOR_IDS);
  }
}

export async function finishGame(
  admin: Admin,
  game: GameRow,
  winner: Color | null,
  reason: EndReason,
  opts: { leaverId?: string; foul?: FoulKind; moveCount?: number } = {},
) {
  const { data: claimed } = await admin
    .from("games")
    .update({
      status: "finished",
      winner: winner === 1 ? "black" : winner === 2 ? "white" : null,
      end_reason: reason,
      finished_at: new Date().toISOString(),
    })
    .eq("id", game.id)
    .eq("status", "active")
    .select("id")
    .maybeSingle();
  if (!claimed) return;

  const moveCount = opts.moveCount ?? game.move_count;
  const result: GameResult = {};
  if (opts.foul) result.foul = opts.foul;

  const ids = [game.black_id, game.white_id].filter(Boolean) as string[];
  const { data: profiles } = await admin.from("profiles").select("*").in("id", ids);
  const byId = new Map((profiles ?? []).map((p) => [p.id, p]));

  for (const color of [1, 2] as Color[]) {
    const userId = color === 1 ? game.black_id : game.white_id;
    if (!userId) continue;
    const p = byId.get(userId);
    if (!p) continue;
    const oppId = color === 1 ? game.white_id : game.black_id;
    const opp = oppId ? byId.get(oppId) ?? null : null;

    const draw = winner === null;
    const won = winner === color;
    const left = opts.leaverId === userId;
    const stones = stonesPlayed(moveCount, color);
    const aiScale = game.vs_ai ? aiRewardScale(game.ai_level) : 1;
    const rawPerf = draw ? 50 : performanceScore(won, stones, left);
    const perf = won ? Math.round(rawPerf * aiScale) : rawPerf;
    const friendly = game.friendly;
    // Friendly matches count exactly like the mode they were created with.
    const ranked = game.mode === "ranked";

    const base: PlayerResult = {
      userId,
      won,
      draw,
      left,
      stones,
      perf,
      rpDelta: 0,
      bp: 0,
      shieldUsed: false,
      ratingBefore: p.rating,
      ratingAfter: p.rating,
      placementPlayed: p.placement_games,
      placedNow: false,
      ranked,
      friendly,
      newTitles: [],
    };

    const reward = won ? winReward(game.vs_ai ? game.ai_level ?? "normal" : null) : { bp: 0, jackpot: false };
    const bp = reward.bp;
    const placed = p.placement_games >= PLACEMENT_GAMES;

    let rating = p.rating;
    let shields = p.shields;
    let shieldUsed = false;
    let placementPlayed = p.placement_games;
    let placementScore = p.placement_score;
    let placementPerfect = p.placement_perfect;
    let placedNow = false;

    if (ranked && !draw) {
      if (!placed) {
        placementPlayed += 1;
        placementScore += perf;
        placementPerfect = placementPerfect && aiScale === 1 && isPerfectPlacementGame(won, moveCount);
        if (placementPlayed >= PLACEMENT_GAMES) {
          rating = placementRating(placementScore, PLACEMENT_GAMES, placementPerfect);
          placedNow = true;
        }
      } else {
        const gap =
          opp && opp.placement_games >= PLACEMENT_GAMES ? gapMultipliers(p.rating, opp.rating) : { win: 1, loss: 1 };
        let delta = won ? Math.max(1, Math.round(rankedWinRp(perf) * gap.win * aiScale)) : -Math.round(rankedLossRp(stones) * gap.loss);
        if (left) delta -= LEAVE_PENALTY;
        const applied = applyRatingChange(rating, delta, shields);
        rating = applied.rating;
        shields = applied.shields;
        shieldUsed = applied.shieldUsed;
      }
    } else if (left && placed) {
      const applied = applyRatingChange(rating, -LEAVE_PENALTY, shields);
      rating = applied.rating;
      shields = applied.shields;
      shieldUsed = applied.shieldUsed;
    }

    // Streaks + hidden MMR
    const winStreak = draw ? 0 : won ? p.win_streak + 1 : 0;
    const lossStreak = draw ? 0 : won ? 0 : p.loss_streak + 1;
    const oppMmr = game.vs_ai ? AI_MMR[game.ai_level ?? "normal"] ?? 700 : opp?.mmr ?? p.mmr;
    let mmr = draw ? p.mmr : Math.max(0, p.mmr + mmrChange(p.mmr, oppMmr, won, winStreak));
    if (placedNow) mmr = Math.max(mmr, rating);

    await admin
      .from("profiles")
      .update({
        rating,
        shields,
        bp: p.bp + bp,
        mmr,
        win_streak: winStreak,
        loss_streak: lossStreak,
        placement_games: placementPlayed,
        placement_score: placementScore,
        placement_perfect: placementPerfect,
        wins: p.wins + (won ? 1 : 0),
        losses: p.losses + (!won && !draw ? 1 : 0),
        ranked_wins: p.ranked_wins + (ranked && won ? 1 : 0),
        ranked_losses: p.ranked_losses + (ranked && !won && !draw ? 1 : 0),
      })
      .eq("id", userId);

    const newTitles: string[] = [];
    if (winStreak >= WIN_STREAK_FOR_TITLE && (await grantTitle(admin, userId, WIN_STREAK_TITLE))) newTitles.push(WIN_STREAK_TITLE);
    if (lossStreak >= LOSS_STREAK_FOR_TITLE && (await grantTitle(admin, userId, LOSS_STREAK_TITLE))) newTitles.push(LOSS_STREAK_TITLE);

    result[color === 1 ? "black" : "white"] = {
      ...base,
      rpDelta: placedNow ? 0 : rating - p.rating,
      bp,
      jackpot: reward.jackpot,
      shieldUsed,
      ratingAfter: rating,
      placementPlayed,
      placedNow,
      newTitles,
    };
  }

  await admin.from("games").update({ result: result as never }).eq("id", game.id);
  if (game.mode === "ranked") await syncChampion(admin);
}
