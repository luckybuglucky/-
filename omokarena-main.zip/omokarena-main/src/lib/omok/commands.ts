// Console command parsing. Pure: nickname lookup is injected.
import { CHAMPION_TITLE, findColor, findTitle, MAX_TITLE_LENGTH } from "./cosmetics";
import { divisionStart, TIER_LABEL, TIERS, type Tier } from "./rank";

export type GiveItem =
  | { kind: "bp"; amount: number }
  | { kind: "shield"; count: number }
  | { kind: "color"; color: string }
  | { kind: "title"; title: string }
  | { kind: "all" };

export type ClearItem = { kind: "all" } | { kind: "shield" } | { kind: "bp" } | { kind: "color"; color: string } | { kind: "title"; title: string };

export const MAX_GIVE_BP = 100_000;
export const MAX_STOP_SECONDS = 600;
export const KICK_SECONDS = 10;
export const MAX_CALL_LENGTH = 100;
export const MAX_WHISPER_LENGTH = 200;

const SHIELD_WORDS = ["방어권", "강등방어권", "강등 방어권"];
const ALL_WORDS = ["all", "전체", "모두", "아이템", "전부"];

export function classifyItem(raw: string): GiveItem | null {
  const s = raw.trim();
  if (!s) return null;
  if (ALL_WORDS.includes(s.toLowerCase())) return { kind: "all" };
  if (/^\d+$/.test(s)) {
    const amount = Number(s);
    if (amount < 1 || amount > MAX_GIVE_BP) return null;
    return { kind: "bp", amount };
  }
  if (SHIELD_WORDS.includes(s)) return { kind: "shield", count: 1 };
  const color = findColor(s);
  if (color) return { kind: "color", color: color.id };
  const known = findTitle(s);
  if (known) return { kind: "title", title: known.title };
  if (Array.from(s).length > MAX_TITLE_LENGTH || s === CHAMPION_TITLE) return null;
  return { kind: "title", title: s };
}

export function classifyClear(raw: string): ClearItem | null {
  const s = raw.trim();
  if (!s || ALL_WORDS.includes(s.toLowerCase())) return { kind: "all" };
  if (SHIELD_WORDS.includes(s)) return { kind: "shield" };
  if (s.toLowerCase() === "bp") return { kind: "bp" };
  const color = findColor(s);
  if (color) return { kind: "color", color: color.id };
  return { kind: "title", title: findTitle(s)?.title ?? s };
}

const TIER_ALIASES: Record<Tier, string[]> = {
  iron: ["아이언", "iron"],
  bronze: ["브론즈", "bronze"],
  silver: ["실버", "silver"],
  gold: ["골드", "gold"],
  platinum: ["플래티넘", "플레티넘", "플래", "플레", "platinum"],
  diamond: ["다이아몬드", "다이아", "diamond"],
  master: ["마스터", "master"],
  grandmaster: ["그랜드마스터", "그마", "grandmaster"],
  challenger: ["챌린저", "챌", "challenger"],
};

/** "골드2" / "골드 2" / "골드" (= 1단계) -> starting rating of that step. */
export function parseTier(raw: string): { tier: Tier; division: 1 | 2 | 3; rating: number; label: string } | null {
  const m = raw.replace(/\s/g, "").toLowerCase().match(/^(.+?)([123])?(단계)?$/);
  if (!m) return null;
  const tierIndex = TIERS.findIndex((t) => TIER_ALIASES[t].includes(m[1]!));
  if (tierIndex < 0) return null;
  const division = Number(m[2] ?? 1) as 1 | 2 | 3;
  const tier = TIERS[tierIndex]!;
  return { tier, division, rating: divisionStart(tierIndex * 3 + division - 1), label: `${TIER_LABEL[tier]} ${division}` };
}

export function parseSeconds(raw: string): number | null {
  const m = raw.replace(/\s/g, "").match(/^(\d+)(초)?$/);
  if (!m) return null;
  const n = Number(m[1]);
  return n >= 1 && n <= MAX_STOP_SECONDS ? n : null;
}

export type ParsedCommand =
  | { cmd: "help" }
  | { cmd: "list" }
  | { cmd: "call"; text: string }
  | { cmd: "give" | "clear" | "tier" | "untier" | "whisper" | "stop"; payload: string }
  | { cmd: "op" | "unop" | "del" | "show" | "hide" | "kick"; nickname: string }
  | { cmd: "unknown"; name: string };

const NICK_ONLY: [string, "op" | "unop" | "del" | "show" | "hide" | "kick"][] = [
  ["/unop", "unop"],
  ["/op", "op"],
  ["/del", "del"],
  ["/show", "show"],
  ["/hide", "hide"],
  ["/k", "kick"],
];
const WITH_ARG: [string, "give" | "clear" | "tier" | "untier" | "whisper" | "stop"][] = [
  ["/귓속말", "whisper"],
  ["/귓말", "whisper"],
  ["/w", "whisper"],
  ["/untier", "untier"],
  ["/clear", "clear"],
  ["/tier", "tier"],
  ["/give", "give"],
  ["/stop", "stop"],
];

/** Admin-only commands (everything except /귓속말 and /help). */
export function isAdminCommand(p: ParsedCommand) {
  return p.cmd !== "help" && p.cmd !== "whisper" && p.cmd !== "unknown";
}

export function parseCommand(input: string): ParsedCommand {
  const s = input.trim();
  if (s === "/help" || s === "/도움말") return { cmd: "help" };
  if (s === "/A" || s === "/a") return { cmd: "list" };
  if (s.startsWith("/call")) return { cmd: "call", text: unwrap(s.slice(5)) };
  for (const [prefix, cmd] of WITH_ARG) {
    if (s.startsWith(prefix)) return { cmd, payload: s.slice(prefix.length).trim() };
  }
  for (const [prefix, cmd] of NICK_ONLY) {
    if (s.startsWith(prefix)) return { cmd, nickname: s.slice(prefix.length).replace(/[()\s]/g, "") };
  }
  return { cmd: "unknown", name: s.split(/\s/)[0] ?? s };
}

function unwrap(s: string) {
  const t = s.trim();
  const m = t.match(/^\(([\s\S]*)\)$/);
  return (m ? m[1]! : t).trim();
}

/** Candidate nickname prefixes (2-12 chars) of a payload, longest first. */
export function nicknameCandidates(payload: string): string[] {
  const p = payload.trim();
  const out = new Set<string>();
  const paren = p.match(/^\(([^)]+)\)/);
  if (paren) out.add(paren[1]!.trim());
  const first = p.match(/^(\S+)/);
  if (first) out.add(first[1]!.replace(/[()]/g, ""));
  const chars = Array.from(p.replace(/[()]/g, ""));
  for (let i = Math.min(12, chars.length); i >= 2; i--) {
    const c = chars.slice(0, i).join("");
    if (!/\s/.test(c)) out.add(c);
  }
  return [...out].filter((c) => c.length >= 2);
}

/**
 * Splits "닉네임인자", "닉네임 인자" or "(닉네임)(인자)" into a known nickname and
 * a parsed argument. `isNickname` must be case-insensitive.
 */
export function splitNickArg<T>(
  payload: string,
  isNickname: (n: string) => boolean,
  parseArg: (s: string) => T | null,
): { nickname: string; arg: T } | null {
  const p = payload.trim();
  const paren = p.match(/^\(([^)]+)\)\s*\(([\s\S]*)\)$/);
  if (paren) {
    const nickname = paren[1]!.trim();
    const arg = parseArg(paren[2]!.trim());
    return arg !== null && isNickname(nickname) ? { nickname, arg } : null;
  }
  const spaced = p.match(/^(\S+)\s+([\s\S]+)$/);
  if (spaced) {
    const nickname = spaced[1]!.replace(/[()]/g, "");
    const arg = parseArg(spaced[2]!.replace(/^\(|\)$/g, "").trim());
    if (arg !== null && isNickname(nickname)) return { nickname, arg };
  }
  const chars = Array.from(p.replace(/[()]/g, ""));
  for (let i = Math.min(12, chars.length - 1); i >= 2; i--) {
    const nickname = chars.slice(0, i).join("");
    if (/\s/.test(nickname)) continue;
    const arg = parseArg(chars.slice(i).join("").trim());
    if (arg !== null && isNickname(nickname)) return { nickname, arg };
  }
  return null;
}

export function splitGive(payload: string, isNickname: (n: string) => boolean): { nickname: string; item: GiveItem } | null {
  const r = splitNickArg(payload, isNickname, classifyItem);
  return r ? { nickname: r.nickname, item: r.arg } : null;
}

export const PLAYER_HELP = ["/귓속말닉네임 내용 — 귓속말 보내기 (예: /귓속말러키 안녕하세요)", "/help — 명령어 목록"];

export const COMMAND_HELP = [
  "/give닉네임숫자 — BP 지급 (예: /give러키100)",
  "/give닉네임칭호명 · 색상 · 방어권 — 아이템 지급",
  "/give닉네임all — 모든 아이템 지급",
  "/clear닉네임아이템 — 보유 아이템 전부 제거 (칭호명·색상·방어권·BP 지정 가능)",
  "/op닉네임 · /unop닉네임 — 관리자 권한 부여 · 박탈",
  "/tier닉네임티어 — 티어 배정 (예: /tier러키골드2)",
  "/untier닉네임 — 티어 박탈 (언랭)",
  "/del닉네임 — 계정 삭제",
  "/show닉네임 · /hide닉네임 — 대국 관전 · 관전 종료",
  "/stop닉네임초 — 대국 일시정지 (예: /stop러키30)",
  "/call내용 — 전체 공지 (10초)",
  "/k닉네임 — 10초간 추방",
  "/A — 가입한 계정 목록",
  ...PLAYER_HELP,
];
