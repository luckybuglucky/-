// Titles, nickname colors, rarities and redeem codes.

export const DEVELOPER_NICKNAME = "러키";
export const DEVELOPER_TITLE = "개발자";
export const WIN_STREAK_TITLE = "불굴";
export const WIN_STREAK_FOR_TITLE = 10;
export const LOSS_STREAK_TITLE = "불운";
export const LOSS_STREAK_FOR_TITLE = 5;
/** Held only by the current #1 on the leaderboard (and the developer). */
export const CHAMPION_TITLE = "챔피언";
export const JACKPOT_TITLE = "잭팟";
export const MAX_TITLE_LENGTH = 10;

/** One-time (per account) redeem codes and their BP reward. */
export const REDEEM_CODES: Record<string, number> = {
  RELEASE: 25,
  UPD1: 25,
  ILOVECAT: 25,
  OMOK: 25,
};

export function redeemReward(code: string): number | null {
  return REDEEM_CODES[code.trim().toUpperCase()] ?? null;
}

// ---------- Rarity ----------

export type Rarity = "rare" | "super" | "epic" | "legendary" | "secret";
export const RARITIES: Rarity[] = ["rare", "super", "epic", "legendary", "secret"];
export const RARITY_LABEL: Record<Rarity, string> = {
  rare: "희귀",
  super: "초희귀",
  epic: "에픽",
  legendary: "전설",
  secret: "시크릿",
};
export const RARITY_PRICE: Record<Rarity, number> = {
  rare: 20,
  super: 30,
  epic: 40,
  legendary: 75,
  secret: 175,
};

// ---------- Nickname colors ----------

export type NickColor = { id: string; label: string; aliases: string[]; rarity: Rarity | null };

/** rarity null = not sold in the shop. */
export const NICK_COLORS: NickColor[] = [
  { id: "rainbow", label: "무지개", aliases: ["무지개", "무지개색", "무지갯빛", "무지개빛", "레인보우", "rainbow"], rarity: null },
  { id: "red", label: "빨강", aliases: ["빨강", "빨간색", "빨강색", "레드", "red"], rarity: "rare" },
  { id: "orange", label: "주황", aliases: ["주황", "주황색", "오렌지", "orange"], rarity: "rare" },
  { id: "yellow", label: "노랑", aliases: ["노랑", "노란색", "노랑색", "옐로우", "yellow"], rarity: "rare" },
  { id: "green", label: "초록", aliases: ["초록", "초록색", "녹색", "그린", "green"], rarity: "rare" },
  { id: "sky", label: "하늘", aliases: ["하늘", "하늘색", "스카이", "sky"], rarity: "rare" },
  { id: "blue", label: "파랑", aliases: ["파랑", "파란색", "파랑색", "블루", "blue"], rarity: "rare" },
  { id: "purple", label: "보라", aliases: ["보라", "보라색", "퍼플", "purple"], rarity: "rare" },
  { id: "pink", label: "분홍", aliases: ["분홍", "분홍색", "핑크", "pink"], rarity: "rare" },
  { id: "white", label: "흰색", aliases: ["흰색", "하양", "하얀색", "white"], rarity: "rare" },
  { id: "mint", label: "민트", aliases: ["민트", "민트색", "mint"], rarity: "rare" },
  { id: "coral", label: "코랄", aliases: ["코랄", "산호", "산호색", "coral"], rarity: "rare" },
  { id: "lime", label: "라임", aliases: ["라임", "연두", "연두색", "lime"], rarity: "rare" },
  { id: "gold", label: "금색", aliases: ["금색", "황금", "황금색", "금빛", "gold"], rarity: "super" },
  { id: "silver", label: "은색", aliases: ["은색", "은빛", "silver"], rarity: "super" },
  { id: "lavender", label: "라벤더", aliases: ["라벤더", "lavender"], rarity: "super" },
  { id: "teal", label: "청록", aliases: ["청록", "청록색", "틸", "teal"], rarity: "super" },
  { id: "amber", label: "호박", aliases: ["호박", "호박색", "앰버", "amber"], rarity: "super" },
  { id: "rose", label: "장미", aliases: ["장미", "장미색", "로즈", "rose"], rarity: "super" },
  { id: "sunset", label: "노을", aliases: ["노을", "노을빛", "선셋", "sunset"], rarity: "epic" },
  { id: "ocean", label: "바다", aliases: ["바다", "바다색", "오션", "ocean"], rarity: "epic" },
  { id: "sakura", label: "벚꽃", aliases: ["벚꽃", "벚꽃색", "사쿠라", "sakura"], rarity: "epic" },
  { id: "neon", label: "네온", aliases: ["네온", "neon"], rarity: "epic" },
  { id: "aurora", label: "오로라", aliases: ["오로라", "aurora"], rarity: "legendary" },
  { id: "flame", label: "불꽃", aliases: ["불꽃", "화염", "flame"], rarity: "legendary" },
  { id: "galaxy", label: "은하", aliases: ["은하", "은하수", "갤럭시", "galaxy"], rarity: "legendary" },
  { id: "taegeuk", label: "태극", aliases: ["태극", "태극색", "taegeuk"], rarity: "secret" },
];

export function findColor(text: string): NickColor | null {
  const t = text.trim().toLowerCase().replace(/\s/g, "");
  return NICK_COLORS.find((c) => c.id === t || c.aliases.includes(t)) ?? null;
}

export function colorLabel(id: string) {
  return NICK_COLORS.find((c) => c.id === id)?.label ?? id;
}

// ---------- Titles ----------

export type TitleDef = { title: string; rarity: Rarity | null };

/** rarity null = earned or special, not sold in the shop. */
export const TITLES: TitleDef[] = [
  { title: DEVELOPER_TITLE, rarity: null },
  { title: CHAMPION_TITLE, rarity: null },
  { title: WIN_STREAK_TITLE, rarity: null },
  { title: LOSS_STREAK_TITLE, rarity: null },
  { title: "새내기", rarity: "rare" },
  { title: "수읽기", rarity: "rare" },
  { title: "속기", rarity: "rare" },
  { title: "장고", rarity: "rare" },
  { title: "꾸준함", rarity: "rare" },
  { title: "열정", rarity: "rare" },
  { title: "행운아", rarity: "rare" },
  { title: "묘수", rarity: "super" },
  { title: "철벽", rarity: "super" },
  { title: "승부사", rarity: "super" },
  { title: "전략가", rarity: "super" },
  { title: "야행성", rarity: "super" },
  { title: "한 수 위", rarity: "super" },
  { title: "오목 장인", rarity: "epic" },
  { title: "신의 한 수", rarity: "epic" },
  { title: "판의 지배자", rarity: "epic" },
  { title: "냉철", rarity: "epic" },
  { title: "폭풍", rarity: "epic" },
  { title: "흑백의 시인", rarity: "epic" },
  { title: "전설", rarity: "legendary" },
  { title: "무패", rarity: "legendary" },
  { title: "오목의 신", rarity: "legendary" },
  { title: "천재", rarity: "legendary" },
  { title: JACKPOT_TITLE, rarity: "secret" },
];

/** Catalog title matching the text, ignoring spaces ("오목장인" -> "오목 장인"). */
export function findTitle(text: string): TitleDef | null {
  const t = text.replace(/\s/g, "");
  return TITLES.find((d) => d.title.replace(/\s/g, "") === t) ?? null;
}

export function titleRarity(title: string): Rarity | null {
  return TITLES.find((d) => d.title === title)?.rarity ?? null;
}

/** Visual style key for a title badge. */
export function titleStyle(title: string): string {
  if (title === DEVELOPER_TITLE) return "developer";
  if (title === CHAMPION_TITLE) return "champion";
  if (title === WIN_STREAK_TITLE) return "unyielding";
  if (title === LOSS_STREAK_TITLE) return "unlucky";
  return titleRarity(title) ?? "custom";
}

// ---------- Shop items ----------

export type ShopItem = { key: string; kind: "title" | "color"; id: string; label: string; rarity: Rarity; price: number };

export function itemKey(kind: "title" | "color", id: string) {
  return `${kind}:${id}`;
}

/** Every item that can appear in the daily shop (excludes rainbow, 개발자, 챔피언, 불굴, 불운). */
export const SHOP_ITEMS: ShopItem[] = [
  ...TITLES.filter((t) => t.rarity).map((t) => ({
    key: itemKey("title", t.title),
    kind: "title" as const,
    id: t.title,
    label: t.title,
    rarity: t.rarity!,
    price: RARITY_PRICE[t.rarity!],
  })),
  ...NICK_COLORS.filter((c) => c.rarity).map((c) => ({
    key: itemKey("color", c.id),
    kind: "color" as const,
    id: c.id,
    label: c.label,
    rarity: c.rarity!,
    price: RARITY_PRICE[c.rarity!],
  })),
];

export function findShopItem(key: string) {
  return SHOP_ITEMS.find((i) => i.key === key) ?? null;
}

/** Titles granted by "/give닉네임all" (champion stays tied to #1, developer title stays with the developer). */
export const GIVE_ALL_TITLES = TITLES.filter((t) => t.title !== CHAMPION_TITLE && t.title !== DEVELOPER_TITLE).map((t) => t.title);
export const ALL_COLOR_IDS = NICK_COLORS.map((c) => c.id);
/** The developer account owns every title. */
export const DEVELOPER_TITLES = TITLES.map((t) => t.title);
