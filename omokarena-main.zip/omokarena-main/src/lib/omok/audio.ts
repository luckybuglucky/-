// Lightweight generative audio: synthesized stone clicks + calm ambient music.
// Everything is created with the Web Audio API, so no files need to download.

export type Track = "lobby" | "game";
export type AudioSettings = { music: number; sfx: number; muted: boolean };

type TrackDef = {
  bpm: number;
  barsPerChord: number;
  chords: number[][]; // midi notes, first is the root
  padCutoff: number;
  padGain: number;
  bass: boolean;
  lead: { notes: number[]; chance: number; perBeat: number; gain: number; decay: number; bell: boolean };
};

const TRACKS: Record<Track, TrackDef> = {
  lobby: {
    bpm: 76,
    barsPerChord: 2,
    chords: [
      [53, 57, 60, 64, 67],
      [52, 55, 59, 62],
      [50, 53, 57, 60, 64],
      [48, 55, 59, 64],
    ],
    padCutoff: 1100,
    padGain: 0.05,
    bass: true,
    lead: { notes: [], chance: 0.42, perBeat: 2, gain: 0.05, decay: 1.4, bell: false },
  },
  game: {
    bpm: 58,
    barsPerChord: 2,
    chords: [
      [45, 52, 55, 59, 60],
      [41, 48, 52, 57, 59],
      [48, 55, 59, 62, 64],
      [43, 50, 52, 57, 60],
    ],
    padCutoff: 750,
    padGain: 0.042,
    bass: false,
    lead: { notes: [69, 72, 74, 76, 79, 81, 84], chance: 0.24, perBeat: 1, gain: 0.045, decay: 2.4, bell: true },
  },
};

const STORAGE_KEY = "omok-arena-audio";
const midi = (n: number) => 440 * Math.pow(2, (n - 69) / 12);

class AudioEngine {
  private ctx: AudioContext | null = null;
  private master!: GainNode;
  private musicBus!: GainNode;
  private sfxBus!: GainNode;
  private reverb!: ConvolverNode;
  private delay!: DelayNode;
  private noise!: AudioBuffer;
  private desired: Track | null = null;
  private playing: Track | null = null;
  private trackGain: GainNode | null = null;
  private timer: number | null = null;
  private nextBeat = 0;
  private beat = 0;
  private listeners = new Set<() => void>();
  settings: AudioSettings = { music: 0.55, sfx: 0.8, muted: false };

  subscribe(fn: () => void) {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }

  loadSettings() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) this.settings = { ...this.settings, ...JSON.parse(raw) };
    } catch {
      /* ignore */
    }
  }

  update(next: Partial<AudioSettings>) {
    this.settings = { ...this.settings, ...next };
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(this.settings));
    } catch {
      /* ignore */
    }
    this.applyVolumes();
    this.listeners.forEach((l) => l());
  }

  private applyVolumes() {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    this.master.gain.setTargetAtTime(this.settings.muted ? 0 : 1, t, 0.05);
    this.musicBus.gain.setTargetAtTime(this.settings.music, t, 0.1);
    this.sfxBus.gain.setTargetAtTime(this.settings.sfx, t, 0.05);
  }

  private init() {
    if (this.ctx) return;
    const Ctx = window.AudioContext ?? (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!Ctx) return;
    const ctx = new Ctx();
    this.ctx = ctx;
    this.master = ctx.createGain();
    this.master.connect(ctx.destination);
    this.musicBus = ctx.createGain();
    this.sfxBus = ctx.createGain();
    this.musicBus.connect(this.master);
    this.sfxBus.connect(this.master);

    // reverb
    this.reverb = ctx.createConvolver();
    const len = Math.floor(ctx.sampleRate * 3);
    const ir = ctx.createBuffer(2, len, ctx.sampleRate);
    for (let ch = 0; ch < 2; ch++) {
      const d = ir.getChannelData(ch);
      for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, 3);
    }
    this.reverb.buffer = ir;
    const wet = ctx.createGain();
    wet.gain.value = 0.55;
    this.reverb.connect(wet).connect(this.musicBus);

    // soft echo
    this.delay = ctx.createDelay(2);
    this.delay.delayTime.value = 0.42;
    const fb = ctx.createGain();
    fb.gain.value = 0.32;
    const dl = ctx.createBiquadFilter();
    dl.type = "lowpass";
    dl.frequency.value = 2200;
    this.delay.connect(dl).connect(fb).connect(this.delay);
    dl.connect(this.reverb);
    const dWet = ctx.createGain();
    dWet.gain.value = 0.35;
    dl.connect(dWet).connect(this.musicBus);

    // noise buffer for clicks
    this.noise = ctx.createBuffer(1, Math.floor(ctx.sampleRate * 0.15), ctx.sampleRate);
    const nd = this.noise.getChannelData(0);
    for (let i = 0; i < nd.length; i++) nd[i] = Math.random() * 2 - 1;

    this.loadSettings();
    this.applyVolumes();
    this.listeners.forEach((l) => l());
  }

  unlock() {
    this.init();
    if (!this.ctx) return;
    if (this.ctx.state === "suspended") void this.ctx.resume().then(() => this.sync());
    else this.sync();
  }

  setTrack(track: Track | null) {
    this.desired = track;
    this.sync();
  }

  private sync() {
    if (!this.ctx || this.ctx.state !== "running") return;
    if (this.playing === this.desired) return;
    this.stopTrack();
    if (this.desired) this.startTrack(this.desired);
  }

  private stopTrack() {
    if (!this.ctx) return;
    if (this.timer) window.clearInterval(this.timer);
    this.timer = null;
    const g = this.trackGain;
    if (g) {
      const t = this.ctx.currentTime;
      g.gain.cancelScheduledValues(t);
      g.gain.setValueAtTime(g.gain.value, t);
      g.gain.linearRampToValueAtTime(0, t + 1.5);
      window.setTimeout(() => g.disconnect(), 4000);
    }
    this.trackGain = null;
    this.playing = null;
  }

  private startTrack(track: Track) {
    const ctx = this.ctx!;
    const g = ctx.createGain();
    g.gain.value = 0;
    g.gain.linearRampToValueAtTime(1, ctx.currentTime + 2.5);
    g.connect(this.musicBus);
    g.connect(this.reverb);
    this.trackGain = g;
    this.playing = track;
    this.beat = 0;
    this.nextBeat = ctx.currentTime + 0.1;
    const def = TRACKS[track];
    const tick = () => {
      if (!this.ctx || this.trackGain !== g) return;
      while (this.nextBeat < this.ctx.currentTime + 0.8) {
        this.scheduleBeat(def, g, this.nextBeat, this.beat);
        this.nextBeat += 60 / def.bpm;
        this.beat++;
      }
    };
    tick();
    this.timer = window.setInterval(tick, 250);
  }

  private scheduleBeat(def: TrackDef, out: GainNode, t: number, beat: number) {
    const beatsPerChord = def.barsPerChord * 4;
    const chordIdx = Math.floor(beat / beatsPerChord) % def.chords.length;
    const chord = def.chords[chordIdx]!;
    const beatLen = 60 / def.bpm;

    if (beat % beatsPerChord === 0) {
      const dur = beatsPerChord * beatLen;
      chord.forEach((n) => this.pad(out, midi(n), t, dur, def));
      if (def.bass) this.pad(out, midi(chord[0]! - 12), t, dur, { ...def, padGain: def.padGain * 1.2, padCutoff: 400 });
    }

    const pool = def.lead.notes.length ? def.lead.notes : chord.slice(1).map((n) => n + 12);
    for (let s = 0; s < def.lead.perBeat; s++) {
      if (Math.random() < def.lead.chance) {
        const n = pool[Math.floor(Math.random() * pool.length)]!;
        this.pluck(out, midi(n), t + (s * beatLen) / def.lead.perBeat, def.lead);
      }
    }
  }

  private pad(out: GainNode, freq: number, t: number, dur: number, def: TrackDef) {
    const ctx = this.ctx!;
    const filter = ctx.createBiquadFilter();
    filter.type = "lowpass";
    filter.frequency.value = def.padCutoff;
    const env = ctx.createGain();
    env.gain.setValueAtTime(0, t);
    env.gain.linearRampToValueAtTime(def.padGain, t + 2);
    env.gain.setValueAtTime(def.padGain, t + dur - 0.2);
    env.gain.linearRampToValueAtTime(0, t + dur + 2.2);
    filter.connect(env).connect(out);
    const types: OscillatorType[] = ["sine", "triangle"];
    types.forEach((type, i) => {
      const o = ctx.createOscillator();
      o.type = type;
      o.frequency.value = freq;
      o.detune.value = i === 0 ? -5 : 6;
      o.connect(filter);
      o.start(t);
      o.stop(t + dur + 2.4);
    });
  }

  private pluck(out: GainNode, freq: number, t: number, lead: TrackDef["lead"]) {
    const ctx = this.ctx!;
    const env = ctx.createGain();
    env.gain.setValueAtTime(0, t);
    env.gain.linearRampToValueAtTime(lead.gain, t + 0.008);
    env.gain.exponentialRampToValueAtTime(0.0001, t + lead.decay);
    env.connect(out);
    env.connect(this.delay);
    const o = ctx.createOscillator();
    o.type = "sine";
    o.frequency.value = freq;
    o.connect(env);
    o.start(t);
    o.stop(t + lead.decay + 0.05);
    if (lead.bell) {
      const p = ctx.createOscillator();
      const pg = ctx.createGain();
      p.type = "sine";
      p.frequency.value = freq * 4.01;
      pg.gain.setValueAtTime(0.18, t);
      pg.gain.exponentialRampToValueAtTime(0.0001, t + 0.4);
      p.connect(pg).connect(env);
      p.start(t);
      p.stop(t + 0.45);
    }
  }

  private tone(freq: number, t: number, dur: number, gain: number, type: OscillatorType = "sine") {
    const ctx = this.ctx!;
    const o = ctx.createOscillator();
    const g = ctx.createGain();
    o.type = type;
    o.frequency.value = freq;
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(gain, t + 0.01);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g).connect(this.sfxBus);
    o.start(t);
    o.stop(t + dur + 0.05);
  }

  stone() {
    if (!this.ctx || this.ctx.state !== "running") return;
    const ctx = this.ctx;
    const t = ctx.currentTime;
    const src = ctx.createBufferSource();
    src.buffer = this.noise;
    const bp = ctx.createBiquadFilter();
    bp.type = "bandpass";
    bp.frequency.value = 2000 + Math.random() * 500;
    bp.Q.value = 1.4;
    const ng = ctx.createGain();
    ng.gain.setValueAtTime(0.0001, t);
    ng.gain.exponentialRampToValueAtTime(0.55, t + 0.002);
    ng.gain.exponentialRampToValueAtTime(0.0001, t + 0.07);
    src.connect(bp).connect(ng).connect(this.sfxBus);
    src.start(t);
    src.stop(t + 0.1);

    const o = ctx.createOscillator();
    const og = ctx.createGain();
    o.type = "sine";
    o.frequency.setValueAtTime(240 + Math.random() * 30, t);
    o.frequency.exponentialRampToValueAtTime(110, t + 0.06);
    og.gain.setValueAtTime(0.4, t);
    og.gain.exponentialRampToValueAtTime(0.0001, t + 0.1);
    o.connect(og).connect(this.sfxBus);
    o.start(t);
    o.stop(t + 0.12);
  }

  chime(kind: "match" | "win" | "lose" | "tick" | "message") {
    if (!this.ctx || this.ctx.state !== "running") return;
    const t = this.ctx.currentTime;
    if (kind === "tick") this.tone(1046, t, 0.08, 0.08, "triangle");
    if (kind === "message") this.tone(880, t, 0.15, 0.06);
    if (kind === "match") [659, 880].forEach((f, i) => this.tone(f, t + i * 0.12, 0.6, 0.12));
    if (kind === "win") [523, 659, 784, 1046].forEach((f, i) => this.tone(f, t + i * 0.1, 0.9, 0.11));
    if (kind === "lose") [440, 349].forEach((f, i) => this.tone(f, t + i * 0.18, 0.9, 0.1));
  }
}

let engine: AudioEngine | null = null;
export function audio(): AudioEngine {
  if (!engine) engine = new AudioEngine();
  return engine;
}
