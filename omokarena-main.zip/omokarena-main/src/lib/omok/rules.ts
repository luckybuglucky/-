// Omok (Renju-style) rules. Black moves first; black is forbidden from
// overlines (6+), double-four and double-three. White may make overlines.

export const SIZE = 15;
export type Color = 1 | 2; // 1 = black, 2 = white
export type Cell = 0 | Color;
export type Board = Cell[];
export type Move = [number, number];

const DIRS: Array<[number, number]> = [
  [1, 0],
  [0, 1],
  [1, 1],
  [1, -1],
];

export function emptyBoard(): Board {
  return new Array(SIZE * SIZE).fill(0) as Board;
}

export function boardFromMoves(moves: Move[]): Board {
  const b = emptyBoard();
  moves.forEach(([x, y], i) => {
    b[y * SIZE + x] = i % 2 === 0 ? 1 : 2;
  });
  return b;
}

export function colorToMove(moveCount: number): Color {
  return moveCount % 2 === 0 ? 1 : 2;
}

export function inside(x: number, y: number) {
  return x >= 0 && y >= 0 && x < SIZE && y < SIZE;
}

export function at(b: Board, x: number, y: number): number {
  if (!inside(x, y)) return -1;
  return b[y * SIZE + x]!;
}

/** Length of consecutive `c` stones through (x,y) along a direction, plus the span. */
function span(b: Board, x: number, y: number, dx: number, dy: number, c: number) {
  let neg = 0;
  while (at(b, x - (neg + 1) * dx, y - (neg + 1) * dy) === c) neg++;
  let pos = 0;
  while (at(b, x + (pos + 1) * dx, y + (pos + 1) * dy) === c) pos++;
  return { neg, pos, len: neg + pos + 1 };
}

/** Offsets on the line where adding a black stone makes exactly five covering the origin. */
function fiveOffsets(b: Board, x: number, y: number, dx: number, dy: number, c: Color) {
  const offs: number[] = [];
  for (let k = -4; k <= 4; k++) {
    if (k === 0) continue;
    const ex = x + k * dx;
    const ey = y + k * dy;
    if (at(b, ex, ey) !== 0) continue;
    b[ey * SIZE + ex] = c;
    const s = span(b, ex, ey, dx, dy, c);
    b[ey * SIZE + ex] = 0;
    const from = k - s.neg;
    const to = k + s.pos;
    const ok = c === 1 ? s.len === 5 : s.len >= 5;
    if (ok && from <= 0 && to >= 0) offs.push(k);
  }
  return offs;
}

function foursInDir(b: Board, x: number, y: number, dx: number, dy: number) {
  const offs = fiveOffsets(b, x, y, dx, dy, 1);
  if (offs.length === 0) return 0;
  if (offs.length === 2 && Math.abs(offs[0]! - offs[1]!) === 5) return 1; // straight (open) four
  return offs.length >= 2 ? 2 : 1;
}

function isOpenFourDir(b: Board, x: number, y: number, dx: number, dy: number) {
  const offs = fiveOffsets(b, x, y, dx, dy, 1);
  return offs.length === 2 && Math.abs(offs[0]! - offs[1]!) === 5;
}

function isOpenThreeDir(b: Board, x: number, y: number, dx: number, dy: number) {
  if (foursInDir(b, x, y, dx, dy) > 0) return false;
  for (let k = -4; k <= 4; k++) {
    if (k === 0) continue;
    const ex = x + k * dx;
    const ey = y + k * dy;
    if (at(b, ex, ey) !== 0) continue;
    b[ey * SIZE + ex] = 1;
    const over = span(b, ex, ey, dx, dy, 1).len >= 6;
    const open = !over && isOpenFourDir(b, x, y, dx, dy);
    b[ey * SIZE + ex] = 0;
    if (open) return true;
  }
  return false;
}

/** Board must already contain the stone at (x,y). */
export function makesFive(b: Board, x: number, y: number, c: Color): boolean {
  return DIRS.some(([dx, dy]) => {
    const l = span(b, x, y, dx, dy, c).len;
    return c === 1 ? l === 5 : l >= 5;
  });
}

export type FoulKind = "overline" | "double-four" | "double-three";

/** Black-only forbidden-move check. Board must already contain the black stone at (x,y). */
export function blackFoul(b: Board, x: number, y: number): FoulKind | null {
  if (makesFive(b, x, y, 1)) return null; // exact five always wins
  if (DIRS.some(([dx, dy]) => span(b, x, y, dx, dy, 1).len >= 6)) return "overline";
  let fours = 0;
  let threes = 0;
  for (const [dx, dy] of DIRS) {
    fours += foursInDir(b, x, y, dx, dy);
    if (isOpenThreeDir(b, x, y, dx, dy)) threes++;
  }
  if (fours >= 2) return "double-four";
  if (threes >= 2) return "double-three";
  return null;
}

export type MoveOutcome =
  | { kind: "continue" }
  | { kind: "win"; winner: Color; reason: "five" }
  | { kind: "foul"; winner: Color; reason: "foul"; foul: FoulKind }
  | { kind: "draw" };

/** Applies the move to the board (mutates) and reports the outcome. */
export function applyMove(b: Board, x: number, y: number, c: Color, moveCountAfter: number): MoveOutcome {
  b[y * SIZE + x] = c;
  if (c === 1) {
    const foul = blackFoul(b, x, y);
    if (foul) return { kind: "foul", winner: 2, reason: "foul", foul };
  }
  if (makesFive(b, x, y, c)) return { kind: "win", winner: c, reason: "five" };
  if (moveCountAfter >= SIZE * SIZE) return { kind: "draw" };
  return { kind: "continue" };
}

export function stonesPlayed(moveCount: number, color: Color) {
  return color === 1 ? Math.ceil(moveCount / 2) : Math.floor(moveCount / 2);
}
