import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { COMMAND_HELP, nicknameCandidates, parseCommand, splitGive } from "./commands";
import { colorLabel, findColor, NICK_COLORS, redeemReward } from "./cosmetics";
import { grantTitle, type Admin } from "./engine";

const INVITE_TTL_MS = 60_000;
const NICK_RE = /^[가-힣a-zA-Z0-9_]{2,12}$/;

async function admin(): Promise<Admin> {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  return supabaseAdmin;
}

async function hasActiveGame(db: Admin, userId: string) {
  const { data } = await db
    .from("games")
    .select("id")
    .eq("status", "active")
    .or(`black_id.eq.${userId},white_id.eq.${userId}`)
    .limit(1);
  return data?.[0]?.id ?? null;
}

// ---------- Redeem codes ----------

export const redeemCode = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ code: z.string().min(1).max(40) }).parse(input))
  .handler(async ({ data, context }) => {
    const code = data.code.trim().toUpperCase();
    const reward = redeemReward(code);
    if (reward === null) throw new Error("존재하지 않는 코드입니다.");
    const db = await admin();
    const { error } = await db.from("redeemed_codes").insert({ user_id: context.userId, code });
    if (error) throw new Error(error.code === "23505" ? "이미 사용한 코드입니다." : "코드를 사용할 수 없습니다.");
    const { data: p } = await db.from("profiles").select("bp").eq("id", context.userId).single();
    await db.from("profiles").update({ bp: (p?.bp ?? 0) + reward }).eq("id", context.userId);
    return { reward };
  });

// ---------- Inventory ----------

export const getInventory = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const db = await admin();
    const [{ data: titles }, { data: colors }, { data: p }] = await Promise.all([
      db.from("profile_titles").select("title, created_at").eq("user_id", context.userId).order("created_at"),
      db.from("profile_colors").select("color, created_at").eq("user_id", context.userId).order("created_at"),
      db.from("profiles").select("equipped_title, equipped_color").eq("id", context.userId).single(),
    ]);
    return {
      titles: (titles ?? []).map((t) => t.title),
      colors: (colors ?? []).map((c) => c.color),
      equippedTitle: p?.equipped_title ?? null,
      equippedColor: p?.equipped_color ?? null,
    };
  });

export const equipCosmetics = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z.object({ title: z.string().max(20).nullable(), color: z.string().max(20).nullable() }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const db = await admin();
    if (data.title) {
      const { data: own } = await db.from("profile_titles").select("title").eq("user_id", context.userId).eq("title", data.title).maybeSingle();
      if (!own) throw new Error("보유하지 않은 칭호입니다.");
    }
    if (data.color) {
      const { data: own } = await db.from("profile_colors").select("color").eq("user_id", context.userId).eq("color", data.color).maybeSingle();
      if (!own) throw new Error("보유하지 않은 색상입니다.");
    }
    await db.from("profiles").update({ equipped_title: data.title, equipped_color: data.color }).eq("id", context.userId);
    return { ok: true };
  });

// ---------- Friendly match invites ----------

export const sendInvite = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ nickname: z.string().min(1).max(20) }).parse(input))
  .handler(async ({ data, context }) => {
    const db = await admin();
    const name = data.nickname.trim();
    if (!NICK_RE.test(name)) throw new Error("닉네임을 정확히 입력해 주세요.");
    const { data: target } = await db.from("profiles").select("id, nickname").ilike("nickname", name).maybeSingle();
    if (!target) throw new Error("해당 닉네임의 플레이어를 찾을 수 없습니다.");
    if (target.id === context.userId) throw new Error("자기 자신에게는 신청할 수 없습니다.");
    if (await hasActiveGame(db, context.userId)) throw new Error("진행 중인 대국이 있습니다.");
    if (await hasActiveGame(db, target.id)) throw new Error(`${target.nickname}님은 대국 중입니다.`);
    await db.from("match_queue").delete().eq("user_id", context.userId);
    await db.from("game_invites").update({ status: "cancelled" }).eq("from_id", context.userId).eq("status", "pending");
    const { data: inv, error } = await db
      .from("game_invites")
      .insert({ from_id: context.userId, to_id: target.id })
      .select("id")
      .single();
    if (error || !inv) throw new Error("신청을 보낼 수 없습니다.");
    return { inviteId: inv.id, nickname: target.nickname };
  });

export const inviteStatus = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const db = await admin();
    const { data: inv } = await db.from("game_invites").select("*").eq("id", data.id).single();
    if (!inv || (inv.from_id !== context.userId && inv.to_id !== context.userId)) throw new Error("신청을 찾을 수 없습니다.");
    const expired = inv.status === "pending" && Date.now() - new Date(inv.created_at).getTime() > INVITE_TTL_MS;
    if (expired) await db.from("game_invites").update({ status: "cancelled" }).eq("id", inv.id).eq("status", "pending");
    return { status: expired ? "expired" : inv.status, gameId: inv.game_id };
  });

export const cancelInvite = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const db = await admin();
    await db.from("game_invites").update({ status: "cancelled" }).eq("id", data.id).eq("from_id", context.userId).eq("status", "pending");
    return { ok: true };
  });

export const respondInvite = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ id: z.string().uuid(), accept: z.boolean() }).parse(input))
  .handler(async ({ data, context }) => {
    const db = await admin();
    const { data: inv } = await db.from("game_invites").select("*").eq("id", data.id).single();
    if (!inv || inv.to_id !== context.userId) throw new Error("신청을 찾을 수 없습니다.");
    if (inv.status !== "pending" || Date.now() - new Date(inv.created_at).getTime() > INVITE_TTL_MS) {
      throw new Error("이미 만료된 신청입니다.");
    }
    if (!data.accept) {
      await db.from("game_invites").update({ status: "declined" }).eq("id", inv.id).eq("status", "pending");
      return { gameId: null };
    }
    if (await hasActiveGame(db, context.userId)) throw new Error("진행 중인 대국이 있습니다.");
    if (await hasActiveGame(db, inv.from_id)) throw new Error("상대가 이미 대국 중입니다.");
    const meBlack = Math.random() < 0.5;
    const { data: game, error } = await db
      .from("games")
      .insert({
        mode: "normal",
        friendly: true,
        vs_ai: false,
        black_id: meBlack ? context.userId : inv.from_id,
        white_id: meBlack ? inv.from_id : context.userId,
        turn_started_at: new Date(Date.now() + 3000).toISOString(),
      })
      .select("id")
      .single();
    if (error || !game) throw new Error("대국을 만들 수 없습니다.");
    const { data: updated } = await db
      .from("game_invites")
      .update({ status: "accepted", game_id: game.id })
      .eq("id", inv.id)
      .eq("status", "pending")
      .select("id")
      .maybeSingle();
    if (!updated) {
      await db.from("games").update({ status: "finished", end_reason: "draw" }).eq("id", game.id);
      throw new Error("상대가 신청을 취소했습니다.");
    }
    await db.from("match_queue").delete().in("user_id", [context.userId, inv.from_id]);
    return { gameId: game.id };
  });

// ---------- Admin console ----------

export const runCommand = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ command: z.string().min(1).max(100) }).parse(input))
  .handler(async ({ data, context }) => {
    const { data: isAdmin } = await context.supabase.rpc("has_role", { _user_id: context.userId, _role: "admin" });
    if (!isAdmin) throw new Error("관리자가 아닙니다.");

    const parsed = parseCommand(data.command);
    if (parsed.cmd === "help") return { ok: true, message: COMMAND_HELP.join("\n") };
    if (parsed.cmd === "unknown") return { ok: false, message: `알 수 없는 명령어입니다: ${parsed.name}  (/help 참고)` };
    if (!parsed.payload) return { ok: false, message: "사용법: /give닉네임(숫자|칭호명|색상|방어권)" };

    const db = await admin();
    const firstToken = parsed.payload.match(/^\(?([^)\s]+)/)?.[1] ?? "";
    const cands = Array.from(new Set([firstToken, ...nicknameCandidates(parsed.payload.replace(/\s/g, ""))])).filter((c) =>
      NICK_RE.test(c),
    );
    if (!cands.length) return { ok: false, message: "닉네임을 찾을 수 없습니다." };
    const { data: found } = await db
      .from("profiles")
      .select("id, nickname, bp, shields")
      .or(cands.map((c) => `nickname.ilike.${c}`).join(","));
    const byLower = new Map((found ?? []).map((p) => [p.nickname.toLowerCase(), p]));
    const split = splitGive(parsed.payload, (n) => byLower.has(n.toLowerCase()));
    if (!split) return { ok: false, message: "닉네임 또는 지급 항목을 인식하지 못했습니다. (/help 참고)" };
    const target = byLower.get(split.nickname.toLowerCase())!;
    const item = split.item;

    if (item.kind === "bp") {
      await db.from("profiles").update({ bp: target.bp + item.amount }).eq("id", target.id);
      return { ok: true, message: `${target.nickname}님에게 ${item.amount} BP를 지급했습니다.` };
    }
    if (item.kind === "shield") {
      await db.from("profiles").update({ shields: target.shields + item.count }).eq("id", target.id);
      return { ok: true, message: `${target.nickname}님에게 강등 방어권 ${item.count}개를 지급했습니다.` };
    }
    if (item.kind === "color") {
      const color = findColor(item.color) ?? NICK_COLORS.find((c) => c.id === item.color);
      await db
        .from("profile_colors")
        .upsert({ user_id: target.id, color: item.color }, { onConflict: "user_id,color", ignoreDuplicates: true });
      return { ok: true, message: `${target.nickname}님에게 '${color?.label ?? colorLabel(item.color)}' 닉네임 색상을 지급했습니다.` };
    }
    const added = await grantTitle(db, target.id, item.title);
    return {
      ok: true,
      message: added ? `${target.nickname}님에게 '${item.title}' 칭호를 지급했습니다.` : `${target.nickname}님은 이미 '${item.title}' 칭호를 보유하고 있습니다.`,
    };
  });
