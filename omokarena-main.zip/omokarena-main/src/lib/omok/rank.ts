// Ranking math: tiers, divisions, RP, performance, placement and rewards.

export const TIERS = [
  "iron",
  "bronze",
  "silver",
  "gold",
  "platinum",
  "diamond",
  "master",
  "grandmaster",
  "challenger",
] as const;
export type Tier = (typeof TIERS)[number];

export const TIER_LABEL: Record<Tier, string> = {
  iron: "아이언",
  bronze: "브론즈",
  silver: "실버",
  gold: "골드",
  platinum: "플래티넘",
  diamond: "다이아몬드",
  master: "마스터",
  grandmaster: "그랜드마스터",
  challenger: "챌린저",
};

export const PLACEMENT_GAMES = 5;
export const BASE_DIVISION_RP = 100;
export const HIGH_DIVISION_RP = 150; // master and above
export const SHIELD_PRICE = 100;
export const LEAVE_PENALTY = 5;
export const TURN_SECONDS = 60;
const HIGH_TIER_INDEX = 6; // master
const HIGH_START = HIGH_TIER_INDEX * 3 * BASE_DIVISION_RP; // 1800
const LAST_DIVISION = TIERS.length * 3 - 1; // 26

export function divisionSize(divIndex: number) {
  return divIndex >= HIGH_TIER_INDEX * 3 ? HIGH_DIVISION_RP : BASE_DIVISION_RP;
}

export function divisionStart(divIndex: number) {
  if (divIndex < HIGH_TIER_INDEX * 3) return divIndex * BASE_DIVISION_RP;
  return HIGH_START + (divIndex - HIGH_TIER_INDEX * 3) * HIGH_DIVISION_RP;
}

export function divisionIndex(rating: number) {
  const r = Math.max(0, rating);
  const d =
    r < HIGH_START
      ? Math.floor(r / BASE_DIVISION_RP)
      : HIGH_TIER_INDEX * 3 + Math.floor((r - HIGH_START) / HIGH_DIVISION_RP);
  return Math.min(d, LAST_DIVISION);
}

export type RankInfo = {
  tier: Tier;
  tierIndex: number;
  division: 1 | 2 | 3; // 1 is the lowest step, 3 promotes into the next tier
  rp: number; // RP within the current division
  size: number; // RP needed to promote
  label: string;
};

export function rankFromRating(rating: number): RankInfo {
  const d = divisionIndex(rating);
  const tierIndex = Math.floor(d / 3);
  const tier = TIERS[tierIndex]!;
  const division = ((d % 3) + 1) as 1 | 2 | 3;
  return {
    tier,
    tierIndex,
    division,
    rp: Math.max(0, rating) - divisionStart(d),
    size: divisionSize(d),
    label: `${TIER_LABEL[tier]} ${division}`,
  };
}

/** Performance score (0-100). Faster wins score higher; longer resistance softens a loss. */
export function performanceScore(won: boolean, stones: number, left = false) {
  if (left) return 0;
  if (won) return clamp(Math.round(100 - (stones - 5) * 2.5), 40, 100);
  return clamp(Math.round(stones * 1.2), 5, 35);
}

/** Placement game counts as "perfect" only when won within this many total moves (both players' stones). */
export const PLACEMENT_PERFECT_MAX_MOVES = 20;
/** Platinum 3 — the highest placement result, reserved for a perfect placement. */
export const PLACEMENT_MAX_RATING = 1400;

export function isPerfectPlacementGame(won: boolean, totalMoves: number) {
  return won && totalMoves <= PLACEMENT_PERFECT_MAX_MOVES;
}

/**
 * Initial rating after placement. Perfect placement (5/5 wins, each within 20
 * total moves) gives Platinum 3; otherwise the average performance score maps to
 * at most Platinum 2.
 */
export function placementRating(totalScore: number, games = PLACEMENT_GAMES, perfect = false) {
  if (perfect) return PLACEMENT_MAX_RATING;
  const avg = totalScore / games;
  return clamp(Math.round(avg * 14), 0, PLACEMENT_MAX_RATING - 1);
}

export function rankedWinRp(perf: number) {
  return 15 + Math.round(((clamp(perf, 40, 100) - 40) / 60) * 15);
}

export function rankedLossRp(stones: number) {
  return 22 - Math.min(8, Math.floor(stones / 4));
}

/** Applies an RP delta, consuming a demotion shield if it would drop a division. */
export function applyRatingChange(rating: number, delta: number, shields: number) {
  const next = Math.max(0, rating + delta);
  if (delta < 0 && shields > 0) {
    const floor = divisionStart(divisionIndex(rating));
    if (next < floor) return { rating: floor, shields: shields - 1, shieldUsed: true };
  }
  return { rating: next, shields, shieldUsed: false };
}

export function randomBp(rand: () => number = Math.random) {
  return 1 + Math.floor(rand() * 5); // 1..5
}

function clamp(v: number, lo: number, hi: number) {
  return Math.min(hi, Math.max(lo, v));
}

// ---- Rating gap & MMR ----

/** Rating gap where RP scaling starts, and the gap that reaches the full effect. */
export const GAP_START = 200;
export const GAP_FULL = 500;

/**
 * Multipliers for RP when the two players' ratings differ a lot.
 * diff = opponent rating - my rating. Beating a much stronger player pays more,
 * beating a much weaker player pays less; losses mirror it.
 */
export function gapMultipliers(myRating: number, oppRating: number) {
  const diff = oppRating - myRating;
  const over = Math.max(0, Math.abs(diff) - GAP_START);
  const t = Math.min(1, over / (GAP_FULL - GAP_START)) * 0.5; // 0..0.5
  if (diff >= 0) return { win: 1 + t, loss: 1 - t };
  return { win: 1 - t, loss: 1 + t };
}

export const DEFAULT_MMR = 600;
export const AI_MMR: Record<string, number> = { easy: 300, normal: 700, hard: 1100 };

/**
 * Hidden matchmaking rating. Elo-style change plus a win-streak bonus so players
 * on a streak get matched against stronger opponents.
 */
export function mmrChange(myMmr: number, oppMmr: number, won: boolean, winStreakAfter: number) {
  const expected = 1 / (1 + Math.pow(10, (oppMmr - myMmr) / 400));
  let delta = Math.round(40 * ((won ? 1 : 0) - expected));
  if (won && winStreakAfter >= 2) delta += Math.min(40, (winStreakAfter - 1) * 8);
  return delta;
}

/** Reward scale for beating each AI level (RP, performance score). Hard AI = full rewards. */
export const AI_REWARD_SCALE: Record<string, number> = { easy: 0.3, normal: 0.6, hard: 1 };
/** Max BP for a win against each AI level (min is always 1). */
export const AI_MAX_BP: Record<string, number> = { easy: 1, normal: 2, hard: 5 };

export function aiRewardScale(level: string | null | undefined) {
  return AI_REWARD_SCALE[level ?? "hard"] ?? 1;
}

export function randomBpFor(level: string | null | undefined, rand: () => number = Math.random) {
  const max = level ? AI_MAX_BP[level] ?? 5 : 5;
  return 1 + Math.floor(rand() * max);
}

/** Any win has this chance to pay the jackpot instead of the normal 1-5 BP. */
export const WIN_JACKPOT_CHANCE = 0.005;
export const WIN_JACKPOT_BP = 150;

export function winReward(aiLevel: string | null | undefined, rand: () => number = Math.random) {
  if (rand() < WIN_JACKPOT_CHANCE) return { bp: WIN_JACKPOT_BP, jackpot: true };
  return { bp: aiLevel ? randomBpFor(aiLevel, rand) : randomBp(rand), jackpot: false };
}
