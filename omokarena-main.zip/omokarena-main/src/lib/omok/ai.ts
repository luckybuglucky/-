import { SIZE, at, blackFoul, makesFive, type Board, type Color, type Move } from "./rules";

export type AiLevel = "easy" | "normal" | "hard";

const DIRS: Array<[number, number]> = [
  [1, 0],
  [0, 1],
  [1, 1],
  [1, -1],
];

type Kind = "five" | "open4" | "four" | "open3" | "three" | "open2" | "two";
const PATTERNS: Array<[string, number, Kind]> = [
  ["XXXXX", 1_000_000, "five"],
  [".XXXX.", 120_000, "open4"],
  ["XXXX.", 12_000, "four"],
  [".XXXX", 12_000, "four"],
  ["XX.XX", 12_000, "four"],
  ["X.XXX", 12_000, "four"],
  ["XXX.X", 12_000, "four"],
  [".XXX.", 5_000, "open3"],
  [".XX.X.", 5_000, "open3"],
  [".X.XX.", 5_000, "open3"],
  ["XXX..", 700, "three"],
  ["..XXX", 700, "three"],
  ["X.XX.", 600, "three"],
  [".XX.X", 600, "three"],
  ["XX.X.", 600, "three"],
  [".X.XX", 600, "three"],
  ["X..XX", 500, "three"],
  ["XX..X", 500, "three"],
  ["X.X.X", 500, "three"],
  ["..XX..", 300, "open2"],
  [".X.X.", 220, "open2"],
  [".X..X.", 180, "open2"],
  ["XX...", 60, "two"],
  ["...XX", 60, "two"],
  [".X.X..", 60, "two"],
];

function lineFor(b: Board, x: number, y: number, dx: number, dy: number, c: Color) {
  let s = "";
  for (let k = -5; k <= 5; k++) {
    if (k === 0) {
      s += "X";
      continue;
    }
    const v = at(b, x + k * dx, y + k * dy);
    s += v === c ? "X" : v === 0 ? "." : "B";
  }
  return s;
}

function matchAtCenter(line: string, pat: string) {
  const center = 5;
  for (let s = Math.max(0, center - pat.length + 1); s <= Math.min(center, line.length - pat.length); s++) {
    if (pat[center - s] === "X" && line.startsWith(pat, s)) return true;
  }
  return false;
}

/** Heuristic value of placing `c` at (x,y). Cell must be empty. */
export function evaluatePoint(b: Board, x: number, y: number, c: Color): number {
  let total = 0;
  let fours = 0;
  let open3 = 0;
  for (const [dx, dy] of DIRS) {
    const line = lineFor(b, x, y, dx, dy, c);
    for (const [pat, score, kind] of PATTERNS) {
      if (matchAtCenter(line, pat)) {
        total += score;
        if (kind === "open4" || kind === "four") fours++;
        if (kind === "open3") open3++;
        break;
      }
    }
  }
  if (fours >= 2 || (fours >= 1 && open3 >= 1)) total += 90_000;
  else if (open3 >= 2) total += 40_000;
  return total;
}

function candidates(b: Board): Move[] {
  const out: Move[] = [];
  let any = false;
  for (let y = 0; y < SIZE; y++) {
    for (let x = 0; x < SIZE; x++) {
      if (b[y * SIZE + x] !== 0) {
        any = true;
        continue;
      }
      let near = false;
      for (let dy = -2; dy <= 2 && !near; dy++) {
        for (let dx = -2; dx <= 2 && !near; dx++) {
          const v = at(b, x + dx, y + dy);
          if (v === 1 || v === 2) near = true;
        }
      }
      if (near) out.push([x, y]);
    }
  }
  if (!any) return [[7, 7]];
  return out;
}

function isLegal(b: Board, x: number, y: number, c: Color) {
  if (c !== 1) return true;
  b[y * SIZE + x] = 1;
  const foul = blackFoul(b, x, y);
  b[y * SIZE + x] = 0;
  return foul === null;
}

function wins(b: Board, x: number, y: number, c: Color) {
  b[y * SIZE + x] = c;
  const w = makesFive(b, x, y, c);
  b[y * SIZE + x] = 0;
  return w;
}

type Scored = { m: Move; s: number };

function scoreMoves(b: Board, me: Color, defenseWeight: number): Scored[] {
  const opp: Color = me === 1 ? 2 : 1;
  const list: Scored[] = [];
  for (const [x, y] of candidates(b)) {
    if (!isLegal(b, x, y, me)) continue;
    const s = evaluatePoint(b, x, y, me) + evaluatePoint(b, x, y, opp) * defenseWeight;
    list.push({ m: [x, y], s });
  }
  list.sort((a, c) => c.s - a.s);
  return list;
}

export function chooseAiMove(b: Board, me: Color, level: AiLevel, rand: () => number = Math.random): Move {
  const opp: Color = me === 1 ? 2 : 1;
  const cands = candidates(b).filter(([x, y]) => isLegal(b, x, y, me));
  const fallback: Move = cands[0] ?? [7, 7];
  if (cands.length === 0) {
    // fall back to any empty cell
    for (let i = 0; i < b.length; i++) if (b[i] === 0) return [i % SIZE, Math.floor(i / SIZE)];
  }

  // Always finish a five; always block the opponent's five (except on easy, sometimes).
  for (const [x, y] of cands) if (wins(b, x, y, me)) return [x, y];
  const blocks = cands.filter(([x, y]) => wins(b, x, y, opp));
  if (blocks[0] && (level !== "easy" || rand() < 0.75)) return blocks[0];

  if (level === "easy") {
    const list = scoreMoves(b, me, 0.5);
    const top = list.slice(0, 6);
    return top[Math.floor(rand() * top.length)]?.m ?? fallback;
  }
  if (level === "normal") {
    const list = scoreMoves(b, me, 0.85).map((it) => ({ ...it, s: it.s * (0.85 + rand() * 0.3) }));
    list.sort((a, c) => c.s - a.s);
    return list[0]?.m ?? fallback;
  }

  // hard: shallow lookahead over the top candidates
  const top = scoreMoves(b, me, 0.95).slice(0, 10);
  let best: Scored | null = null;
  for (const cand of top) {
    const [x, y] = cand.m;
    b[y * SIZE + x] = me;
    const replies = scoreMoves(b, opp, 0.9);
    const oppBest = replies[0]?.s ?? 0;
    b[y * SIZE + x] = 0;
    const value = cand.s - oppBest * 0.6;
    if (!best || value > best.s) best = { m: cand.m, s: value };
  }
  return best?.m ?? fallback;
}
