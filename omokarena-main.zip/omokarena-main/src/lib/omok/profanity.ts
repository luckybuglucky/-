// Chat profanity filter and mute rules.

const BANNED = [
  "시발", "씨발", "씨빨", "씨바", "시바", "씹", "ㅅㅂ", "ㅆㅂ", "ㅅ1ㅂ", "ㅆ1ㅂ",
  "병신", "븅신", "빙신", "ㅂㅅ", "ㅄ", "개새끼", "개새", "개색", "새끼", "ㅅㄲ",
  "좆", "존나", "졸라", "ㅈㄴ", "지랄", "ㅈㄹ", "미친", "ㅁㅊ", "닥쳐", "꺼져",
  "엠창", "느금", "니애미", "니미", "애미", "애비", "염병", "썅", "등신", "호로",
  "fuck", "fck", "shit", "bitch", "asshole", "bastard", "dick", "pussy", "cunt",
  "wtf", "stfu", "sibal", "ssibal", "tlqkf", "qudtls",
];

const SEP = "[\\s._\\-*~!@#$%^&+=0-9|/\\\\]*";

function escape(ch: string) {
  return ch.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

const REGEXES = BANNED.map((w) => new RegExp(Array.from(w).map(escape).join(SEP), "gi"));

export function censor(text: string): { text: string; flagged: boolean } {
  let out = text;
  let flagged = false;
  for (const re of REGEXES) {
    re.lastIndex = 0;
    out = out.replace(re, (m) => {
      flagged = true;
      return "*".repeat(Math.max(2, Array.from(m).length));
    });
  }
  return { text: out, flagged };
}

export const WARNINGS_PER_MUTE = 3;
export const MAX_MUTE_MINUTES = 30;

/** Minutes of chat ban triggered when the warning count reaches this value (0 = none). */
export function muteMinutesFor(warnings: number) {
  if (warnings <= 0 || warnings % WARNINGS_PER_MUTE !== 0) return 0;
  return Math.min(MAX_MUTE_MINUTES, warnings);
}

export const MAX_MESSAGE_LENGTH = 120;
