import { useEffect, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";

import { supabase } from "@/integrations/supabase/client";
import { audio, type Track } from "./audio";
import { getMe } from "./game.functions";
import { PLACEMENT_GAMES } from "./rank";

export function useMe() {
  const fn = useServerFn(getMe);
  return useQuery({
    queryKey: ["me"],
    queryFn: () => fn(),
    staleTime: 10_000,
    refetchInterval: 60_000,
  });
}

export type LeaderRow = {
  id: string;
  nickname: string;
  rating: number;
  placement_games: number;
  ranked_wins: number;
  ranked_losses: number;
  equipped_title: string | null;
  equipped_color: string | null;
};

export function useLeaderboard() {
  return useQuery({
    queryKey: ["leaderboard"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("profiles")
        .select("id, nickname, rating, placement_games, ranked_wins, ranked_losses, equipped_title, equipped_color")
        .gte("placement_games", PLACEMENT_GAMES)
        .order("rating", { ascending: false })
        .order("created_at", { ascending: true })
        .limit(100);
      if (error) throw error;
      return (data ?? []) as LeaderRow[];
    },
    staleTime: 30_000,
  });
}

/** Map of user id -> leaderboard position (1-based) for the top 10. */
export function useRankerMap() {
  const { data } = useLeaderboard();
  return useMemo(() => {
    const m = new Map<string, number>();
    (data ?? []).slice(0, 10).forEach((r, i) => m.set(r.id, i + 1));
    return m;
  }, [data]);
}

export function useMusic(track: Track | null) {
  useEffect(() => {
    audio().setTrack(track);
  }, [track]);
}

export async function nicknameToEmail(nickname: string) {
  const norm = nickname.trim().toLowerCase();
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(norm));
  const hex = Array.from(new Uint8Array(buf))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("")
    .slice(0, 32);
  return `p${hex}@omok-arena.app`;
}

export const NICKNAME_RE = /^[가-힣a-zA-Z0-9_]{2,12}$/;
