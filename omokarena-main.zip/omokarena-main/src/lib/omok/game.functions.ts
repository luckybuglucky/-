import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { chooseAiMove, type AiLevel } from "./ai";
import { ensureDeveloperItems, finishGame, type Admin, type GameRow } from "./engine";
import { censor, MAX_MESSAGE_LENGTH, muteMinutesFor } from "./profanity";
import { SHIELD_PRICE, TURN_SECONDS } from "./rank";
import { applyMove, boardFromMoves, colorToMove, inside, SIZE, type Color, type Move } from "./rules";

const modeSchema = z.enum(["ranked", "normal"]);
const idSchema = z.object({ id: z.string().uuid() });

async function admin(): Promise<Admin> {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  return supabaseAdmin;
}

export type PublicPlayer = {
  id: string;
  nickname: string;
  rating: number;
  placement_games: number;
  equipped_title: string | null;
  equipped_color: string | null;
};

export type GameState = {
  game: GameRow;
  players: { black: PublicPlayer | null; white: PublicPlayer | null };
  serverNow: number;
};

function myColor(game: GameRow, userId: string): Color | null {
  if (game.black_id === userId) return 1;
  if (game.white_id === userId) return 2;
  return null;
}

function turnExpired(game: GameRow, slackMs = 0) {
  return Date.now() - new Date(game.turn_started_at).getTime() >= TURN_SECONDS * 1000 - slackMs;
}

async function loadState(db: Admin, id: string): Promise<GameState> {
  const { data: game, error } = await db.from("games").select("*").eq("id", id).single();
  if (error || !game) throw new Error("대국을 찾을 수 없습니다.");
  const ids = [game.black_id, game.white_id].filter(Boolean) as string[];
  const { data: profiles } = await db
    .from("profiles")
    .select("id, nickname, rating, placement_games, equipped_title, equipped_color")
    .in("id", ids.length ? ids : ["00000000-0000-0000-0000-000000000000"]);
  const find = (uid: string | null) => (uid ? (profiles ?? []).find((p) => p.id === uid) ?? null : null);
  return { game, players: { black: find(game.black_id), white: find(game.white_id) }, serverNow: Date.now() };
}

async function myMmr(db: Admin, userId: string) {
  const { data } = await db.from("profiles").select("mmr").eq("id", userId).single();
  return data?.mmr ?? 600;
}

async function resolveStaleGames(db: Admin, userId: string) {
  const { data: games } = await db
    .from("games")
    .select("*")
    .eq("status", "active")
    .or(`black_id.eq.${userId},white_id.eq.${userId}`);
  let active: string | null = null;
  for (const g of games ?? []) {
    if (turnExpired(g, -2000)) {
      await finishGame(db, g, colorToMove(g.move_count) === 1 ? 2 : 1, "timeout");
    } else {
      active = g.id;
    }
  }
  return active;
}

export const getMe = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const db = await admin();
    const activeGameId = await resolveStaleGames(db, context.userId);
    const { data: profile } = await db
      .from("profiles")
      .update({ last_seen_at: new Date().toISOString() })
      .eq("id", context.userId)
      .select("*")
      .single();
    if (!profile) throw new Error("프로필을 찾을 수 없습니다.");
    const [{ data: isAdmin }, { data: isDev }] = await Promise.all([
      context.supabase.rpc("has_role", { _user_id: context.userId, _role: "admin" }),
      context.supabase.rpc("has_role", { _user_id: context.userId, _role: "developer" }),
    ]);
    if (isDev) await ensureDeveloperItems(db, context.userId);
    const kicked = !!profile.kicked_until && new Date(profile.kicked_until).getTime() > Date.now();
    return { profile, activeGameId, isAdmin: !!isAdmin, kicked };
  });

export const startAiGame = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z.object({ mode: modeSchema, level: z.enum(["easy", "normal", "hard"]) }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const db = await admin();
    const active = await resolveStaleGames(db, context.userId);
    if (active) return { gameId: active };
    await db.from("match_queue").delete().eq("user_id", context.userId);
    const level: AiLevel = data.level;
    const playerIsBlack = Math.random() < 0.5;
    const moves: Move[] = playerIsBlack ? [] : [[7, 7]];
    const { data: game, error } = await db
      .from("games")
      .insert({
        mode: data.mode,
        vs_ai: true,
        ai_level: level,
        black_id: playerIsBlack ? context.userId : null,
        white_id: playerIsBlack ? null : context.userId,
        moves: moves as never,
        move_count: moves.length,
      })
      .select("id")
      .single();
    if (error || !game) throw new Error("대국을 만들 수 없습니다.");
    return { gameId: game.id };
  });

export const joinQueue = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ mode: modeSchema }).parse(input))
  .handler(async ({ data, context }) => {
    const db = await admin();
    const active = await resolveStaleGames(db, context.userId);
    if (active) return { gameId: active };
    const now = new Date().toISOString();
    await db
      .from("match_queue")
      .upsert({ user_id: context.userId, mode: data.mode, created_at: now, heartbeat_at: now, mmr: await myMmr(db, context.userId) });
    const { data: gameId } = await db.rpc("try_match", { _user: context.userId, _mode: data.mode });
    return { gameId: (gameId as string | null) ?? null };
  });

export const pollQueue = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ mode: modeSchema }).parse(input))
  .handler(async ({ data, context }) => {
    const db = await admin();
    const { data: games } = await db
      .from("games")
      .select("id")
      .eq("status", "active")
      .eq("vs_ai", false)
      .or(`black_id.eq.${context.userId},white_id.eq.${context.userId}`)
      .limit(1);
    if (games && games[0]) return { gameId: games[0].id };
    const { data: row } = await db.from("match_queue").select("user_id").eq("user_id", context.userId).maybeSingle();
    if (!row) {
      const now = new Date().toISOString();
      await db
        .from("match_queue")
        .upsert({ user_id: context.userId, mode: data.mode, created_at: now, heartbeat_at: now, mmr: await myMmr(db, context.userId) });
    }
    const { data: gameId } = await db.rpc("try_match", { _user: context.userId, _mode: data.mode });
    return { gameId: (gameId as string | null) ?? null };
  });

export const leaveQueue = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const db = await admin();
    await db.from("match_queue").delete().eq("user_id", context.userId);
    return { ok: true };
  });

export const getGame = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => idSchema.parse(input))
  .handler(async ({ data, context }) => {
    const db = await admin();
    const state = await loadState(db, data.id);
    if (!myColor(state.game, context.userId)) {
      // Admins may spectate any game.
      const { data: isAdmin } = await context.supabase.rpc("has_role", { _user_id: context.userId, _role: "admin" });
      if (!isAdmin) throw new Error("참여 중인 대국이 아닙니다.");
    }
    return state;
  });

export const playMove = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z.object({ id: z.string().uuid(), x: z.number().int(), y: z.number().int() }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const db = await admin();
    const { data: game } = await db.from("games").select("*").eq("id", data.id).single();
    if (!game) throw new Error("대국을 찾을 수 없습니다.");
    const me = myColor(game, context.userId);
    if (!me) throw new Error("참여 중인 대국이 아닙니다.");
    if (game.status !== "active") return loadState(db, game.id);
    if (colorToMove(game.move_count) !== me) throw new Error("상대의 차례입니다.");
    if (game.paused_until && new Date(game.paused_until).getTime() > Date.now()) throw new Error("대국이 일시정지되었습니다.");
    if (turnExpired(game, -1500)) {
      await finishGame(db, game, me === 1 ? 2 : 1, "timeout");
      return loadState(db, game.id);
    }
    if (!inside(data.x, data.y)) throw new Error("잘못된 위치입니다.");

    const moves = (game.moves as unknown as Move[]) ?? [];
    const board = boardFromMoves(moves);
    if (board[data.y * SIZE + data.x] !== 0) throw new Error("이미 돌이 있는 자리입니다.");

    let current = game;
    let list: Move[] = [...moves, [data.x, data.y]];
    let outcome = applyMove(board, data.x, data.y, me, list.length);

    const commit = async (prevCount: number, next: Move[]) => {
      const { data: updated } = await db
        .from("games")
        .update({ moves: next as never, move_count: next.length, turn_started_at: new Date().toISOString() })
        .eq("id", game.id)
        .eq("status", "active")
        .eq("move_count", prevCount)
        .select("*")
        .maybeSingle();
      if (!updated) throw new Error("수를 반영하지 못했습니다. 다시 시도해 주세요.");
      return updated;
    };

    current = await commit(moves.length, list);

    if (outcome.kind === "continue" && game.vs_ai) {
      const aiColor: Color = me === 1 ? 2 : 1;
      const [ax, ay] = chooseAiMove(board, aiColor, (game.ai_level as AiLevel) ?? "normal");
      const prev = list.length;
      list = [...list, [ax, ay]];
      outcome = applyMove(board, ax, ay, aiColor, list.length);
      current = await commit(prev, list);
    }

    if (outcome.kind === "win") await finishGame(db, current, outcome.winner, "five");
    else if (outcome.kind === "foul") await finishGame(db, current, outcome.winner, "foul", { foul: outcome.foul });
    else if (outcome.kind === "draw") await finishGame(db, current, null, "draw");

    return loadState(db, game.id);
  });

export const claimTimeout = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => idSchema.parse(input))
  .handler(async ({ data, context }) => {
    const db = await admin();
    const { data: game } = await db.from("games").select("*").eq("id", data.id).single();
    if (!game || !myColor(game, context.userId)) throw new Error("참여 중인 대국이 아닙니다.");
    if (game.status === "active" && turnExpired(game, 500)) {
      await finishGame(db, game, colorToMove(game.move_count) === 1 ? 2 : 1, "timeout");
    }
    return loadState(db, game.id);
  });

export const leaveGame = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => idSchema.parse(input))
  .handler(async ({ data, context }) => {
    const db = await admin();
    const { data: game } = await db.from("games").select("*").eq("id", data.id).single();
    const me = game ? myColor(game, context.userId) : null;
    if (!game || !me) throw new Error("참여 중인 대국이 아닙니다.");
    if (game.status === "active") {
      await finishGame(db, game, me === 1 ? 2 : 1, "leave", { leaverId: context.userId });
    }
    return loadState(db, game.id);
  });

export const sendMessage = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z.object({ id: z.string().uuid(), content: z.string().min(1).max(500) }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const db = await admin();
    const { data: game } = await db.from("games").select("*").eq("id", data.id).single();
    if (!game || !myColor(game, context.userId)) throw new Error("참여 중인 대국이 아닙니다.");
    if (game.vs_ai) throw new Error("AI 대국에서는 채팅을 사용할 수 없습니다.");
    const { data: p } = await db.from("profiles").select("*").eq("id", context.userId).single();
    if (!p) throw new Error("프로필을 찾을 수 없습니다.");
    if (p.muted_until && new Date(p.muted_until).getTime() > Date.now()) {
      return { sent: false, warned: false, warnings: p.chat_warnings, mutedUntil: p.muted_until };
    }
    const text = data.content.trim().slice(0, MAX_MESSAGE_LENGTH);
    if (!text) return { sent: false, warned: false, warnings: p.chat_warnings, mutedUntil: null };
    const { text: clean, flagged } = censor(text);
    let warnings = p.chat_warnings;
    let mutedUntil: string | null = null;
    if (flagged) {
      warnings += 1;
      const mins = muteMinutesFor(warnings);
      if (mins > 0) mutedUntil = new Date(Date.now() + mins * 60_000).toISOString();
      await db
        .from("profiles")
        .update({ chat_warnings: warnings, ...(mutedUntil ? { muted_until: mutedUntil } : {}) })
        .eq("id", context.userId);
    }
    await db.from("game_messages").insert({ game_id: game.id, user_id: context.userId, content: clean, censored: flagged });
    return { sent: true, warned: flagged, warnings, mutedUntil };
  });

export const buyShield = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const db = await admin();
    const { data: p } = await db.from("profiles").select("bp, shields").eq("id", context.userId).single();
    if (!p) throw new Error("프로필을 찾을 수 없습니다.");
    if (p.bp < SHIELD_PRICE) throw new Error(`BP가 부족합니다. (${p.bp} / ${SHIELD_PRICE})`);
    const { data: updated } = await db
      .from("profiles")
      .update({ bp: p.bp - SHIELD_PRICE, shields: p.shields + 1 })
      .eq("id", context.userId)
      .eq("bp", p.bp)
      .select("bp, shields")
      .maybeSingle();
    if (!updated) throw new Error("구매에 실패했습니다. 다시 시도해 주세요.");
    return updated;
  });
