// Daily shop: 4 random items per player per day (Korea time), deterministic so
// the server can re-check a purchase without storing the roll.
import { SHOP_ITEMS, type Rarity, type ShopItem } from "./cosmetics";

export const SHOP_SLOTS = 4;
/** Chance that a day's shop contains one secret item (태극 / 잭팟). */
export const SECRET_DAILY_CHANCE = 0.05;
const RARITY_WEIGHTS: [Exclude<Rarity, "secret">, number][] = [
  ["rare", 45],
  ["super", 28],
  ["epic", 17],
  ["legendary", 10],
];
const KST_OFFSET_MS = 9 * 3600_000;

export function shopDateKey(now = Date.now()) {
  return new Date(now + KST_OFFSET_MS).toISOString().slice(0, 10);
}

export function nextShopReset(now = Date.now()) {
  const kst = now + KST_OFFSET_MS;
  return Math.floor(kst / 86_400_000) * 86_400_000 + 86_400_000 - KST_OFFSET_MS;
}

function hash(s: string) {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

function rng(seed: number) {
  let a = seed;
  return () => {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function dailyShop(userId: string, dateKey: string): ShopItem[] {
  const rand = rng(hash(`${userId}:${dateKey}`));
  const withSecret = rand() < SECRET_DAILY_CHANCE;
  const picked: ShopItem[] = [];
  const total = RARITY_WEIGHTS.reduce((s, [, w]) => s + w, 0);
  let guard = 0;
  while (picked.length < SHOP_SLOTS && guard++ < 200) {
    let r = rand() * total;
    let rarity: Rarity = "rare";
    for (const [k, w] of RARITY_WEIGHTS) {
      if ((r -= w) < 0) {
        rarity = k;
        break;
      }
    }
    const pool = SHOP_ITEMS.filter((i) => i.rarity === rarity && !picked.some((p) => p.key === i.key));
    if (pool.length) picked.push(pool[Math.floor(rand() * pool.length)]!);
  }
  if (withSecret) {
    const secrets = SHOP_ITEMS.filter((i) => i.rarity === "secret");
    picked[Math.floor(rand() * SHOP_SLOTS)] = secrets[Math.floor(rand() * secrets.length)]!;
  }
  return picked;
}
