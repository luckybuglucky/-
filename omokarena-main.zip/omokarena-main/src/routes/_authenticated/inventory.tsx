import { useEffect, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Check, Loader2 } from "lucide-react";
import { toast } from "sonner";

import { AppShell } from "@/components/omok/AppShell";
import { PlayerName, TitleBadge, tierClass } from "@/components/omok/PlayerName";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { colorLabel, LOSS_STREAK_FOR_TITLE, LOSS_STREAK_TITLE, WIN_STREAK_FOR_TITLE, WIN_STREAK_TITLE } from "@/lib/omok/cosmetics";
import { useMe, useRankerMap } from "@/lib/omok/hooks";
import { equipCosmetics, getInventory } from "@/lib/omok/social.functions";

export const Route = createFileRoute("/_authenticated/inventory")({
  head: () => ({
    meta: [
      { title: "인벤토리 · Omok Arena" },
      { name: "description", content: "보유한 칭호와 닉네임 색상을 골라 장착하세요." },
      { property: "og:title", content: "인벤토리 · Omok Arena" },
      { property: "og:description", content: "보유한 칭호와 닉네임 색상을 골라 장착하세요." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Inventory,
});

function Inventory() {
  const { data: me } = useMe();
  const rankers = useRankerMap();
  const qc = useQueryClient();
  const fetchInv = useServerFn(getInventory);
  const equip = useServerFn(equipCosmetics);
  const { data: inv, isLoading } = useQuery({ queryKey: ["inventory"], queryFn: () => fetchInv() });
  const [title, setTitle] = useState<string | null>(null);
  const [color, setColor] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (inv) {
      setTitle(inv.equippedTitle);
      setColor(inv.equippedColor);
    }
  }, [inv]);

  const p = me?.profile;
  const dirty = inv && (title !== inv.equippedTitle || color !== inv.equippedColor);

  async function save() {
    setBusy(true);
    try {
      await equip({ data: { title, color } });
      toast.success("장착했습니다.");
      await Promise.all([qc.invalidateQueries({ queryKey: ["inventory"] }), qc.invalidateQueries({ queryKey: ["me"] }), qc.invalidateQueries({ queryKey: ["leaderboard"] })]);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "장착할 수 없습니다.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <AppShell>
      <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="label-caps">Inventory</p>
          <h1 className="mt-1 text-2xl font-bold">인벤토리</h1>
        </div>
        <Button onClick={save} disabled={!dirty || busy}>
          {busy && <Loader2 className="size-4 animate-spin" />}
          장착하기
        </Button>
      </div>

      {p && (
        <div className="panel mb-6 flex items-center justify-center p-6">
          <PlayerName nickname={p.nickname} rating={p.rating} placementGames={p.placement_games} position={rankers.get(p.id)} title={title} color={color} className="text-2xl" />
        </div>
      )}

      {isLoading || !inv ? (
        <Loader2 className="mx-auto my-16 size-6 animate-spin text-muted-foreground" />
      ) : (
        <div className="grid gap-6 lg:grid-cols-2">
          <section className="panel p-5">
            <p className="label-caps">칭호 · {inv.titles.length}</p>
            <div className="mt-4 grid gap-2 sm:grid-cols-2">
              <Option active={title === null} onClick={() => setTitle(null)}>
                <span className="text-sm text-muted-foreground">칭호 없음</span>
              </Option>
              {inv.titles.map((t) => (
                <Option key={t} active={title === t} onClick={() => setTitle(t)}>
                  <TitleBadge title={t} className="text-xs" />
                </Option>
              ))}
            </div>
            {inv.titles.length === 0 && (
              <p className="mt-4 text-xs text-muted-foreground">
                {WIN_STREAK_FOR_TITLE}연승 시 '{WIN_STREAK_TITLE}', {LOSS_STREAK_FOR_TITLE}연패 시 '{LOSS_STREAK_TITLE}' 칭호를 받을 수 있습니다.
              </p>
            )}
          </section>

          <section className="panel p-5">
            <p className="label-caps">닉네임 색상 · {inv.colors.length}</p>
            <div className="mt-4 grid gap-2 sm:grid-cols-2">
              <Option active={color === null} onClick={() => setColor(null)}>
                <span className={cn("text-sm font-semibold", p ? tierClass(p.rating, p.placement_games) : "")}>티어 색상 (기본)</span>
              </Option>
              {inv.colors.map((c) => (
                <Option key={c} active={color === c} onClick={() => setColor(c)}>
                  <span className={cn("text-sm font-semibold", `nick-c-${c}`)}>{colorLabel(c)}</span>
                </Option>
              ))}
            </div>
            {inv.colors.length === 0 && <p className="mt-4 text-xs text-muted-foreground">아직 보유한 닉네임 색상이 없습니다.</p>}
          </section>
        </div>
      )}
    </AppShell>
  );
}

function Option({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "flex items-center justify-between gap-2 rounded-lg border px-3 py-3 text-left transition-colors",
        active ? "border-primary bg-primary/10" : "border-border bg-secondary/40 hover:border-muted-foreground/40",
      )}
    >
      {children}
      {active && <Check className="size-4 shrink-0 text-primary" />}
    </button>
  );
}
