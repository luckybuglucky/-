import { useEffect, useRef, useState } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { Bot, Coins, Handshake, Loader2, Shield, Swords, Trophy, Users } from "lucide-react";
import { toast } from "sonner";

import { AppShell } from "@/components/omok/AppShell";
import { PlayerName } from "@/components/omok/PlayerName";
import { RankEmblem, RpBar, rankLabel } from "@/components/omok/RankBadge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";
import { audio } from "@/lib/omok/audio";
import { joinQueue, leaveQueue, pollQueue, startAiGame } from "@/lib/omok/game.functions";
import { cancelInvite, inviteStatus, sendInvite } from "@/lib/omok/social.functions";
import { useLeaderboard, useMe, useRankerMap } from "@/lib/omok/hooks";
import { PLACEMENT_GAMES } from "@/lib/omok/rank";

export const Route = createFileRoute("/_authenticated/lobby")({
  head: () => ({
    meta: [
      { title: "로비 · Omok Arena" },
      { name: "description", content: "경쟁전과 일반전, AI 또는 플레이어와의 대국을 시작하세요." },
      { property: "og:title", content: "로비 · Omok Arena" },
      { property: "og:description", content: "경쟁전과 일반전, AI 또는 플레이어와의 대국을 시작하세요." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  validateSearch: (s: Record<string, unknown>): { friend?: string } =>
    typeof s["friend"] === "string" ? { friend: s["friend"] } : {},
  component: Lobby,
});

type Mode = "ranked" | "normal";
type Opp = "random" | "friendly" | "ai";
type Level = "easy" | "normal" | "hard";

function Lobby() {
  const { data, isLoading } = useMe();
  const rankers = useRankerMap();
  const { data: board } = useLeaderboard();
  const navigate = useNavigate();
  const [mode, setMode] = useState<Mode>("ranked");
  const search = Route.useSearch();
  const [opp, setOpp] = useState<Opp>(search.friend ? "friendly" : "random");
  const [friendNick, setFriendNick] = useState(search.friend ?? "");
  const [invite, setInvite] = useState<{ id: string; nickname: string } | null>(null);
  const [level, setLevel] = useState<Level>("normal");
  const [searching, setSearching] = useState(false);
  const [busy, setBusy] = useState(false);
  const [elapsed, setElapsed] = useState(0);
  const searchingRef = useRef(false);

  const startAi = useServerFn(startAiGame);
  const join = useServerFn(joinQueue);
  const poll = useServerFn(pollQueue);
  const leave = useServerFn(leaveQueue);
  const invitefn = useServerFn(sendInvite);
  const statusFn = useServerFn(inviteStatus);
  const cancelInv = useServerFn(cancelInvite);

  useEffect(() => {
    if (!invite) return;
    const started = Date.now();
    let done = false;
    const clock = window.setInterval(() => setElapsed(Math.floor((Date.now() - started) / 1000)), 500);
    const iv = window.setInterval(async () => {
      if (done) return;
      try {
        const r = await statusFn({ data: { id: invite.id } });
        if (r.status === "accepted" && r.gameId) {
          done = true;
          setInvite(null);
          found(r.gameId);
        } else if (r.status !== "pending") {
          done = true;
          setInvite(null);
          toast(r.status === "declined" ? `${invite.nickname}님이 신청을 거절했습니다.` : "응답이 없어 신청이 만료되었습니다.");
        }
      } catch {
        /* keep trying */
      }
    }, 1500);
    return () => {
      done = true;
      window.clearInterval(iv);
      window.clearInterval(clock);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [invite]);

  async function cancelFriendly() {
    if (!invite) return;
    const id = invite.id;
    setInvite(null);
    await cancelInv({ data: { id } }).catch(() => undefined);
  }

  useEffect(() => {
    if (!searching) return;
    searchingRef.current = true;
    const started = Date.now();
    const clock = window.setInterval(() => setElapsed(Math.floor((Date.now() - started) / 1000)), 500);
    const iv = window.setInterval(async () => {
      if (!searchingRef.current) return;
      try {
        const r = await poll({ data: { mode } });
        if (r.gameId && searchingRef.current) found(r.gameId);
      } catch {
        /* keep trying */
      }
    }, 2000);
    return () => {
      window.clearInterval(iv);
      window.clearInterval(clock);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [searching, mode]);

  useEffect(
    () => () => {
      if (searchingRef.current) void leave();
    },
    [leave],
  );

  function found(gameId: string) {
    searchingRef.current = false;
    setSearching(false);
    audio().chime("match");
    navigate({ to: "/game/$gameId", params: { gameId } });
  }

  async function start() {
    setBusy(true);
    try {
      if (opp === "friendly") {
        const r = await invitefn({ data: { nickname: friendNick.trim() } });
        setElapsed(0);
        setInvite({ id: r.inviteId, nickname: r.nickname });
        return;
      }
      if (opp === "ai") {
        const r = await startAi({ data: { mode, level } });
        navigate({ to: "/game/$gameId", params: { gameId: r.gameId } });
        return;
      }
      const r = await join({ data: { mode } });
      if (r.gameId) found(r.gameId);
      else {
        setElapsed(0);
        setSearching(true);
      }
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "대국을 시작할 수 없습니다.");
    } finally {
      setBusy(false);
    }
  }

  async function cancel() {
    searchingRef.current = false;
    setSearching(false);
    await leave();
  }

  const p = data?.profile;

  return (
    <AppShell>
      {data?.activeGameId && (
        <div className="panel mb-6 flex items-center justify-between gap-4 border-primary/40 p-4">
          <p className="text-sm">진행 중인 대국이 있습니다. 1분 안에 돌아가지 않으면 시간패 처리됩니다.</p>
          <Button size="sm" onClick={() => navigate({ to: "/game/$gameId", params: { gameId: data.activeGameId! } })}>
            대국으로 돌아가기
          </Button>
        </div>
      )}

      <div className="grid gap-6 lg:grid-cols-[320px_1fr_280px]">
        {/* Profile */}
        <section className="panel flex flex-col items-center p-6 text-center">
          {isLoading || !p ? (
            <Loader2 className="my-20 size-6 animate-spin text-muted-foreground" />
          ) : (
            <>
              <RankEmblem rating={p.rating} placementGames={p.placement_games} size={150} animated />
              <PlayerName
                nickname={p.nickname}
                rating={p.rating}
                placementGames={p.placement_games}
                position={rankers.get(p.id)}
                title={p.equipped_title}
                color={p.equipped_color}
                className="mt-4 justify-center text-xl"
              />
              <p className="mt-1 font-display text-lg font-semibold tracking-wider text-muted-foreground">
                {rankLabel(p.rating, p.placement_games)}
              </p>
              <div className="mt-5 w-full">
                <RpBar rating={p.rating} placementGames={p.placement_games} />
              </div>
              <div className="mt-6 grid w-full grid-cols-3 gap-2 text-center">
                <Stat label="승" value={p.wins} />
                <Stat label="패" value={p.losses} />
                <Stat label="승률" value={p.wins + p.losses ? `${Math.round((p.wins / (p.wins + p.losses)) * 100)}%` : "-"} />
              </div>
              <div className="mt-3 grid w-full grid-cols-2 gap-2">
                <div className="flex items-center justify-center gap-1.5 rounded-md bg-secondary py-2 text-sm">
                  <Coins className="size-4 text-primary" /> <span className="font-display font-semibold">{p.bp}</span> BP
                </div>
                <div className="flex items-center justify-center gap-1.5 rounded-md bg-secondary py-2 text-sm">
                  <Shield className="size-4 text-primary" /> 방어권 <span className="font-display font-semibold">{p.shields}</span>
                </div>
              </div>
              {p.placement_games < PLACEMENT_GAMES && (
                <p className="mt-4 text-xs text-muted-foreground">
                  경쟁전 {PLACEMENT_GAMES}판을 마치면 성과 점수로 첫 티어가 정해집니다.
                </p>
              )}
            </>
          )}
        </section>

        {/* Play */}
        <section className="panel p-6">
          <p className="label-caps">Match Type</p>
          <div className="mt-3 grid grid-cols-3 gap-2 sm:gap-3">
            <Choice active={opp === "random"} onClick={() => setOpp("random")} icon={<Users className="size-5" />} title="랜덤 대국" desc="실력이 비슷한 상대와 매칭" />
            <Choice active={opp === "friendly"} onClick={() => setOpp("friendly")} icon={<Handshake className="size-5" />} title="친선 대국" desc="닉네임으로 신청" />
            <Choice active={opp === "ai"} onClick={() => setOpp("ai")} icon={<Bot className="size-5" />} title="AI 대국" desc="난이도 선택" />
          </div>

          {opp !== "friendly" && (
            <>
              <p className="label-caps mt-7">Game Mode</p>
              <div className="mt-3 grid grid-cols-2 gap-3">
                <Choice active={mode === "ranked"} onClick={() => setMode("ranked")} icon={<Trophy className="size-5" />} title="경쟁전" desc="RP와 티어가 걸린 대국" />
                <Choice active={mode === "normal"} onClick={() => setMode("normal")} icon={<Swords className="size-5" />} title="일반전" desc="부담 없이 즐기는 대국" />
              </div>
            </>
          )}

          {opp === "ai" && (
            <div className="mt-4">
              <div className="flex gap-2">
                {(["easy", "normal", "hard"] as Level[]).map((l) => (
                  <Button key={l} variant={level === l ? "default" : "secondary"} size="sm" onClick={() => setLevel(l)}>
                    {l === "easy" ? "1단계 · 입문" : l === "normal" ? "2단계 · 중급" : "3단계 · 고수"}
                  </Button>
                ))}
              </div>
              {level !== "hard" && (
                <p className="mt-2 text-xs text-muted-foreground">입문·중급 AI는 승리 보상(RP·BP·성과 점수)이 적습니다.</p>
              )}
            </div>
          )}

          {opp === "friendly" && (
            <div className="mt-6 space-y-2">
              <p className="label-caps">Opponent Nickname</p>
              <Input
                value={friendNick}
                onChange={(e) => setFriendNick(e.target.value)}
                placeholder="상대 닉네임 입력"
                maxLength={12}
                disabled={!!invite}
                onKeyDown={(e) => e.key === "Enter" && start()}
              />
              <p className="text-xs text-muted-foreground">친선 대국은 RP·BP·전적에 반영되지 않습니다.</p>
            </div>
          )}

          <div className="mt-8">
            {searching || invite ? (
              <div className="flex items-center justify-between gap-4 rounded-lg border border-primary/40 bg-primary/5 p-4">
                <div className="flex items-center gap-3">
                  <Loader2 className="size-5 animate-spin text-primary" />
                  <div>
                    <p className="text-sm font-medium">{invite ? `${invite.nickname}님의 응답을 기다리는 중…` : "상대를 찾는 중…"}</p>
                    <p className="font-display text-xs tracking-wider text-muted-foreground">
                      {String(Math.floor(elapsed / 60)).padStart(2, "0")}:{String(elapsed % 60).padStart(2, "0")}
                    </p>
                  </div>
                </div>
                <Button variant="secondary" onClick={invite ? cancelFriendly : cancel}>
                  취소
                </Button>
              </div>
            ) : (
              <Button
                className="h-14 w-full text-base"
                onClick={start}
                disabled={busy || !!data?.activeGameId || (opp === "friendly" && !friendNick.trim())}
              >
                {busy && <Loader2 className="size-4 animate-spin" />}
                {opp === "friendly" ? "친선 대국 신청" : `${mode === "ranked" ? "경쟁전" : "일반전"} 시작`}
              </Button>
            )}
          </div>

          <ul className="mt-6 space-y-1.5 text-xs text-muted-foreground">
            <li>· 흑의 3-3, 4-4, 6목 이상은 반칙패입니다.</li>
            <li>· 한 수에 1분이 넘으면 시간패, 대국을 나가면 패배와 함께 RP가 소량 차감됩니다.</li>
            <li>· 승리 시 1~5 BP를 획득합니다. 연승할수록 더 강한 상대와 매칭됩니다.</li>
          </ul>
        </section>

        {/* Top players */}
        <section className="panel p-5">
          <div className="flex items-center justify-between">
            <p className="label-caps">Top Players</p>
            <Link to="/leaderboard" className="text-xs text-muted-foreground hover:text-foreground">
              전체 보기
            </Link>
          </div>
          <ol className="mt-4 space-y-2.5">
            {(board ?? []).slice(0, 8).map((r, i) => (
              <li key={r.id} className="flex items-center gap-2.5">
                <span className="w-5 font-display text-sm font-semibold text-muted-foreground">{i + 1}</span>
                <RankEmblem rating={r.rating} placementGames={r.placement_games} size={26} />
                <PlayerName nickname={r.nickname} rating={r.rating} placementGames={r.placement_games} position={i + 1} color={r.equipped_color} showTitle={false} className="text-sm" />
                <span className="ml-auto font-display text-xs text-muted-foreground">{r.rating}</span>
              </li>
            ))}
            {board && board.length === 0 && <li className="text-sm text-muted-foreground">아직 배치를 마친 플레이어가 없습니다.</li>}
          </ol>
        </section>
      </div>
    </AppShell>
  );
}

function Stat({ label, value }: { label: string; value: string | number }) {
  return (
    <div className="rounded-md bg-secondary py-2">
      <div className="font-display text-lg font-semibold">{value}</div>
      <div className="text-xs text-muted-foreground">{label}</div>
    </div>
  );
}

function Choice({ active, onClick, icon, title, desc }: { active: boolean; onClick: () => void; icon: React.ReactNode; title: string; desc: string }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "flex flex-col items-start gap-2 rounded-lg border p-3 text-left transition-colors sm:p-4",
        active ? "border-primary bg-primary/10" : "border-border bg-secondary/40 hover:border-muted-foreground/40",
      )}
    >
      <span className={active ? "text-primary" : "text-muted-foreground"}>{icon}</span>
      <span className="font-semibold">{title}</span>
      <span className="hidden text-xs text-muted-foreground sm:block">{desc}</span>
    </button>
  );
}
