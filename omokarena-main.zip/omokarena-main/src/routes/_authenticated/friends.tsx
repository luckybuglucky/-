import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Check, Handshake, Loader2, UserPlus, X } from "lucide-react";
import { toast } from "sonner";

import { AppShell } from "@/components/omok/AppShell";
import { PlayerName } from "@/components/omok/PlayerName";
import { RankEmblem, rankLabel } from "@/components/omok/RankBadge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { supabase } from "@/integrations/supabase/client";
import { cn } from "@/lib/utils";
import { useMe, useRankerMap } from "@/lib/omok/hooks";

export const Route = createFileRoute("/_authenticated/friends")({
  head: () => ({
    meta: [
      { title: "친구 · Omok Arena" },
      { name: "description", content: "닉네임으로 친구를 추가하고 함께 대국하세요." },
      { property: "og:title", content: "친구 · Omok Arena" },
      { property: "og:description", content: "닉네임으로 친구를 추가하고 함께 대국하세요." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Friends,
});

type P = { id: string; nickname: string; rating: number; placement_games: number; last_seen_at: string; equipped_title: string | null; equipped_color: string | null };
type Row = { id: string; status: string; requester_id: string; addressee_id: string; requester: P; addressee: P };

const COLS = "id, nickname, rating, placement_games, last_seen_at, equipped_title, equipped_color";

function Friends() {
  const { data: me } = useMe();
  const myId = me?.profile.id;
  const rankers = useRankerMap();
  const qc = useQueryClient();
  const [nick, setNick] = useState("");
  const [busy, setBusy] = useState(false);

  const { data: rows, isLoading } = useQuery({
    queryKey: ["friends", myId],
    enabled: !!myId,
    refetchInterval: 15_000,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("friendships")
        .select(`id, status, requester_id, addressee_id, requester:profiles!friendships_requester_id_fkey(${COLS}), addressee:profiles!friendships_addressee_id_fkey(${COLS})`)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as unknown as Row[];
    },
  });

  const refresh = () => qc.invalidateQueries({ queryKey: ["friends", myId] });

  async function add(e: React.FormEvent) {
    e.preventDefault();
    const name = nick.trim();
    if (!name || !myId) return;
    setBusy(true);
    try {
      const { data: target } = await supabase
        .from("profiles")
        .select("id, nickname")
        .ilike("nickname", name.replace(/[%_]/g, (m) => `\\${m}`))
        .maybeSingle();
      if (!target) return void toast.error("해당 닉네임의 플레이어를 찾을 수 없습니다.");
      if (target.id === myId) return void toast.error("자기 자신은 추가할 수 없습니다.");
      const { error } = await supabase.from("friendships").insert({ requester_id: myId, addressee_id: target.id });
      if (error) return void toast.error(error.code === "23505" ? "이미 친구이거나 요청을 보냈습니다." : "요청을 보낼 수 없습니다.");
      toast.success(`${target.nickname}님에게 친구 요청을 보냈습니다.`);
      setNick("");
      refresh();
    } finally {
      setBusy(false);
    }
  }

  async function accept(id: string) {
    const { error } = await supabase.from("friendships").update({ status: "accepted" }).eq("id", id);
    if (error) toast.error("수락할 수 없습니다.");
    refresh();
  }

  async function remove(id: string) {
    await supabase.from("friendships").delete().eq("id", id);
    refresh();
  }

  const friends = (rows ?? []).filter((r) => r.status === "accepted");
  const incoming = (rows ?? []).filter((r) => r.status === "pending" && r.addressee_id === myId);
  const outgoing = (rows ?? []).filter((r) => r.status === "pending" && r.requester_id === myId);
  const other = (r: Row) => (r.requester_id === myId ? r.addressee : r.requester);
  const online = (p: P) => Date.now() - new Date(p.last_seen_at).getTime() < 3 * 60_000;

  return (
    <AppShell>
      <div className="mb-6">
        <p className="label-caps">Friends</p>
        <h1 className="mt-1 text-2xl font-bold">친구</h1>
      </div>

      <div className="grid gap-6 lg:grid-cols-[1fr_340px]">
        <section className="panel p-5">
          <div className="flex items-center justify-between">
            <p className="label-caps">친구 목록 · {friends.length}</p>
          </div>
          {isLoading ? (
            <Loader2 className="mx-auto my-12 size-5 animate-spin text-muted-foreground" />
          ) : friends.length === 0 ? (
            <p className="py-12 text-center text-sm text-muted-foreground">아직 친구가 없습니다. 닉네임으로 추가해 보세요.</p>
          ) : (
            <ul className="mt-3 divide-y divide-border/60">
              {friends
                .map((r) => ({ r, p: other(r) }))
                .sort((a, b) => Number(online(b.p)) - Number(online(a.p)))
                .map(({ r, p }) => (
                  <li key={r.id} className="flex items-center gap-3 py-3">
                    <RankEmblem rating={p.rating} placementGames={p.placement_games} size={36} />
                    <div className="min-w-0 flex-1">
                      <PlayerName nickname={p.nickname} rating={p.rating} placementGames={p.placement_games} position={rankers.get(p.id)} title={p.equipped_title} color={p.equipped_color} />
                      <p className="text-xs text-muted-foreground">{rankLabel(p.rating, p.placement_games)}</p>
                    </div>
                    <span className={cn("flex items-center gap-1.5 text-xs", online(p) ? "text-success" : "text-muted-foreground")}>
                      <span className={cn("size-2 rounded-full", online(p) ? "bg-success" : "bg-muted-foreground/40")} />
                      {online(p) ? "온라인" : "오프라인"}
                    </span>
                    <Button asChild variant="secondary" size="sm">
                      <Link to="/lobby" search={{ friend: p.nickname }}>
                        <Handshake className="size-4" /> 대국
                      </Link>
                    </Button>
                    <Button variant="ghost" size="icon" onClick={() => remove(r.id)} aria-label="친구 삭제">
                      <X className="size-4" />
                    </Button>
                  </li>
                ))}
            </ul>
          )}
        </section>

        <div className="flex flex-col gap-6">
          <section className="panel p-5">
            <p className="label-caps">친구 추가</p>
            <form onSubmit={add} className="mt-3 flex gap-2">
              <Input value={nick} onChange={(e) => setNick(e.target.value)} placeholder="닉네임" maxLength={12} />
              <Button type="submit" disabled={busy || !nick.trim()}>
                {busy ? <Loader2 className="size-4 animate-spin" /> : <UserPlus className="size-4" />}
                추가
              </Button>
            </form>
          </section>

          <section className="panel p-5">
            <p className="label-caps">받은 요청 · {incoming.length}</p>
            <ul className="mt-3 space-y-2">
              {incoming.map((r) => (
                <li key={r.id} className="flex items-center gap-2">
                  <RankEmblem rating={r.requester.rating} placementGames={r.requester.placement_games} size={28} />
                  <PlayerName nickname={r.requester.nickname} rating={r.requester.rating} placementGames={r.requester.placement_games} color={r.requester.equipped_color} className="flex-1 text-sm" />
                  <Button size="icon" variant="secondary" onClick={() => accept(r.id)} aria-label="수락">
                    <Check className="size-4" />
                  </Button>
                  <Button size="icon" variant="ghost" onClick={() => remove(r.id)} aria-label="거절">
                    <X className="size-4" />
                  </Button>
                </li>
              ))}
              {incoming.length === 0 && <li className="text-xs text-muted-foreground">받은 요청이 없습니다.</li>}
            </ul>
          </section>

          {outgoing.length > 0 && (
            <section className="panel p-5">
              <p className="label-caps">보낸 요청 · {outgoing.length}</p>
              <ul className="mt-3 space-y-2">
                {outgoing.map((r) => (
                  <li key={r.id} className="flex items-center gap-2 text-sm">
                    <span className="flex-1 truncate">{r.addressee.nickname}</span>
                    <Button size="sm" variant="ghost" onClick={() => remove(r.id)}>
                      취소
                    </Button>
                  </li>
                ))}
              </ul>
            </section>
          )}
        </div>
      </div>
    </AppShell>
  );
}
