import { memo, useCallback, useEffect, useMemo, useRef, useState } from "react";
import { createFileRoute, Link, useBlocker, useNavigate } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Bot, Coins, Loader2, LogOut, Send, Shield } from "lucide-react";
import { toast } from "sonner";

import { Board, findWinLine } from "@/components/omok/Board";
import { PlayerName, TitleBadge } from "@/components/omok/PlayerName";
import { RankEmblem, RpBar, rankLabel } from "@/components/omok/RankBadge";
import { SoundControl } from "@/components/omok/SoundControl";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { supabase } from "@/integrations/supabase/client";
import { cn } from "@/lib/utils";
import { audio } from "@/lib/omok/audio";
import type { GameResult, GameRow, PlayerResult } from "@/lib/omok/engine";
import {
  claimTimeout,
  getGame,
  leaveGame,
  playMove,
  sendMessage,
  type GameState,
  type PublicPlayer,
} from "@/lib/omok/game.functions";
import { useMe, useMusic, useRankerMap } from "@/lib/omok/hooks";
import { PLACEMENT_GAMES, TURN_SECONDS } from "@/lib/omok/rank";
import { colorToMove, type Color, type Move } from "@/lib/omok/rules";

export const Route = createFileRoute("/_authenticated/game/$gameId")({
  head: () => ({
    meta: [
      { title: "대국 · Omok Arena" },
      { name: "description", content: "Omok Arena 대국 화면." },
      { property: "og:title", content: "대국 · Omok Arena" },
      { property: "og:description", content: "Omok Arena 대국 화면." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: GamePage,
});

type Msg = { id: string; user_id: string; content: string; censored: boolean; created_at: string };

const statusRank = (g: GameRow) => (g.status === "active" ? 0 : g.result ? 2 : 1);
function isNewer(cur: GameRow, next: GameRow) {
  if (next.move_count !== cur.move_count) return next.move_count > cur.move_count;
  return statusRank(next) >= statusRank(cur);
}

const AI_LABEL: Record<string, string> = { easy: "입문", normal: "중급", hard: "고수" };

function GamePage() {
  useMusic("game");
  const { gameId } = Route.useParams();
  const { data: meData } = useMe();
  const myId = meData?.profile.id;
  const rankers = useRankerMap();
  const qc = useQueryClient();
  const navigate = useNavigate();

  const fetchGame = useServerFn(getGame);
  const play = useServerFn(playMove);
  const claim = useServerFn(claimTimeout);
  const leave = useServerFn(leaveGame);

  const [state, setState] = useState<GameState | null>(null);
  const [offset, setOffset] = useState(0);
  const [pending, setPending] = useState<Move | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [resultOpen, setResultOpen] = useState(false);
  const soundCount = useRef<number | null>(null);
  const endedRef = useRef(false);

  const applyState = useCallback((s: GameState) => {
    setOffset(s.serverNow - Date.now());
    setState((cur) => (!cur || isNewer(cur.game, s.game) ? s : { ...cur, players: s.players }));
  }, []);

  useEffect(() => {
    fetchGame({ data: { id: gameId } })
      .then(applyState)
      .catch((e) => setLoadError(e instanceof Error ? e.message : "대국을 불러올 수 없습니다."));
  }, [gameId, fetchGame, applyState]);

  useEffect(() => {
    const ch = supabase
      .channel(`game-${gameId}`)
      .on("postgres_changes", { event: "UPDATE", schema: "public", table: "games", filter: `id=eq.${gameId}` }, (payload) => {
        const next = payload.new as GameRow;
        setState((cur) => (cur && isNewer(cur.game, next) ? { ...cur, game: next } : cur));
      })
      .subscribe();
    return () => {
      void supabase.removeChannel(ch);
    };
  }, [gameId]);

  const game = state?.game;
  const moves = useMemo(() => ((game?.moves as unknown as Move[]) ?? []), [game?.moves]);
  const myColor: Color | null = game && myId ? (game.black_id === myId ? 1 : game.white_id === myId ? 2 : null) : null;
  const active = game?.status === "active";
  const turn = game ? colorToMove(game.move_count) : 1;
  const myTurn = active && myColor === turn;

  // stone sounds for incoming moves
  useEffect(() => {
    if (!game) return;
    if (soundCount.current === null) {
      soundCount.current = game.move_count;
      return;
    }
    if (game.move_count > soundCount.current) {
      soundCount.current = game.move_count;
      window.setTimeout(() => audio().stone(), game.vs_ai ? 180 : 0);
    }
  }, [game]);

  // game end
  useEffect(() => {
    if (!game || game.status !== "finished" || !game.result || endedRef.current) return;
    endedRef.current = true;
    setPending(null);
    const key = myColor === 1 ? "black" : "white";
    const r = (game.result as unknown as GameResult)[key];
    if (r) audio().chime(r.won ? "win" : "lose");
    r?.newTitles?.forEach((t) => toast.success(`새 칭호 획득: ${t}`, { description: "인벤토리에서 장착할 수 있습니다." }));
    window.setTimeout(() => setResultOpen(true), 700);
    void qc.invalidateQueries({ queryKey: ["me"] });
    void qc.invalidateQueries({ queryKey: ["leaderboard"] });
  }, [game, myColor, qc]);

  const onPlay = useCallback(
    async (x: number, y: number) => {
      if (!game || !myTurn || pending) return;
      setPending([x, y]);
      audio().stone();
      soundCount.current = game.move_count + 1;
      try {
        const s = await play({ data: { id: game.id, x, y } });
        applyState(s);
      } catch (e) {
        toast.error(e instanceof Error ? e.message : "수를 둘 수 없습니다.");
        soundCount.current = game.move_count;
      } finally {
        setPending(null);
      }
    },
    [game, myTurn, pending, play, applyState],
  );

  const claimingRef = useRef(false);
  const onExpire = useCallback(async () => {
    if (!game || claimingRef.current) return;
    claimingRef.current = true;
    try {
      applyState(await claim({ data: { id: game.id } }));
    } catch {
      /* retry on next tick */
    } finally {
      claimingRef.current = false;
    }
  }, [game, claim, applyState]);

  // leaving guard
  const activeRef = useRef(false);
  activeRef.current = !!active;
  const blocker = useBlocker({
    shouldBlockFn: () => activeRef.current,
    enableBeforeUnload: () => activeRef.current,
    withResolver: true,
  });
  const [leaving, setLeaving] = useState(false);

  async function confirmLeave() {
    if (!game) return;
    setLeaving(true);
    try {
      await leave({ data: { id: game.id } });
      await qc.invalidateQueries({ queryKey: ["me"] });
    } catch {
      /* ignore */
    } finally {
      setLeaving(false);
      activeRef.current = false;
      if (blocker.status === "blocked") blocker.proceed();
    }
  }

  const winLine = useMemo(() => (game?.status === "finished" && game.end_reason === "five" ? findWinLine(moves) : null), [game?.status, game?.end_reason, moves]);

  if (loadError) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-4">
        <p className="text-muted-foreground">{loadError}</p>
        <Button asChild>
          <Link to="/lobby">로비로</Link>
        </Button>
      </div>
    );
  }

  if (!state || !game || !myId) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <Loader2 className="size-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  const oppColor: Color = myColor === 1 ? 2 : 1;
  const me = myColor === 1 ? state.players.black : state.players.white;
  const opp = myColor === 1 ? state.players.white : state.players.black;
  const myResult = game.result ? (game.result as unknown as GameResult)[myColor === 1 ? "black" : "white"] : undefined;

  let status = "";
  if (active) status = myTurn ? "당신의 차례입니다" : game.vs_ai ? "AI가 생각 중…" : "상대의 차례입니다";
  else if (myResult) status = myResult.draw ? "무승부" : myResult.won ? "승리" : "패배";
  else status = "대국 종료";

  return (
    <div className="flex min-h-screen flex-col">
      <header className="border-b border-border/70 bg-background/80 backdrop-blur-md">
        <div className="mx-auto flex h-14 max-w-6xl items-center gap-4 px-4">
          <span className="wordmark text-sm">
            Omok<span className="text-primary"> Arena</span>
          </span>
          <span className="rounded-md border border-border px-2 py-0.5 text-xs text-muted-foreground">
            {game.friendly ? "친선 대국" : `${game.mode === "ranked" ? "경쟁전" : "일반전"} · ${game.vs_ai ? `AI ${AI_LABEL[game.ai_level ?? "normal"]}` : "랜덤 대국"}`}
          </span>
          <div className="ml-auto flex items-center gap-1">
            <SoundControl />
            <Button variant="ghost" size="sm" onClick={() => navigate({ to: "/lobby" })}>
              <LogOut className="size-4" /> 나가기
            </Button>
          </div>
        </div>
      </header>

      <main className="mx-auto grid w-full max-w-6xl flex-1 gap-6 px-4 py-6 lg:grid-cols-[minmax(0,1fr)_320px]">
        <div className="flex flex-col items-center gap-3">
          <div className="flex w-full max-w-[min(100%,calc(100vh-9rem))] items-center justify-between">
            <span className={cn("text-sm font-medium", myTurn ? "text-primary" : "text-muted-foreground")}>{status}</span>
            <span className="font-display text-xs tracking-wider text-muted-foreground">MOVE {game.move_count}</span>
          </div>
          <div className="w-full max-w-[min(100%,calc(100vh-9rem))]">
            <Board moves={moves} pending={pending} canPlay={!!myTurn && !pending} myColor={myColor} winLine={winLine} onPlay={onPlay} />
          </div>
        </div>

        <aside className="flex flex-col gap-4">
          <PlayerCard
            player={opp}
            isAi={game.vs_ai}
            aiLevel={game.ai_level}
            color={oppColor}
            position={opp ? rankers.get(opp.id) : undefined}
            running={!!active && turn === oppColor}
            startedAt={game.turn_started_at}
            offset={offset}
            onExpire={onExpire}
          />
          {game.vs_ai ? (
            <div className="panel flex-1 space-y-3 p-4 text-sm text-muted-foreground">
              <p className="label-caps">Rules</p>
              <p>흑의 3-3, 4-4, 장목(6목 이상)은 반칙패입니다. 백은 장목도 승리로 인정됩니다.</p>
              <p>한 수에 {TURN_SECONDS}초가 지나면 시간패입니다.</p>
              {game.mode === "ranked" && <p>경쟁전 AI 대국도 RP와 배치고사에 반영됩니다.</p>}
            </div>
          ) : (
            <Chat gameId={game.id} myId={myId} players={state.players} rankers={rankers} mutedUntil={meData?.profile.muted_until ?? null} />
          )}
          <PlayerCard
            player={me}
            isAi={false}
            color={myColor ?? 1}
            position={me ? rankers.get(me.id) : undefined}
            running={!!active && turn === myColor}
            startedAt={game.turn_started_at}
            offset={offset}
            onExpire={onExpire}
            tick
            isMe
          />
        </aside>
      </main>

      <ResultDialog open={resultOpen} onOpenChange={setResultOpen} game={game} result={myResult} />

      <AlertDialog open={blocker.status === "blocked"}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>대국을 나가시겠습니까?</AlertDialogTitle>
            <AlertDialogDescription>
              지금 나가면 패배로 처리되며 RP가 소량 차감됩니다.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => blocker.status === "blocked" && blocker.reset()}>계속 두기</AlertDialogCancel>
            <AlertDialogAction onClick={confirmLeave} disabled={leaving} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              나가기
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

const PlayerCard = memo(function PlayerCard({
  player,
  isAi,
  aiLevel,
  color,
  position,
  running,
  startedAt,
  offset,
  onExpire,
  tick,
  isMe,
}: {
  player: PublicPlayer | null;
  isAi: boolean;
  aiLevel?: string | null | undefined;
  color: Color;
  position?: number | undefined;
  running: boolean;
  startedAt: string;
  offset: number;
  onExpire: () => void;
  tick?: boolean | undefined;
  isMe?: boolean | undefined;
}) {
  return (
    <div className={cn("panel p-4 transition-colors", running && "border-primary/60")}>
      <div className="flex items-center gap-3">
        {isAi ? (
          <div className="flex size-11 items-center justify-center rounded-lg bg-secondary">
            <Bot className="size-5 text-muted-foreground" />
          </div>
        ) : player ? (
          <RankEmblem rating={player.rating} placementGames={player.placement_games} size={44} />
        ) : null}
        <div className="min-w-0 flex-1">
          {isAi ? (
            <span className="font-semibold">AI · {AI_LABEL[aiLevel ?? "normal"]}</span>
          ) : player ? (
            <PlayerName nickname={player.nickname} rating={player.rating} placementGames={player.placement_games} position={position} title={player.equipped_title} color={player.equipped_color} className="max-w-full" />
          ) : (
            <span className="text-muted-foreground">-</span>
          )}
          <div className="mt-0.5 flex items-center gap-1.5 text-xs text-muted-foreground">
            <span className={cn("inline-block size-2.5 rounded-full border", color === 1 ? "border-border bg-background" : "border-foreground/40 bg-foreground")} />
            {color === 1 ? "흑" : "백"}
            {!isAi && player && <span>· {rankLabel(player.rating, player.placement_games)}</span>}
            {isMe && <span>· 나</span>}
          </div>
        </div>
      </div>
      <TurnClock running={running} startedAt={startedAt} offset={offset} onExpire={onExpire} tick={tick} />
    </div>
  );
});

function TurnClock({ running, startedAt, offset, onExpire, tick }: { running: boolean; startedAt: string; offset: number; onExpire: () => void; tick?: boolean | undefined }) {
  const [left, setLeft] = useState(TURN_SECONDS);
  const lastSec = useRef(-1);
  const lastExpire = useRef(0);

  useEffect(() => {
    if (!running) {
      setLeft(TURN_SECONDS);
      return;
    }
    const start = new Date(startedAt).getTime();
    const update = () => {
      const remain = Math.min(TURN_SECONDS, Math.max(0, TURN_SECONDS - (Date.now() + offset - start) / 1000));
      setLeft(remain);
      const sec = Math.ceil(remain);
      if (tick && sec <= 10 && sec > 0 && sec !== lastSec.current) audio().chime("tick");
      lastSec.current = sec;
      if (remain <= 0 && Date.now() - lastExpire.current > 3000) {
        lastExpire.current = Date.now();
        onExpire();
      }
    };
    update();
    const iv = window.setInterval(update, 200);
    return () => window.clearInterval(iv);
  }, [running, startedAt, offset, onExpire, tick]);

  const pct = (left / TURN_SECONDS) * 100;
  const low = running && left <= 10;
  return (
    <div className="mt-3 flex items-center gap-3">
      <div className="h-1 flex-1 overflow-hidden rounded-full bg-muted">
        <div
          className={cn("h-full rounded-full transition-[width] duration-200 ease-linear", low ? "bg-destructive" : running ? "bg-primary" : "bg-muted-foreground/30")}
          style={{ width: `${running ? pct : 100}%` }}
        />
      </div>
      <span className={cn("w-10 text-right font-display text-sm font-semibold tabular-nums", low ? "text-destructive" : running ? "text-foreground" : "text-muted-foreground")}>
        {running ? `${Math.ceil(left)}s` : "—"}
      </span>
    </div>
  );
}

function Chat({
  gameId,
  myId,
  players,
  rankers,
  mutedUntil: initialMute,
}: {
  gameId: string;
  myId: string;
  players: GameState["players"];
  rankers: Map<string, number>;
  mutedUntil: string | null;
}) {
  const send = useServerFn(sendMessage);
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [text, setText] = useState("");
  const [mutedUntil, setMutedUntil] = useState<string | null>(initialMute);
  const [now, setNow] = useState(() => Date.now());
  const listRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    supabase
      .from("game_messages")
      .select("id, user_id, content, censored, created_at")
      .eq("game_id", gameId)
      .order("created_at")
      .limit(100)
      .then(({ data }) => data && setMsgs(data));
    const ch = supabase
      .channel(`chat-${gameId}`)
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "game_messages", filter: `game_id=eq.${gameId}` }, (payload) => {
        const m = payload.new as Msg;
        setMsgs((cur) => (cur.some((x) => x.id === m.id) ? cur : [...cur, m]));
        if (m.user_id !== myId) audio().chime("message");
      })
      .subscribe();
    return () => {
      void supabase.removeChannel(ch);
    };
  }, [gameId, myId]);

  useEffect(() => {
    listRef.current?.scrollTo({ top: listRef.current.scrollHeight });
  }, [msgs]);

  const muted = mutedUntil ? new Date(mutedUntil).getTime() > now : false;
  useEffect(() => {
    if (!muted) return;
    const iv = window.setInterval(() => setNow(Date.now()), 1000);
    return () => window.clearInterval(iv);
  }, [muted]);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    const content = text.trim();
    if (!content || muted) return;
    setText("");
    try {
      const r = await send({ data: { id: gameId, content } });
      if (r.mutedUntil) {
        setMutedUntil(r.mutedUntil);
        setNow(Date.now());
      }
      if (r.warned) {
        toast.warning(
          r.mutedUntil ? `욕설 경고 ${r.warnings}회 — 잠시 동안 채팅이 금지됩니다.` : `욕설이 감지되었습니다. (경고 ${r.warnings}회)`,
        );
      }
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "메시지를 보낼 수 없습니다.");
    }
  }

  const who = (uid: string) => (players.black?.id === uid ? players.black : players.white?.id === uid ? players.white : null);
  const remain = mutedUntil ? Math.max(0, Math.ceil((new Date(mutedUntil).getTime() - now) / 1000)) : 0;

  return (
    <div className="panel flex min-h-64 flex-1 flex-col overflow-hidden">
      <div className="border-b border-border px-4 py-2.5">
        <p className="label-caps">Chat</p>
      </div>
      <div ref={listRef} className="flex-1 space-y-2 overflow-y-auto px-4 py-3 text-sm lg:max-h-[calc(100vh-24rem)]">
        {msgs.length === 0 && <p className="text-xs text-muted-foreground">좋은 대국 되세요.</p>}
        {msgs.map((m) => {
          const p = who(m.user_id);
          return (
            <div key={m.id} className="leading-relaxed">
              {p && (
                <PlayerName nickname={p.nickname} rating={p.rating} placementGames={p.placement_games} position={rankers.get(p.id)} color={p.equipped_color} showTitle={false} className="mr-1.5 text-xs" />
              )}
              <span className={m.censored ? "text-muted-foreground" : "text-foreground"}>{m.content}</span>
            </div>
          );
        })}
      </div>
      <form onSubmit={submit} className="flex gap-2 border-t border-border p-2.5">
        <Input
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder={muted ? `채팅 금지 ${Math.floor(remain / 60)}:${String(remain % 60).padStart(2, "0")}` : "메시지 입력"}
          disabled={muted}
          maxLength={120}
        />
        <Button type="submit" size="icon" disabled={muted || !text.trim()} aria-label="보내기">
          <Send className="size-4" />
        </Button>
      </form>
    </div>
  );
}

const REASON: Record<string, string> = {
  five: "오목 완성",
  timeout: "시간 초과",
  leave: "대국 이탈",
  draw: "판이 가득 찼습니다",
};
const FOUL: Record<string, string> = {
  overline: "흑 장목(6목 이상) 반칙",
  "double-four": "흑 4-4 반칙",
  "double-three": "흑 3-3 반칙",
};

function ResultDialog({
  open,
  onOpenChange,
  game,
  result,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  game: GameRow;
  result?: PlayerResult | undefined;
}) {
  const navigate = useNavigate();
  if (!result) return null;
  const foul = (game.result as unknown as GameResult)?.foul;
  const reason = game.end_reason === "foul" && foul ? FOUL[foul] : REASON[game.end_reason ?? ""] ?? "";
  const title = result.draw ? "무승부" : result.won ? "승리" : "패배";
  const placed = result.placementPlayed >= PLACEMENT_GAMES;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-sm">
        <DialogHeader>
          <DialogTitle className={cn("wordmark text-center text-3xl", result.won ? "text-primary" : result.draw ? "text-foreground" : "text-muted-foreground")}>
            {title}
          </DialogTitle>
          <p className="text-center text-sm text-muted-foreground">{reason}</p>
        </DialogHeader>

        <div className={cn("grid grid-cols-3 gap-2 text-center", result.friendly && "hidden")}>
          <div className="rounded-md bg-secondary py-2.5">
            <div className="font-display text-xl font-semibold">{result.perf}</div>
            <div className="text-xs text-muted-foreground">성과 점수</div>
          </div>
          <div className="rounded-md bg-secondary py-2.5">
            <div className="font-display text-xl font-semibold">{result.stones}</div>
            <div className="text-xs text-muted-foreground">착수</div>
          </div>
          <div className="rounded-md bg-secondary py-2.5">
            <div className="flex items-center justify-center gap-1 font-display text-xl font-semibold text-primary">
              <Coins className="size-4" />+{result.bp}
            </div>
            <div className="text-xs text-muted-foreground">BP</div>
          </div>
        </div>

        {result.friendly && <p className="text-center text-sm text-muted-foreground">친선 대국은 기록과 보상에 반영되지 않습니다.</p>}

        {result.newTitles?.length > 0 && (
          <div className="flex flex-wrap items-center justify-center gap-2 rounded-lg border border-primary/40 bg-primary/5 p-3 text-sm">
            새 칭호 획득 {result.newTitles.map((t) => <TitleBadge key={t} title={t} />)}
          </div>
        )}

        {result.ranked && !placed && (
          <p className="text-center text-sm text-muted-foreground">
            배치고사 {result.placementPlayed} / {PLACEMENT_GAMES}
          </p>
        )}

        {!result.friendly && (placed || result.rpDelta !== 0) && (
          <div className="flex flex-col items-center gap-2 rounded-lg border border-border p-4">
            {result.placedNow && <p className="label-caps text-primary">배치 완료</p>}
            <RankEmblem rating={result.ratingAfter} placementGames={result.placementPlayed >= PLACEMENT_GAMES ? PLACEMENT_GAMES : result.placementPlayed} size={96} animated />
            <p className="font-display text-lg font-semibold tracking-wider">{rankLabel(result.ratingAfter, result.placementPlayed)}</p>
            {!result.placedNow && result.rpDelta !== 0 && (
              <p className={cn("font-display text-base font-semibold", result.rpDelta > 0 ? "text-success" : "text-destructive")}>
                {result.rpDelta > 0 ? "+" : ""}
                {result.rpDelta} RP
              </p>
            )}
            {placed && (
              <div className="w-full">
                <RpBar rating={result.ratingAfter} placementGames={PLACEMENT_GAMES} />
              </div>
            )}
            {result.shieldUsed && (
              <p className="flex items-center gap-1.5 text-xs text-primary">
                <Shield className="size-3.5" /> 강등 방어권이 사용되었습니다
              </p>
            )}
          </div>
        )}

        <div className="grid grid-cols-2 gap-2">
          <Button variant="secondary" onClick={() => onOpenChange(false)}>
            판 보기
          </Button>
          <Button onClick={() => navigate({ to: "/lobby" })}>로비로</Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
