import { createFileRoute } from "@tanstack/react-router";
import { Loader2 } from "lucide-react";

import { AppShell } from "@/components/omok/AppShell";
import { PlayerName, RankCrown } from "@/components/omok/PlayerName";
import { RankEmblem, rankLabel } from "@/components/omok/RankBadge";
import { cn } from "@/lib/utils";
import { useLeaderboard, useMe } from "@/lib/omok/hooks";

export const Route = createFileRoute("/_authenticated/leaderboard")({
  head: () => ({
    meta: [
      { title: "순위표 · Omok Arena" },
      { name: "description", content: "RP가 가장 높은 오목 아레나 플레이어 순위." },
      { property: "og:title", content: "순위표 · Omok Arena" },
      { property: "og:description", content: "RP가 가장 높은 오목 아레나 플레이어 순위." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Leaderboard,
});

function Leaderboard() {
  const { data, isLoading } = useLeaderboard();
  const { data: me } = useMe();

  return (
    <AppShell>
      <div className="mb-6 flex items-end justify-between">
        <div>
          <p className="label-caps">Leaderboard</p>
          <h1 className="mt-1 text-2xl font-bold">순위표</h1>
        </div>
        <p className="text-xs text-muted-foreground">상위 10명은 랭커 칭호를 받습니다</p>
      </div>

      {isLoading ? (
        <div className="flex justify-center py-20">
          <Loader2 className="size-6 animate-spin text-muted-foreground" />
        </div>
      ) : (
        <div className="panel overflow-hidden">
          <div className="grid grid-cols-[3rem_1fr_auto] gap-3 border-b border-border px-4 py-2.5 text-xs text-muted-foreground sm:grid-cols-[3.5rem_1fr_9rem_6rem_6rem]">
            <span>순위</span>
            <span>플레이어</span>
            <span className="hidden sm:block">티어</span>
            <span className="text-right">RP</span>
            <span className="hidden text-right sm:block">전적</span>
          </div>
          {(data ?? []).map((r, i) => {
            const pos = i + 1;
            const mine = me?.profile.id === r.id;
            return (
              <div
                key={r.id}
                className={cn(
                  "grid grid-cols-[3rem_1fr_auto] items-center gap-3 border-b border-border/60 px-4 py-3 last:border-0 sm:grid-cols-[3.5rem_1fr_9rem_6rem_6rem]",
                  pos <= 3 && "bg-secondary/40",
                  mine && "bg-primary/10",
                )}
              >
                <span className="flex items-center gap-1 font-display text-lg font-bold text-muted-foreground">
                  {pos <= 3 ? <RankCrown position={pos} size={22} /> : pos}
                </span>
                <span className="flex min-w-0 items-center gap-3">
                  <RankEmblem rating={r.rating} placementGames={r.placement_games} size={pos <= 3 ? 40 : 32} animated={pos <= 3} />
                  <PlayerName nickname={r.nickname} rating={r.rating} placementGames={r.placement_games} position={pos} title={r.equipped_title} color={r.equipped_color} />
                </span>
                <span className="hidden text-sm text-muted-foreground sm:block">{rankLabel(r.rating, r.placement_games)}</span>
                <span className="text-right font-display text-base font-semibold">{r.rating}</span>
                <span className="hidden text-right text-xs text-muted-foreground sm:block">
                  {r.ranked_wins}승 {r.ranked_losses}패
                </span>
              </div>
            );
          })}
          {data && data.length === 0 && (
            <p className="px-4 py-16 text-center text-sm text-muted-foreground">
              아직 배치고사를 마친 플레이어가 없습니다. 첫 번째 랭커가 되어 보세요.
            </p>
          )}
        </div>
      )}
    </AppShell>
  );
}
