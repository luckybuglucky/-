import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Coins, Loader2 } from "lucide-react";
import { toast } from "sonner";

import { AppShell } from "@/components/omok/AppShell";
import { Button } from "@/components/ui/button";
import { buyShield } from "@/lib/omok/game.functions";
import { redeemCode } from "@/lib/omok/social.functions";
import { Input } from "@/components/ui/input";
import { useMe } from "@/lib/omok/hooks";
import { SHIELD_PRICE } from "@/lib/omok/rank";

export const Route = createFileRoute("/_authenticated/shop")({
  head: () => ({
    meta: [
      { title: "상점 · Omok Arena" },
      { name: "description", content: "모은 BP로 강등 방어권을 구매하세요." },
      { property: "og:title", content: "상점 · Omok Arena" },
      { property: "og:description", content: "모은 BP로 강등 방어권을 구매하세요." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Shop,
});

function Shop() {
  const { data } = useMe();
  const qc = useQueryClient();
  const buy = useServerFn(buyShield);
  const [busy, setBusy] = useState(false);
  const redeem = useServerFn(redeemCode);
  const [code, setCode] = useState("");
  const [redeeming, setRedeeming] = useState(false);

  async function submitCode(e: React.FormEvent) {
    e.preventDefault();
    if (!code.trim()) return;
    setRedeeming(true);
    try {
      const r = await redeem({ data: { code } });
      toast.success(`코드 사용 완료! ${r.reward} BP를 받았습니다.`);
      setCode("");
      await qc.invalidateQueries({ queryKey: ["me"] });
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "코드를 사용할 수 없습니다.");
    } finally {
      setRedeeming(false);
    }
  }
  const bp = data?.profile.bp ?? 0;
  const shields = data?.profile.shields ?? 0;
  const pct = Math.min(100, (bp / SHIELD_PRICE) * 100);

  async function purchase() {
    setBusy(true);
    try {
      await buy();
      toast.success("강등 방어권을 구매했습니다.");
      await qc.invalidateQueries({ queryKey: ["me"] });
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "구매에 실패했습니다.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <AppShell>
      <div className="mb-6">
        <p className="label-caps">Shop</p>
        <h1 className="mt-1 text-2xl font-bold">상점</h1>
      </div>
      <div className="grid gap-6 md:grid-cols-[1fr_320px]">
        <div className="panel flex flex-col gap-6 p-6 sm:flex-row sm:items-center">
          <ShieldArt />
          <div className="flex-1">
            <h2 className="text-lg font-semibold">강등 방어권</h2>
            <p className="mt-1 text-sm text-muted-foreground">
              경쟁전 패배로 단계가 내려갈 때 자동으로 1장 사용되어, 현재 단계의 0 RP에서 멈춥니다.
            </p>
            <div className="mt-4 flex items-center gap-2 text-sm">
              <span className="text-muted-foreground">보유</span>
              <span className="font-display text-lg font-semibold">{shields}</span>
            </div>
            <div className="mt-5 flex flex-wrap items-center gap-3">
              <Button onClick={purchase} disabled={busy || bp < SHIELD_PRICE} className="h-11 px-6">
                {busy ? <Loader2 className="size-4 animate-spin" /> : <Coins className="size-4" />}
                {SHIELD_PRICE} BP로 구매
              </Button>
              {bp < SHIELD_PRICE && <span className="text-xs text-muted-foreground">{SHIELD_PRICE - bp} BP 더 필요합니다</span>}
            </div>
          </div>
        </div>

        <div className="panel p-6">
          <p className="label-caps">Balance</p>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="font-display text-4xl font-bold text-primary">{bp}</span>
            <span className="text-muted-foreground">BP</span>
          </div>
          <div className="rp-bar mt-4">
            <span style={{ width: `${pct}%` }} />
          </div>
          <p className="mt-2 text-xs text-muted-foreground">
            방어권까지 {Math.min(bp, SHIELD_PRICE)} / {SHIELD_PRICE}
          </p>
          <p className="mt-6 text-sm text-muted-foreground">
            일반전과 경쟁전에서 승리할 때마다 1~5 BP가 무작위로 지급됩니다.
          </p>
        </div>

        <form onSubmit={submitCode} className="panel p-6 md:col-span-2">
          <p className="label-caps">Redeem Code</p>
          <p className="mt-2 text-sm text-muted-foreground">BP 코드를 입력하세요. 코드는 계정당 한 번만 사용할 수 있습니다.</p>
          <div className="mt-4 flex max-w-md gap-2">
            <Input value={code} onChange={(e) => setCode(e.target.value.toUpperCase())} placeholder="코드 입력" maxLength={40} className="font-display tracking-widest" />
            <Button type="submit" disabled={redeeming || !code.trim()}>
              {redeeming && <Loader2 className="size-4 animate-spin" />}
              사용
            </Button>
          </div>
        </form>
      </div>
    </AppShell>
  );
}

function ShieldArt() {
  return (
    <svg width="120" height="120" viewBox="0 0 120 120" aria-hidden className="shrink-0">
      <defs>
        <linearGradient id="shop-shield" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" style={{ stopColor: "var(--tier-gold-hi)" }} />
          <stop offset="1" style={{ stopColor: "var(--tier-gold-lo)" }} />
        </linearGradient>
      </defs>
      <circle cx="60" cy="60" r="54" fill="var(--secondary)" />
      <path d="M60 22 L88 32 L88 60 C88 78 75 90 60 98 C45 90 32 78 32 60 L32 32 Z" fill="url(#shop-shield)" />
      <path d="M60 32 L80 39 L80 60 C80 73 71 82 60 88 C49 82 40 73 40 60 L40 39 Z" fill="var(--background)" opacity="0.35" />
      <path d="M52 60 L58 66 L70 52" fill="none" stroke="var(--tier-gold-hi)" strokeWidth="5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}
