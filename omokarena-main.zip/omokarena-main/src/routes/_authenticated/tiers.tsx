import { createFileRoute } from "@tanstack/react-router";

import { AppShell } from "@/components/omok/AppShell";
import { TierEmblem } from "@/components/omok/TierEmblem";
import { divisionSize, divisionStart, LEAVE_PENALTY, PLACEMENT_GAMES, PLACEMENT_PERFECT_MAX_STONES, SHIELD_PRICE, TIER_LABEL, TIERS, TURN_SECONDS } from "@/lib/omok/rank";

export const Route = createFileRoute("/_authenticated/tiers")({
  head: () => ({
    meta: [
      { title: "티어 안내 · Omok Arena" },
      { name: "description", content: "아이언부터 챌린저까지, 오목 아레나 티어와 경쟁전 규칙 안내." },
      { property: "og:title", content: "티어 안내 · Omok Arena" },
      { property: "og:description", content: "아이언부터 챌린저까지, 오목 아레나 티어와 경쟁전 규칙 안내." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Tiers,
});

function Tiers() {
  return (
    <AppShell>
      <div className="mb-6">
        <p className="label-caps">Tiers</p>
        <h1 className="mt-1 text-2xl font-bold">티어 안내</h1>
      </div>

      <div className="grid gap-4">
        {TIERS.slice()
          .reverse()
          .map((t) => {
            const idx = TIERS.indexOf(t);
            return (
              <div key={t} className="panel flex flex-col gap-4 p-5 sm:flex-row sm:items-center">
                <div className="w-40 shrink-0">
                  <p className={`nick-${t} text-lg font-bold`}>{TIER_LABEL[t]}</p>
                  <p className="text-xs text-muted-foreground">단계당 {divisionSize(idx * 3)} RP</p>
                </div>
                <div className="flex flex-1 items-center justify-around gap-2">
                  {([1, 2, 3] as const).map((d) => (
                    <div key={d} className="flex flex-col items-center gap-1.5">
                      <TierEmblem tier={t} division={d} size={idx >= 6 ? 96 : 80} animated={idx >= 4} />
                      <span className="text-xs text-muted-foreground">
                        {TIER_LABEL[t]} {d} · <span className="font-display">{divisionStart(idx * 3 + d - 1)}</span>
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
      </div>

      <div className="panel mt-6 grid gap-3 p-6 text-sm text-muted-foreground md:grid-cols-2">
        <p>· 경쟁전 {PLACEMENT_GAMES}판의 성과 점수 평균으로 첫 티어가 정해집니다. 적은 수로 이길수록 점수가 높습니다.</p>
        <p>· 배치고사 최고 결과는 플래티넘 3이며, {PLACEMENT_GAMES}판 전승 + 매 판 내 돌 {PLACEMENT_PERFECT_MAX_STONES}수 이내 승리일 때만 받을 수 있습니다.</p>
        <p>· 티어 차이가 큰 상대에게 이기면 RP를 더 받고, 훨씬 낮은 상대에게 이기면 조금만 받습니다.</p>
        <p>· 입문·중급 AI를 이기면 RP·BP·성과 점수가 적게 지급됩니다.</p>
        <p>· 각 단계에서 RP를 100(마스터 이상은 150) 모으면 다음 단계로, 3단계에서 승급하면 다음 티어로 올라갑니다.</p>
        <p>· 흑의 3-3, 4-4, 장목은 반칙패, 한 수에 {TURN_SECONDS}초가 지나면 시간패입니다.</p>
        <p>· 대국을 나가면 패배와 함께 {LEAVE_PENALTY} RP가 추가로 차감됩니다.</p>
        <p>· 강등 방어권({SHIELD_PRICE} BP)은 단계가 내려갈 때 자동으로 사용됩니다.</p>
        <p>· 순위 10위 안은 랭커 칭호, 1·2·3위는 금관·은관·동관이 붙습니다.</p>
      </div>
    </AppShell>
  );
}
