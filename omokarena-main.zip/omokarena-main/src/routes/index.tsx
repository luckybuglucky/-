import { useEffect, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight } from "lucide-react";

import { Button } from "@/components/ui/button";
import { TierEmblem } from "@/components/omok/TierEmblem";
import { supabase } from "@/integrations/supabase/client";
import { TIER_LABEL, TIERS } from "@/lib/omok/rank";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Omok Arena — 한 수로 증명하는 오목 경쟁전" },
      { name: "description", content: "아이언부터 챌린저까지. 경쟁전, 일반전, AI 대국과 실시간 플레이어 대국을 지원하는 오목 아레나." },
      { property: "og:title", content: "Omok Arena — 한 수로 증명하는 오목 경쟁전" },
      { property: "og:description", content: "아이언부터 챌린저까지. 경쟁전, 일반전, AI 대국과 실시간 플레이어 대국." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Landing,
});

function Landing() {
  const [signedIn, setSignedIn] = useState(false);
  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => setSignedIn(!!data.session));
  }, []);

  return (
    <div className="relative min-h-screen overflow-hidden">
      <DecorBoard />
      <header className="relative z-10 mx-auto flex h-16 max-w-6xl items-center px-6">
        <span className="wordmark text-sm">
          Omok<span className="text-primary"> Arena</span>
        </span>
        <div className="ml-auto">
          <Button asChild variant="ghost" size="sm">
            <Link to={signedIn ? "/lobby" : "/auth"}>{signedIn ? "로비" : "로그인"}</Link>
          </Button>
        </div>
      </header>

      <main className="relative z-10 mx-auto flex max-w-6xl flex-col items-center px-6 pt-20 pb-24 text-center md:pt-28">
        <p className="label-caps">Ranked Gomoku · Renju Rules</p>
        <h1 className="wordmark mt-6 text-5xl leading-none md:text-7xl">
          Omok
          <br />
          <span className="text-primary">Arena</span>
        </h1>
        <p className="mt-6 max-w-md text-base text-muted-foreground md:text-lg">
          적은 수로, 더 정확하게. 한 판 한 판이 당신의 티어가 됩니다.
        </p>
        <div className="mt-10 flex gap-3">
          <Button asChild size="lg" className="h-12 px-7 text-base">
            <Link to={signedIn ? "/lobby" : "/auth"}>
              입장하기 <ArrowRight className="size-4" />
            </Link>
          </Button>
        </div>

        <section className="mt-24 w-full">
          <p className="label-caps mb-8">Iron → Challenger</p>
          <div className="grid grid-cols-3 gap-y-8 sm:grid-cols-5 lg:grid-cols-9">
            {TIERS.map((t, i) => (
              <div key={t} className="flex flex-col items-center gap-2">
                <TierEmblem tier={t} division={3} size={i >= 6 ? 84 : 72} />
                <span className="text-xs text-muted-foreground">{TIER_LABEL[t]}</span>
              </div>
            ))}
          </div>
        </section>

        <section className="mt-24 grid w-full gap-4 text-left md:grid-cols-3">
          {[
            ["경쟁전", "배치고사 5판으로 시작. 승리할 때마다 RP를 얻고 단계를 올리세요."],
            ["렌주 규칙", "흑의 3-3, 4-4, 장목은 반칙패. 1분 동안 두지 않으면 시간패."],
            ["실시간 대국", "플레이어와 바로 매칭되고, 대국 중 채팅으로 인사를 나눌 수 있습니다."],
          ].map(([h, d]) => (
            <div key={h} className="panel p-6">
              <h3 className="font-semibold">{h}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{d}</p>
            </div>
          ))}
        </section>
      </main>
    </div>
  );
}

function DecorBoard() {
  const stones: Array<[number, number, 1 | 2]> = [
    [5, 5, 1], [6, 6, 2], [6, 5, 1], [7, 6, 1], [5, 6, 2], [7, 5, 2], [8, 7, 1], [4, 4, 2], [8, 4, 1],
  ];
  return (
    <svg className="pointer-events-none absolute top-0 left-1/2 h-[1100px] w-[1100px] -translate-x-1/2 opacity-[0.035] [mask-image:radial-gradient(closest-side,black,transparent)]" viewBox="0 0 560 560" aria-hidden>
      {Array.from({ length: 15 }).map((_, i) => (
        <g key={i} stroke="var(--foreground)" strokeWidth="0.6">
          <line x1={20} y1={20 + i * 37} x2={538} y2={20 + i * 37} />
          <line x1={20 + i * 37} y1={20} x2={20 + i * 37} y2={538} />
        </g>
      ))}
      {stones.map(([x, y, c], i) => (
        <circle key={i} cx={20 + x * 37} cy={20 + y * 37} r="15" fill={c === 1 ? "var(--foreground)" : "none"} stroke="var(--foreground)" strokeWidth="1.2" />
      ))}
    </svg>
  );
}
