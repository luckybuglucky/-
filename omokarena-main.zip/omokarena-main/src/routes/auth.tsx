import { useEffect, useState } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { Loader2 } from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { supabase } from "@/integrations/supabase/client";
import { NICKNAME_RE, nicknameToEmail } from "@/lib/omok/hooks";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "로그인 · Omok Arena" },
      { name: "description", content: "닉네임과 비밀번호로 간단하게 Omok Arena에 입장하세요." },
      { property: "og:title", content: "로그인 · Omok Arena" },
      { property: "og:description", content: "닉네임과 비밀번호로 간단하게 Omok Arena에 입장하세요." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: AuthPage,
});

function AuthPage() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<"login" | "signup">("login");
  const [nickname, setNickname] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      if (data.session) navigate({ to: "/lobby", replace: true });
    });
  }, [navigate]);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    const nick = nickname.trim();
    if (!NICKNAME_RE.test(nick)) {
      toast.error("닉네임은 2~12자의 한글, 영문, 숫자, _ 만 사용할 수 있습니다.");
      return;
    }
    if (password.length < 6) {
      toast.error("비밀번호는 6자 이상이어야 합니다.");
      return;
    }
    if (mode === "signup" && password !== confirm) {
      toast.error("비밀번호가 일치하지 않습니다.");
      return;
    }
    setBusy(true);
    try {
      const email = await nicknameToEmail(nick);
      if (mode === "signup") {
        const { data: taken } = await supabase.rpc("nickname_taken", { _nickname: nick });
        if (taken) {
          toast.error("이미 사용 중인 닉네임입니다.");
          return;
        }
        const { data, error } = await supabase.auth.signUp({
          email,
          password,
          options: { data: { nickname: nick }, emailRedirectTo: window.location.origin },
        });
        if (error) {
          const msg = /registered|exists|database/i.test(error.message) ? "이미 사용 중인 닉네임입니다." : error.message;
          toast.error(msg);
          return;
        }
        if (!data.session) {
          const { error: e2 } = await supabase.auth.signInWithPassword({ email, password });
          if (e2) {
            toast.error("가입은 완료되었습니다. 로그인해 주세요.");
            setMode("login");
            return;
          }
        }
        toast.success(`${nick}님, 아레나에 오신 것을 환영합니다.`);
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) {
          toast.error("닉네임 또는 비밀번호가 올바르지 않습니다.");
          return;
        }
      }
      navigate({ to: "/lobby", replace: true });
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="flex min-h-screen flex-col items-center justify-center px-4">
      <Link to="/" className="wordmark mb-10 text-lg">
        Omok<span className="text-primary"> Arena</span>
      </Link>
      <div className="panel w-full max-w-sm p-6">
        <Tabs value={mode} onValueChange={(v) => setMode(v as "login" | "signup")}>
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="login">로그인</TabsTrigger>
            <TabsTrigger value="signup">계정 만들기</TabsTrigger>
          </TabsList>
        </Tabs>
        <form onSubmit={submit} className="mt-6 space-y-4">
          <div className="space-y-2">
            <Label htmlFor="nick">닉네임</Label>
            <Input
              id="nick"
              value={nickname}
              onChange={(e) => setNickname(e.target.value)}
              placeholder="2~12자"
              autoComplete="username"
              maxLength={12}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="pw">비밀번호</Label>
            <Input
              id="pw"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="6자 이상"
              autoComplete={mode === "login" ? "current-password" : "new-password"}
            />
          </div>
          {mode === "signup" && (
            <div className="space-y-2">
              <Label htmlFor="pw2">비밀번호 확인</Label>
              <Input
                id="pw2"
                type="password"
                value={confirm}
                onChange={(e) => setConfirm(e.target.value)}
                autoComplete="new-password"
              />
            </div>
          )}
          <Button type="submit" className="h-11 w-full" disabled={busy}>
            {busy && <Loader2 className="size-4 animate-spin" />}
            {mode === "login" ? "입장하기" : "계정 만들기"}
          </Button>
          {mode === "signup" && (
            <p className="text-center text-xs text-muted-foreground">
              비밀번호는 찾을 수 없으니 잊지 않도록 주의하세요.
            </p>
          )}
        </form>
      </div>
    </div>
  );
}
