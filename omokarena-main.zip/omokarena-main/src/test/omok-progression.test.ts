import { describe, expect, it } from "vitest";

import { classifyItem, splitGive } from "@/lib/omok/commands";
import {
  DEVELOPER_NICKNAME,
  DEVELOPER_TITLE,
  LOSS_STREAK_FOR_TITLE,
  LOSS_STREAK_TITLE,
  redeemReward,
  WIN_STREAK_FOR_TITLE,
  WIN_STREAK_TITLE,
} from "@/lib/omok/cosmetics";
import {
  aiRewardScale,
  gapMultipliers,
  isPerfectPlacementGame,
  mmrChange,
  placementRating,
  randomBpFor,
  rankFromRating,
} from "@/lib/omok/rank";

describe("redeem codes", () => {
  it("RELEASE gives 25 BP (case-insensitive), unknown codes give nothing", () => {
    expect(redeemReward("RELEASE")).toBe(25);
    expect(redeemReward(" release ")).toBe(25);
    expect(redeemReward("NOPE")).toBeNull();
  });
});

describe("placement cap", () => {
  it("perfect placement (5 wins, each within 20 stones) gives Platinum 3", () => {
    expect(rankFromRating(placementRating(500, 5, true))).toMatchObject({ tier: "platinum", division: 3 });
  });

  it("without a perfect placement the best result is below Platinum 3", () => {
    const r = rankFromRating(placementRating(500, 5, false));
    expect(r.tier).toBe("platinum");
    expect(r.division).toBeLessThan(3);
  });

  it("a win in 21 stones or a loss is not perfect", () => {
    expect(isPerfectPlacementGame(true, 20)).toBe(true);
    expect(isPerfectPlacementGame(true, 21)).toBe(false);
    expect(isPerfectPlacementGame(false, 10)).toBe(false);
  });
});

describe("rating gap", () => {
  it("beating a much stronger player pays more, a much weaker one pays less", () => {
    expect(gapMultipliers(500, 1100).win).toBeGreaterThan(1);
    expect(gapMultipliers(1100, 500).win).toBeLessThan(1);
    expect(gapMultipliers(1100, 500).loss).toBeGreaterThan(1);
  });

  it("small gaps don't change RP", () => {
    expect(gapMultipliers(500, 650)).toEqual({ win: 1, loss: 1 });
  });
});

describe("MMR", () => {
  it("win streaks raise MMR faster", () => {
    expect(mmrChange(800, 800, true, 5)).toBeGreaterThan(mmrChange(800, 800, true, 1));
  });
});

describe("AI rewards", () => {
  it("level 1 and 2 AI give reduced rewards, level 3 full", () => {
    expect(aiRewardScale("easy")).toBeLessThan(aiRewardScale("normal"));
    expect(aiRewardScale("normal")).toBeLessThan(1);
    expect(aiRewardScale("hard")).toBe(1);
    expect(randomBpFor("easy", () => 0.999)).toBe(1);
    expect(randomBpFor("hard", () => 0.999)).toBe(5);
  });
});

describe("titles", () => {
  it("10 win streak = 불굴, 5 loss streak = 불운, 러키 = 개발자", () => {
    expect([WIN_STREAK_FOR_TITLE, WIN_STREAK_TITLE]).toEqual([10, "불굴"]);
    expect([LOSS_STREAK_FOR_TITLE, LOSS_STREAK_TITLE]).toEqual([5, "불운"]);
    expect([DEVELOPER_NICKNAME, DEVELOPER_TITLE]).toEqual(["러키", "개발자"]);
  });
});

describe("/give command", () => {
  const names = new Set(["러키", "player1", "abc"]);
  const isNick = (n: string) => names.has(n.toLowerCase());

  it("parses nickname + BP without spaces", () => {
    expect(splitGive("러키100", isNick)).toEqual({ nickname: "러키", item: { kind: "bp", amount: 100 } });
    expect(splitGive("player150", isNick)).toEqual({ nickname: "player1", item: { kind: "bp", amount: 50 } });
  });

  it("parses shield, color and title", () => {
    expect(splitGive("abc방어권", isNick)?.item).toEqual({ kind: "shield", count: 1 });
    expect(splitGive("abc무지개", isNick)?.item).toEqual({ kind: "color", color: "rainbow" });
    expect(splitGive("abc전설", isNick)?.item).toEqual({ kind: "title", title: "전설" });
    expect(splitGive("(abc)(빨간색)", isNick)?.item).toEqual({ kind: "color", color: "red" });
  });

  it("rejects unknown nicknames", () => {
    expect(splitGive("nobody100", isNick)).toBeNull();
    expect(classifyItem("0")).toBeNull();
  });
});
