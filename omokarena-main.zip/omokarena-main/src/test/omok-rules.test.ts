import { describe, expect, it } from "vitest";

import { applyMove, emptyBoard, SIZE, type Board, type Color } from "@/lib/omok/rules";
import { chooseAiMove } from "@/lib/omok/ai";
import {
  applyRatingChange,
  performanceScore,
  rankFromRating,
  randomBp,
  SHIELD_PRICE,
  PLACEMENT_GAMES,
  TURN_SECONDS,
} from "@/lib/omok/rank";
import { censor, muteMinutesFor } from "@/lib/omok/profanity";

function place(b: Board, stones: Array<[number, number]>, c: Color) {
  for (const [x, y] of stones) b[y * SIZE + x] = c;
}

describe("omok rules", () => {
  it("black wins with exactly five", () => {
    const b = emptyBoard();
    place(b, [[3, 7], [4, 7], [5, 7], [6, 7]], 1);
    expect(applyMove(b, 7, 7, 1, 9)).toMatchObject({ kind: "win", winner: 1 });
  });

  it("black overline is a foul and loses", () => {
    const b = emptyBoard();
    place(b, [[2, 7], [3, 7], [4, 7], [6, 7], [7, 7]], 1);
    expect(applyMove(b, 5, 7, 1, 11)).toMatchObject({ kind: "foul", winner: 2, foul: "overline" });
  });

  it("white overline wins", () => {
    const b = emptyBoard();
    place(b, [[2, 7], [3, 7], [4, 7], [6, 7], [7, 7]], 2);
    expect(applyMove(b, 5, 7, 2, 12)).toMatchObject({ kind: "win", winner: 2 });
  });

  it("black double-three is a foul", () => {
    const b = emptyBoard();
    place(b, [[6, 7], [7, 7], [8, 6], [8, 5]], 1);
    expect(applyMove(b, 8, 7, 1, 9)).toMatchObject({ kind: "foul", foul: "double-three" });
  });

  it("black double-four is a foul", () => {
    const b = emptyBoard();
    place(b, [[4, 7], [5, 7], [6, 7], [7, 4], [7, 5], [7, 6]], 1);
    place(b, [[3, 7], [7, 3]], 2);
    expect(applyMove(b, 7, 7, 1, 13)).toMatchObject({ kind: "foul", foul: "double-four" });
  });

  it("AI blocks an open four threat", () => {
    const b = emptyBoard();
    place(b, [[3, 7], [4, 7], [5, 7], [6, 7]], 1);
    place(b, [[3, 8], [4, 8], [5, 9]], 2);
    const [x, y] = chooseAiMove(b, 2, "hard");
    expect([[2, 7], [7, 7]]).toContainEqual([x, y]);
  });
});

describe("ranking", () => {
  it("each tier has 3 steps of 100 RP below master", () => {
    expect(rankFromRating(0)).toMatchObject({ tier: "iron", division: 1, size: 100 });
    expect(rankFromRating(250)).toMatchObject({ tier: "iron", division: 3, rp: 50 });
    expect(rankFromRating(300)).toMatchObject({ tier: "bronze", division: 1, rp: 0 });
  });

  it("master and above need 150 RP per step", () => {
    expect(rankFromRating(1800)).toMatchObject({ tier: "master", division: 1, size: 150 });
    expect(rankFromRating(1949)).toMatchObject({ tier: "master", division: 1 });
    expect(rankFromRating(1950)).toMatchObject({ tier: "master", division: 2 });
    expect(rankFromRating(1800 + 150 * 6)).toMatchObject({ tier: "challenger", division: 1 });
  });

  it("faster wins give a higher performance score", () => {
    expect(performanceScore(true, 5)).toBeGreaterThan(performanceScore(true, 20));
  });

  it("placement takes 5 ranked games", () => {
    expect(PLACEMENT_GAMES).toBe(5);
  });

  it("demotion shield keeps the player in the current step", () => {
    expect(applyRatingChange(305, -20, 1)).toEqual({ rating: 300, shields: 0, shieldUsed: true });
    expect(applyRatingChange(305, -20, 0)).toMatchObject({ rating: 285, shieldUsed: false });
  });

  it("shield costs 100 BP and a win gives 1-5 BP", () => {
    expect(SHIELD_PRICE).toBe(100);
    expect(randomBp(() => 0)).toBe(1);
    expect(randomBp(() => 0.9999)).toBe(5);
  });

  it("turn time limit is one minute", () => {
    expect(TURN_SECONDS).toBe(60);
  });
});

describe("chat filter", () => {
  it("censors profanity even with separators", () => {
    expect(censor("야 시 발 진짜").flagged).toBe(true);
    expect(censor("좋은 수네요").flagged).toBe(false);
  });

  it("mutes every 3 warnings", () => {
    expect(muteMinutesFor(2)).toBe(0);
    expect(muteMinutesFor(3)).toBe(3);
    expect(muteMinutesFor(6)).toBe(6);
  });
});
