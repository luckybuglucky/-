import { memo, useId } from "react";

import type { Tier } from "@/lib/omok/rank";

type Props = {
  tier: Tier | null; // null = unranked / placement
  division?: 1 | 2 | 3;
  size?: number;
  animated?: boolean;
  className?: string | undefined;
};

const v = (tier: string, k: "hi" | "mid" | "lo" | "glow") => `var(--tier-${tier}-${k})`;

/** Tier emblem. Ornament, glow and motion scale up with tier; divisions add pips and intensity. */
export const TierEmblem = memo(function TierEmblem({ tier, division = 1, size = 64, animated = true, className }: Props) {
  const uid = useId().replace(/:/g, "");
  if (!tier) return <Unranked size={size} className={className} />;

  const t = tier;
  const level = ["iron", "bronze", "silver", "gold", "platinum", "diamond", "master", "grandmaster", "challenger"].indexOf(t);
  const fancy = animated && level >= 4;
  const glowStrength = level >= 4 ? 0.35 + (level - 4) * 0.12 + (division - 1) * 0.08 : 0;
  const g = (n: string) => `${n}-${uid}`;

  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 120 120"
      className={className}
      role="img"
      aria-label={`${tier} ${division}`}
      style={{ overflow: "visible" }}
    >
      <defs>
        <linearGradient id={g("metal")} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" style={{ stopColor: v(t, "hi") }} />
          <stop offset="0.55" style={{ stopColor: v(t, "mid") }} />
          <stop offset="1" style={{ stopColor: v(t, "lo") }} />
        </linearGradient>
        <linearGradient id={g("inner")} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" style={{ stopColor: v(t, "lo") }} />
          <stop offset="1" style={{ stopColor: "var(--background)" }} />
        </linearGradient>
        <radialGradient id={g("aura")}>
          <stop offset="0" style={{ stopColor: v(t, "glow"), stopOpacity: glowStrength }} />
          <stop offset="1" style={{ stopColor: v(t, "glow"), stopOpacity: 0 }} />
        </radialGradient>
        <linearGradient id={g("shine")} x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" style={{ stopColor: "var(--foreground)", stopOpacity: 0 }} />
          <stop offset="0.5" style={{ stopColor: "var(--foreground)", stopOpacity: 0.55 }} />
          <stop offset="1" style={{ stopColor: "var(--foreground)", stopOpacity: 0 }} />
        </linearGradient>
        {t === "challenger" && (
          <linearGradient id={g("chal")} x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" style={{ stopColor: "var(--tier-challenger-hi)" }} />
            <stop offset="0.5" style={{ stopColor: "var(--tier-challenger-mid)" }} />
            <stop offset="1" style={{ stopColor: "var(--tier-challenger-alt)" }} />
          </linearGradient>
        )}
        <clipPath id={g("clip")}>
          <path d={bodyPath(level)} />
        </clipPath>
        {level >= 4 && (
          <filter id={g("glow")} x="-50%" y="-50%" width="200%" height="200%">
            <feGaussianBlur stdDeviation={2 + (level - 4) * 0.8} result="b" />
            <feMerge>
              <feMergeNode in="b" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
        )}
      </defs>

      {/* aura */}
      {level >= 4 && (
        <circle cx="60" cy="60" r={52 + (level - 4) * 2} fill={`url(#${g("aura")})`} className={fancy ? "em-pulse" : undefined} />
      )}

      {/* outer rings for top tiers */}
      {level >= 7 && (
        <g className={fancy ? "em-spin" : undefined} opacity={0.85}>
          <circle cx="60" cy="60" r="54" fill="none" stroke={v(t, "mid")} strokeWidth="1.2" strokeDasharray="3 6" />
          {Array.from({ length: level === 8 ? 16 : 10 }).map((_, i, arr) => {
            const a = (i / arr.length) * Math.PI * 2;
            return (
              <path
                key={i}
                d={`M ${60 + Math.cos(a) * 50} ${60 + Math.sin(a) * 50} L ${60 + Math.cos(a + 0.06) * 58} ${60 + Math.sin(a + 0.06) * 58} L ${60 + Math.cos(a + 0.12) * 50} ${60 + Math.sin(a + 0.12) * 50} Z`}
                fill={t === "challenger" ? `url(#${g("chal")})` : v(t, "hi")}
              />
            );
          })}
        </g>
      )}
      {level === 8 && (
        <g className={fancy ? "em-spin-rev" : undefined}>
          <circle cx="60" cy="60" r="46" fill="none" stroke="var(--tier-challenger-alt)" strokeWidth="1" strokeDasharray="1 4" opacity="0.9" />
        </g>
      )}
      {level === 8 && fancy && (
        <g className="em-spin-fast">
          {[0, 1, 2, 3].map((i) => {
            const a = (i / 4) * Math.PI * 2;
            return <circle key={i} cx={60 + Math.cos(a) * 56} cy={60 + Math.sin(a) * 56} r="2.2" fill="var(--tier-challenger-hi)" />;
          })}
        </g>
      )}

      <g className={fancy ? "em-float" : undefined} filter={level >= 4 ? `url(#${g("glow")})` : undefined}>
        {/* wings */}
        {level >= 3 && <Wings level={level} t={t} fill={t === "challenger" ? `url(#${g("chal")})` : `url(#${g("metal")})`} />}

        {/* crown */}
        {level >= 6 && <Crown level={level} t={t} fill={t === "challenger" ? `url(#${g("chal")})` : `url(#${g("metal")})`} />}

        {/* body */}
        <path d={bodyPath(level)} fill={`url(#${g("metal")})`} stroke={v(t, level <= 1 ? "lo" : "hi")} strokeWidth={level <= 1 ? 1.5 : 1} />
        {level >= 1 && <path d={innerPath(level)} fill={`url(#${g("inner")})`} opacity={level === 1 ? 0.5 : 0.85} />}

        {/* gem */}
        {level >= 3 && <Gem level={level} t={t} uidFill={t === "challenger" ? `url(#${g("chal")})` : undefined} />}

        {/* shimmer sweep */}
        {fancy && (
          <g clipPath={`url(#${g("clip")})`}>
            <rect x="20" y="10" width="40" height="100" fill={`url(#${g("shine")})`} className="em-shimmer" transform="skewX(-15)" />
          </g>
        )}
      </g>

      {/* sparkles */}
      {fancy && level >= 5 && (
        <g>
          {sparkles(level).map(([x, y, s, d], i) => (
            <path
              key={i}
              d={`M ${x} ${y - s} L ${x + s * 0.25} ${y - s * 0.25} L ${x + s} ${y} L ${x + s * 0.25} ${y + s * 0.25} L ${x} ${y + s} L ${x - s * 0.25} ${y + s * 0.25} L ${x - s} ${y} L ${x - s * 0.25} ${y - s * 0.25} Z`}
              fill={v(t, "hi")}
              className="em-twinkle"
              style={{ animationDelay: `${d}s` }}
            />
          ))}
        </g>
      )}

      {/* division pips */}
      <Pips division={division} level={level} t={t} />
    </svg>
  );
});

function bodyPath(level: number) {
  if (level <= 1) return "M60 22 L92 40 L92 76 L60 94 L28 76 L28 40 Z"; // hexagon
  if (level <= 4) return "M60 20 L90 30 L90 60 C90 78 76 90 60 98 C44 90 30 78 30 60 L30 30 Z"; // shield
  if (level === 5) return "M60 16 L88 44 L60 100 L32 44 Z"; // diamond
  return "M60 24 L88 36 L88 62 C88 80 74 92 60 100 C46 92 32 80 32 62 L32 36 Z"; // crowned shield
}

function innerPath(level: number) {
  if (level <= 1) return "M60 32 L83 45 L83 71 L60 84 L37 71 L37 45 Z";
  if (level <= 4) return "M60 29 L82 36 L82 60 C82 73 72 82 60 88 C48 82 38 73 38 60 L38 36 Z";
  if (level === 5) return "M60 28 L80 46 L60 88 L40 46 Z";
  return "M60 33 L80 42 L80 62 C80 75 71 84 60 90 C49 84 40 75 40 62 L40 42 Z";
}

function Wings({ level, t, fill }: { level: number; t: string; fill: string }) {
  const span = 10 + (level - 3) * 3;
  const feathers = level >= 6 ? 4 : level >= 4 ? 3 : 2;
  const side = (dir: 1 | -1) => (
    <g>
      {Array.from({ length: feathers }).map((_, i) => {
        const y = 40 + i * 9;
        const x0 = 60 + dir * 26;
        const x1 = 60 + dir * (26 + span + (feathers - i) * 4);
        return (
          <path
            key={i}
            d={`M ${x0} ${y} L ${x1} ${y - 6 + i * 2} L ${x0 + dir * 4} ${y + 7} Z`}
            fill={fill}
            stroke={v(t, "lo")}
            strokeWidth="0.6"
            opacity={1 - i * 0.12}
          />
        );
      })}
    </g>
  );
  return (
    <g>
      {side(-1)}
      {side(1)}
    </g>
  );
}

function Crown({ level, t, fill }: { level: number; t: string; fill: string }) {
  const tall = level === 8 ? 22 : level === 7 ? 18 : 14;
  const pts = level === 8 ? 5 : level === 7 ? 5 : 3;
  const w = 44;
  const x0 = 60 - w / 2;
  let d = `M ${x0} 30`;
  for (let i = 0; i < pts; i++) {
    const xa = x0 + (w / pts) * i;
    const xb = xa + w / pts / 2;
    const xc = xa + w / pts;
    const peak = i === Math.floor(pts / 2) ? tall + 4 : tall;
    d += ` L ${xb} ${30 - peak} L ${xc} 30`;
  }
  d += ` L ${x0 + w} 34 L ${x0} 34 Z`;
  return (
    <g>
      <path d={d} fill={fill} stroke={v(t, "hi")} strokeWidth="0.8" />
      {Array.from({ length: pts }).map((_, i) => {
        const xb = x0 + (w / pts) * i + w / pts / 2;
        const peak = i === Math.floor(pts / 2) ? tall + 4 : tall;
        return <circle key={i} cx={xb} cy={30 - peak} r={level === 8 ? 2.2 : 1.6} fill={level === 8 ? "var(--tier-challenger-alt)" : v(t, "hi")} />;
      })}
    </g>
  );
}

function Gem({ level, t, uidFill }: { level: number; t: string; uidFill?: string | undefined }) {
  const r = 7 + (level - 3) * 1.4;
  const cy = level === 5 ? 54 : 60;
  const fill = uidFill ?? v(t, "hi");
  return (
    <g>
      <path d={`M60 ${cy - r} L${60 + r} ${cy} L60 ${cy + r} L${60 - r} ${cy} Z`} fill={fill} />
      <path d={`M60 ${cy - r} L${60 + r} ${cy} L60 ${cy} Z`} fill="var(--foreground)" opacity="0.35" />
      <path d={`M60 ${cy} L60 ${cy + r} L${60 - r} ${cy} Z`} fill="var(--background)" opacity="0.25" />
    </g>
  );
}

function Pips({ division, level, t }: { division: number; level: number; t: string }) {
  const y = level >= 6 ? 108 : 106;
  const gap = 9;
  return (
    <g>
      {[0, 1, 2].map((i) => {
        const x = 60 + (i - 1) * gap;
        const on = i < division;
        const s = level >= 4 ? 3.4 : 3;
        return (
          <path
            key={i}
            d={`M ${x} ${y - s} L ${x + s} ${y} L ${x} ${y + s} L ${x - s} ${y} Z`}
            fill={on ? v(t, "hi") : "var(--muted)"}
            stroke={on ? v(t, "mid") : "var(--border)"}
            strokeWidth="0.6"
          />
        );
      })}
    </g>
  );
}

function sparkles(level: number): Array<[number, number, number, number]> {
  const base: Array<[number, number, number, number]> = [
    [24, 26, 4, 0],
    [98, 34, 3.5, 0.7],
    [96, 88, 3, 1.3],
    [22, 84, 3.5, 1.8],
  ];
  if (level >= 7) base.push([60, 6, 4.5, 0.4], [108, 60, 3.5, 1.1], [12, 56, 3.5, 1.6]);
  return base;
}

function Unranked({ size, className }: { size: number; className?: string | undefined }) {
  return (
    <svg width={size} height={size} viewBox="0 0 120 120" className={className} role="img" aria-label="unranked">
      <path d="M60 22 L92 40 L92 76 L60 94 L28 76 L28 40 Z" fill="var(--muted)" stroke="var(--border)" strokeWidth="1.5" strokeDasharray="4 3" />
      <text x="60" y="66" textAnchor="middle" fontSize="22" fontWeight="700" fill="var(--muted-foreground)" fontFamily="var(--font-display)">
        ?
      </text>
    </svg>
  );
}
