import { useEffect, useRef, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Terminal } from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";
import { COMMAND_HELP } from "@/lib/omok/commands";
import { runCommand } from "@/lib/omok/social.functions";

type Line = { kind: "in" | "ok" | "err"; text: string };

export function AdminConsole({ isAdmin }: { isAdmin: boolean }) {
  const [open, setOpen] = useState(false);
  const [lines, setLines] = useState<Line[]>(() => COMMAND_HELP.map((text) => ({ kind: "ok" as const, text })));
  const [cmd, setCmd] = useState("");
  const [busy, setBusy] = useState(false);
  const run = useServerFn(runCommand);
  const qc = useQueryClient();
  const logRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    logRef.current?.scrollTo({ top: logRef.current.scrollHeight });
  }, [lines]);

  function openConsole() {
    if (!isAdmin) {
      toast.error("관리자가 아닙니다");
      return;
    }
    setOpen(true);
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    const command = cmd.trim();
    if (!command || busy) return;
    setCmd("");
    setLines((l) => [...l, { kind: "in", text: command }]);
    setBusy(true);
    try {
      const r = await run({ data: { command } });
      setLines((l) => [...l, ...r.message.split("\n").map((text) => ({ kind: r.ok ? ("ok" as const) : ("err" as const), text }))]);
      if (r.ok) {
        void qc.invalidateQueries({ queryKey: ["me"] });
        void qc.invalidateQueries({ queryKey: ["leaderboard"] });
        void qc.invalidateQueries({ queryKey: ["inventory"] });
      }
    } catch (err) {
      setLines((l) => [...l, { kind: "err", text: err instanceof Error ? err.message : "실행 실패" }]);
    } finally {
      setBusy(false);
    }
  }

  return (
    <>
      <Button variant="ghost" size="icon" onClick={openConsole} aria-label="명령어 창">
        <Terminal className="size-4" />
      </Button>
      {isAdmin && (
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogContent className="max-w-lg">
            <DialogHeader>
              <DialogTitle className="label-caps text-foreground">Console</DialogTitle>
            </DialogHeader>
            <div ref={logRef} className="h-64 overflow-y-auto rounded-md border border-border bg-background p-3 font-mono text-xs leading-relaxed">
              {lines.map((l, i) => (
                <div key={i} className={cn(l.kind === "in" ? "text-primary" : l.kind === "err" ? "text-destructive" : "text-muted-foreground")}>
                  {l.kind === "in" ? "> " : ""}
                  {l.text}
                </div>
              ))}
            </div>
            <form onSubmit={submit} className="flex gap-2">
              <Input value={cmd} onChange={(e) => setCmd(e.target.value)} placeholder="/give닉네임100" className="font-mono" autoFocus />
              <Button type="submit" disabled={busy || !cmd.trim()}>
                실행
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      )}
    </>
  );
}
