import { useEffect, useRef } from "react";
import { useNavigate } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";

import { supabase } from "@/integrations/supabase/client";
import { audio } from "@/lib/omok/audio";
import { respondInvite } from "@/lib/omok/social.functions";

const TTL = 60_000;

/** Shows incoming friendly-match invites as toasts with accept / decline. */
export function InviteWatcher({ myId }: { myId: string }) {
  const navigate = useNavigate();
  const respond = useServerFn(respondInvite);
  const shown = useRef(new Set<string>());

  useEffect(() => {
    let alive = true;

    async function show(invite: { id: string; from_id: string; created_at: string; status: string }) {
      if (invite.status !== "pending" || shown.current.has(invite.id)) return;
      const left = TTL - (Date.now() - new Date(invite.created_at).getTime());
      if (left <= 1000) return;
      shown.current.add(invite.id);
      const { data: from } = await supabase.from("profiles").select("nickname").eq("id", invite.from_id).maybeSingle();
      if (!alive) return;
      audio().chime("match");
      toast(`${from?.nickname ?? "누군가"}님의 친선 대국 신청`, {
        id: invite.id,
        description: "수락하면 바로 대국이 시작됩니다.",
        duration: left,
        action: {
          label: "수락",
          onClick: async () => {
            try {
              const r = await respond({ data: { id: invite.id, accept: true } });
              if (r.gameId) navigate({ to: "/game/$gameId", params: { gameId: r.gameId } });
            } catch (e) {
              toast.error(e instanceof Error ? e.message : "수락할 수 없습니다.");
            }
          },
        },
        cancel: {
          label: "거절",
          onClick: () => void respond({ data: { id: invite.id, accept: false } }).catch(() => undefined),
        },
      });
    }

    supabase
      .from("game_invites")
      .select("id, from_id, created_at, status")
      .eq("to_id", myId)
      .eq("status", "pending")
      .gte("created_at", new Date(Date.now() - TTL).toISOString())
      .then(({ data }) => (data ?? []).forEach((i) => void show(i)));

    const ch = supabase
      .channel(`invites-${myId}`)
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "game_invites", filter: `to_id=eq.${myId}` }, (payload) =>
        void show(payload.new as { id: string; from_id: string; created_at: string; status: string }),
      )
      .on("postgres_changes", { event: "UPDATE", schema: "public", table: "game_invites", filter: `to_id=eq.${myId}` }, (payload) => {
        const n = payload.new as { id: string; status: string };
        if (n.status === "cancelled") toast.dismiss(n.id);
      })
      .subscribe();

    return () => {
      alive = false;
      void supabase.removeChannel(ch);
    };
  }, [myId, navigate, respond]);

  return null;
}
