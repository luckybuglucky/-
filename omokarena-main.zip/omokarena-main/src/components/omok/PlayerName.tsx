import { memo } from "react";

import { cn } from "@/lib/utils";
import { titleStyle } from "@/lib/omok/cosmetics";
import { PLACEMENT_GAMES, rankFromRating } from "@/lib/omok/rank";

type Props = {
  nickname: string;
  rating: number;
  placementGames: number;
  position?: number | undefined; // leaderboard position if in top 10
  title?: string | null | undefined; // equipped title
  color?: string | null | undefined; // equipped nickname color id
  className?: string | undefined;
  showTitle?: boolean | undefined;
};

export function tierClass(rating: number, placementGames: number) {
  return placementGames >= PLACEMENT_GAMES ? `nick-${rankFromRating(rating).tier}` : "nick-unranked";
}

export function nickClass(rating: number, placementGames: number, color?: string | null) {
  return color ? `nick-c-${color}` : tierClass(rating, placementGames);
}

export function TitleBadge({ title, className }: { title: string; className?: string | undefined }) {
  return <span className={cn("title-badge shrink-0", `title-${titleStyle(title)}`, className)}>{title}</span>;
}

export const PlayerName = memo(function PlayerName({
  nickname,
  rating,
  placementGames,
  position,
  title,
  color,
  className,
  showTitle = true,
}: Props) {
  const isRanker = position !== undefined && position <= 10;
  return (
    <span className={cn("inline-flex min-w-0 items-center gap-1.5", className)}>
      <span className={cn("truncate font-semibold", nickClass(rating, placementGames, color))}>{nickname}</span>
      {showTitle && title && <TitleBadge title={title} />}
      {showTitle && isRanker && <span className="ranker-badge shrink-0">랭커</span>}
      {position !== undefined && position <= 3 && <RankCrown position={position} />}
    </span>
  );
});

export function RankCrown({ position, size = 18 }: { position: number; size?: number }) {
  const color = position === 1 ? "var(--crown-gold)" : position === 2 ? "var(--crown-silver)" : "var(--crown-bronze)";
  const label = position === 1 ? "금관" : position === 2 ? "은관" : "동관";
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" aria-label={label} role="img" className="shrink-0">
      <path d="M3 18 L4.5 7 L9 11.5 L12 5 L15 11.5 L19.5 7 L21 18 Z" fill={color} />
      <rect x="3" y="18.5" width="18" height="2.5" rx="0.6" fill={color} />
      <circle cx="12" cy="5" r="1.4" fill={color} />
      <circle cx="4.5" cy="7" r="1.2" fill={color} />
      <circle cx="19.5" cy="7" r="1.2" fill={color} />
      <path d="M3 18 L4.5 7 L9 11.5 L12 5 L15 11.5 L19.5 7 L21 18 Z" fill="var(--foreground)" opacity="0.15" />
    </svg>
  );
}
