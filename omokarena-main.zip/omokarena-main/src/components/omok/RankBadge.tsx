import { PLACEMENT_GAMES, rankFromRating } from "@/lib/omok/rank";
import { TierEmblem } from "./TierEmblem";

type Props = { rating: number; placementGames: number; size?: number; animated?: boolean };

export function RankEmblem({ rating, placementGames, size = 48, animated = false }: Props) {
  if (placementGames < PLACEMENT_GAMES) return <TierEmblem tier={null} size={size} />;
  const r = rankFromRating(rating);
  return <TierEmblem tier={r.tier} division={r.division} size={size} animated={animated} />;
}

export function rankLabel(rating: number, placementGames: number) {
  if (placementGames < PLACEMENT_GAMES) return `배치 ${placementGames}/${PLACEMENT_GAMES}`;
  return rankFromRating(rating).label;
}

export function RpBar({ rating, placementGames }: { rating: number; placementGames: number }) {
  if (placementGames < PLACEMENT_GAMES) {
    return (
      <div className="space-y-1.5">
        <div className="rp-bar">
          <span style={{ width: `${(placementGames / PLACEMENT_GAMES) * 100}%` }} />
        </div>
        <p className="text-xs text-muted-foreground">
          배치고사 {placementGames} / {PLACEMENT_GAMES}
        </p>
      </div>
    );
  }
  const r = rankFromRating(rating);
  const pct = Math.min(100, (r.rp / r.size) * 100);
  return (
    <div className="space-y-1.5">
      <div className="rp-bar">
        <span style={{ width: `${pct}%` }} />
      </div>
      <p className="font-display text-xs tracking-wider text-muted-foreground">
        {r.rp} / {r.size} RP
      </p>
    </div>
  );
}
