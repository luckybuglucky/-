import type { ReactNode } from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { Coins, LogOut, Shield } from "lucide-react";

import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { useMe, useMusic, useRankerMap } from "@/lib/omok/hooks";
import { PlayerName } from "./PlayerName";
import { RankEmblem } from "./RankBadge";
import { SoundControl } from "./SoundControl";
import { AdminConsole } from "./AdminConsole";
import { InviteWatcher } from "./InviteWatcher";

const NAV = [
  { to: "/lobby", label: "로비" },
  { to: "/leaderboard", label: "순위표" },
  { to: "/friends", label: "친구" },
  { to: "/inventory", label: "인벤토리" },
  { to: "/shop", label: "상점" },
  { to: "/tiers", label: "티어" },
] as const;

export function AppShell({ children }: { children: ReactNode }) {
  useMusic("lobby");
  const { data } = useMe();
  const rankers = useRankerMap();
  const qc = useQueryClient();
  const navigate = useNavigate();
  const p = data?.profile;

  async function signOut() {
    await qc.cancelQueries();
    qc.clear();
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  }

  return (
    <div className="min-h-screen">
      <header className="sticky top-0 z-30 border-b border-border/70 bg-background/80 backdrop-blur-md">
        <div className="mx-auto flex h-14 max-w-6xl items-center gap-6 px-4">
          <Link to="/lobby" className="wordmark text-sm text-foreground">
            Omok<span className="text-primary"> Arena</span>
          </Link>
          <nav className="hidden items-center gap-1 md:flex">
            {NAV.map((n) => (
              <Link
                key={n.to}
                to={n.to}
                className="rounded-md px-3 py-1.5 text-sm text-muted-foreground transition-colors hover:text-foreground"
                activeProps={{ className: "bg-secondary text-foreground" }}
              >
                {n.label}
              </Link>
            ))}
          </nav>
          <div className="ml-auto flex items-center gap-2">
            {p && (
              <>
                <div className="hidden items-center gap-3 rounded-md border border-border px-2.5 py-1 text-xs sm:flex">
                  <span className="flex items-center gap-1 text-primary">
                    <Coins className="size-3.5" />
                    <span className="font-display text-sm font-semibold">{p.bp}</span>
                    <span className="text-muted-foreground">BP</span>
                  </span>
                  <span className="flex items-center gap-1 text-muted-foreground">
                    <Shield className="size-3.5" />
                    <span className="font-display text-sm font-semibold text-foreground">{p.shields}</span>
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <RankEmblem rating={p.rating} placementGames={p.placement_games} size={28} />
                  <PlayerName
                    nickname={p.nickname}
                    rating={p.rating}
                    placementGames={p.placement_games}
                    position={rankers.get(p.id)}
                title={p.equipped_title}
                color={p.equipped_color}
                    className="hidden max-w-40 text-sm sm:inline-flex"
                  />
                </div>
              </>
            )}
            <AdminConsole isAdmin={!!data?.isAdmin} />
            <SoundControl />
            <Button variant="ghost" size="icon" onClick={signOut} aria-label="로그아웃">
              <LogOut className="size-4" />
            </Button>
          </div>
        </div>
        <nav className="flex items-center gap-1 overflow-x-auto border-t border-border/60 px-3 py-1.5 md:hidden">
          {NAV.map((n) => (
            <Link
              key={n.to}
              to={n.to}
              className="shrink-0 rounded-md px-3 py-1 text-sm text-muted-foreground"
              activeProps={{ className: "bg-secondary text-foreground" }}
            >
              {n.label}
            </Link>
          ))}
        </nav>
      </header>
      {p && <InviteWatcher myId={p.id} />}
      <main className="mx-auto max-w-6xl px-4 py-8">{children}</main>
    </div>
  );
}
