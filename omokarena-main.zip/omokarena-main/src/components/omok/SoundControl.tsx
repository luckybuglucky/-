import { useEffect, useState } from "react";
import { Music, Volume2, VolumeX } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { audio, type AudioSettings } from "@/lib/omok/audio";

export function SoundControl() {
  const [s, setS] = useState<AudioSettings | null>(null);

  useEffect(() => {
    const a = audio();
    a.loadSettings();
    setS({ ...a.settings });
    return a.subscribe(() => setS({ ...a.settings })) as () => void;
  }, []);

  const muted = s?.muted ?? false;

  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="icon" aria-label="사운드 설정">
          {muted ? <VolumeX className="size-4" /> : <Volume2 className="size-4" />}
        </Button>
      </PopoverTrigger>
      <PopoverContent align="end" className="w-64 space-y-4">
        <div className="flex items-center justify-between">
          <span className="text-sm font-medium">사운드</span>
          <Switch checked={!muted} onCheckedChange={(v) => audio().update({ muted: !v })} aria-label="사운드 켜기" />
        </div>
        <div className="space-y-2">
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <Music className="size-3.5" /> 배경 음악
          </div>
          <Slider
            value={[Math.round((s?.music ?? 0.55) * 100)]}
            max={100}
            step={1}
            onValueChange={([v]) => audio().update({ music: (v ?? 0) / 100 })}
          />
        </div>
        <div className="space-y-2">
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <Volume2 className="size-3.5" /> 효과음
          </div>
          <Slider
            value={[Math.round((s?.sfx ?? 0.8) * 100)]}
            max={100}
            step={1}
            onValueChange={([v]) => {
              audio().update({ sfx: (v ?? 0) / 100 });
              audio().stone();
            }}
          />
        </div>
      </PopoverContent>
    </Popover>
  );
}
