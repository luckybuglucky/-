import { memo, useMemo, useState } from "react";

import { at, boardFromMoves, SIZE, type Color, type Move } from "@/lib/omok/rules";

const CELL = 40;
const PAD = 28;
const W = PAD * 2 + CELL * (SIZE - 1);
const STARS: Move[] = [
  [3, 3],
  [3, 11],
  [7, 7],
  [11, 3],
  [11, 11],
];

type Props = {
  moves: Move[];
  pending?: Move | null;
  canPlay: boolean;
  myColor: Color | null;
  winLine?: Move[] | null;
  onPlay?: (x: number, y: number) => void;
};

export function findWinLine(moves: Move[]): Move[] | null {
  if (!moves.length) return null;
  const b = boardFromMoves(moves);
  const lastMove = moves[moves.length - 1];
  if (!lastMove) return null;
  const [x, y] = lastMove;
  const c = b[y * SIZE + x];
  const dirs: Array<[number, number]> = [
    [1, 0],
    [0, 1],
    [1, 1],
    [1, -1],
  ];
  for (const [dx, dy] of dirs) {
    const line: Move[] = [[x, y]];
    let k = 1;
    while (at(b, x - k * dx, y - k * dy) === c) line.unshift([x - k * dx, y - k * dy]), k++;
    k = 1;
    while (at(b, x + k * dx, y + k * dy) === c) line.push([x + k * dx, y + k * dy]), k++;
    if (line.length >= 5) return line;
  }
  return null;
}

const Grid = memo(function Grid() {
  const lines = [];
  for (let i = 0; i < SIZE; i++) {
    const p = PAD + i * CELL;
    lines.push(<line key={`h${i}`} x1={PAD} y1={p} x2={W - PAD} y2={p} />);
    lines.push(<line key={`v${i}`} x1={p} y1={PAD} x2={p} y2={W - PAD} />);
  }
  return (
    <g>
      <g stroke="var(--board-line)" strokeWidth="1" opacity="0.75">
        {lines}
      </g>
      <rect x={PAD} y={PAD} width={CELL * (SIZE - 1)} height={CELL * (SIZE - 1)} fill="none" stroke="var(--board-line)" strokeWidth="1.6" />
      {STARS.map(([x, y]) => (
        <circle key={`${x}-${y}`} cx={PAD + x * CELL} cy={PAD + y * CELL} r="3.6" fill="var(--board-line)" />
      ))}
    </g>
  );
});

const Stones = memo(function Stones({ moves }: { moves: Move[] }) {
  return (
    <g>
      {moves.map(([x, y], i) => (
        <circle
          key={`${x}-${y}`}
          cx={PAD + x * CELL}
          cy={PAD + y * CELL}
          r={CELL * 0.45}
          fill={i % 2 === 0 ? "url(#stone-black)" : "url(#stone-white)"}
          filter="url(#stone-shadow)"
          className="stone-in"
        />
      ))}
    </g>
  );
});

export const Board = memo(function Board({ moves, pending, canPlay, myColor, winLine, onPlay }: Props) {
  const [hover, setHover] = useState<Move | null>(null);
  const occupied = useMemo(() => {
    const s = new Set<number>();
    moves.forEach(([x, y]) => s.add(y * SIZE + x));
    if (pending) s.add(pending[1] * SIZE + pending[0]);
    return s;
  }, [moves, pending]);

  const last = moves[moves.length - 1];
  const lastColor: Color = moves.length % 2 === 1 ? 1 : 2;

  function cellFromEvent(e: React.PointerEvent<SVGSVGElement>): Move | null {
    const rect = e.currentTarget.getBoundingClientRect();
    const sx = ((e.clientX - rect.left) / rect.width) * W;
    const sy = ((e.clientY - rect.top) / rect.height) * W;
    const x = Math.round((sx - PAD) / CELL);
    const y = Math.round((sy - PAD) / CELL);
    if (x < 0 || y < 0 || x >= SIZE || y >= SIZE) return null;
    return [x, y];
  }

  const ghost = canPlay && hover && !occupied.has(hover[1] * SIZE + hover[0]) ? hover : null;

  return (
    <div className="board-surface relative aspect-square w-full overflow-hidden rounded-xl">
      <svg
        viewBox={`0 0 ${W} ${W}`}
        className={canPlay ? "block h-full w-full cursor-pointer touch-manipulation" : "block h-full w-full"}
        onPointerMove={(e) => {
          if (!canPlay || e.pointerType !== "mouse") return;
          const c = cellFromEvent(e);
          if (!c || !hover || c[0] !== hover[0] || c[1] !== hover[1]) setHover(c);
        }}
        onPointerLeave={() => setHover(null)}
        onPointerUp={(e) => {
          if (!canPlay || !onPlay) return;
          const c = cellFromEvent(e);
          if (c && !occupied.has(c[1] * SIZE + c[0])) onPlay(c[0], c[1]);
        }}
      >
        <defs>
          <radialGradient id="stone-black" cx="0.35" cy="0.3" r="0.75">
            <stop offset="0" style={{ stopColor: "var(--stone-black-hi)" }} />
            <stop offset="1" style={{ stopColor: "var(--stone-black)" }} />
          </radialGradient>
          <radialGradient id="stone-white" cx="0.35" cy="0.3" r="0.8">
            <stop offset="0" style={{ stopColor: "var(--stone-white-hi)" }} />
            <stop offset="1" style={{ stopColor: "var(--stone-white)" }} />
          </radialGradient>
          <filter id="stone-shadow" x="-30%" y="-30%" width="160%" height="160%">
            <feDropShadow dx="1.2" dy="2" stdDeviation="1.6" floodOpacity="0.45" />
          </filter>
        </defs>
        <Grid />
        <Stones moves={moves} />
        {pending && (
          <circle
            cx={PAD + pending[0] * CELL}
            cy={PAD + pending[1] * CELL}
            r={CELL * 0.45}
            fill={myColor === 1 ? "url(#stone-black)" : "url(#stone-white)"}
            filter="url(#stone-shadow)"
            className="stone-in"
          />
        )}
        {ghost && (
          <circle
            cx={PAD + ghost[0] * CELL}
            cy={PAD + ghost[1] * CELL}
            r={CELL * 0.45}
            fill={myColor === 1 ? "var(--stone-black)" : "var(--stone-white)"}
            opacity="0.35"
            pointerEvents="none"
          />
        )}
        {last && !pending && (
          <circle
            cx={PAD + last[0] * CELL}
            cy={PAD + last[1] * CELL}
            r="4.5"
            fill={lastColor === 1 ? "var(--primary)" : "var(--destructive)"}
            pointerEvents="none"
          />
        )}
        {winLine && winLine.length > 1 && (
          <line
            x1={PAD + winLine[0]![0] * CELL}
            y1={PAD + winLine[0]![1] * CELL}
            x2={PAD + winLine[winLine.length - 1]![0] * CELL}
            y2={PAD + winLine[winLine.length - 1]![1] * CELL}
            stroke="var(--primary)"
            strokeWidth="5"
            strokeLinecap="round"
            opacity="0.85"
            pointerEvents="none"
          />
        )}
      </svg>
    </div>
  );
});
