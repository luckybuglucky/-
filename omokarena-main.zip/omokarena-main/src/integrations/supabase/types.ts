export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.18"
  }
  public: {
    Tables: {
      friendships: {
        Row: {
          addressee_id: string
          created_at: string
          id: string
          requester_id: string
          status: string
        }
        Insert: {
          addressee_id: string
          created_at?: string
          id?: string
          requester_id: string
          status?: string
        }
        Update: {
          addressee_id?: string
          created_at?: string
          id?: string
          requester_id?: string
          status?: string
        }
        Relationships: [
          {
            foreignKeyName: "friendships_addressee_id_fkey"
            columns: ["addressee_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "friendships_requester_id_fkey"
            columns: ["requester_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      game_invites: {
        Row: {
          created_at: string
          from_id: string
          game_id: string | null
          id: string
          mode: string
          status: string
          to_id: string
        }
        Insert: {
          created_at?: string
          from_id: string
          game_id?: string | null
          id?: string
          mode?: string
          status?: string
          to_id: string
        }
        Update: {
          created_at?: string
          from_id?: string
          game_id?: string | null
          id?: string
          mode?: string
          status?: string
          to_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "game_invites_from_id_fkey"
            columns: ["from_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "game_invites_to_id_fkey"
            columns: ["to_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      game_messages: {
        Row: {
          censored: boolean
          content: string
          created_at: string
          game_id: string
          id: string
          user_id: string
        }
        Insert: {
          censored?: boolean
          content: string
          created_at?: string
          game_id: string
          id?: string
          user_id: string
        }
        Update: {
          censored?: boolean
          content?: string
          created_at?: string
          game_id?: string
          id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "game_messages_game_id_fkey"
            columns: ["game_id"]
            isOneToOne: false
            referencedRelation: "games"
            referencedColumns: ["id"]
          },
        ]
      }
      games: {
        Row: {
          ai_level: string | null
          black_id: string | null
          created_at: string
          end_reason: string | null
          finished_at: string | null
          friendly: boolean
          id: string
          mode: string
          move_count: number
          moves: Json
          paused_until: string | null
          result: Json | null
          status: string
          turn_started_at: string
          vs_ai: boolean
          white_id: string | null
          winner: string | null
        }
        Insert: {
          ai_level?: string | null
          black_id?: string | null
          created_at?: string
          end_reason?: string | null
          finished_at?: string | null
          friendly?: boolean
          id?: string
          mode: string
          move_count?: number
          moves?: Json
          paused_until?: string | null
          result?: Json | null
          status?: string
          turn_started_at?: string
          vs_ai?: boolean
          white_id?: string | null
          winner?: string | null
        }
        Update: {
          ai_level?: string | null
          black_id?: string | null
          created_at?: string
          end_reason?: string | null
          finished_at?: string | null
          friendly?: boolean
          id?: string
          mode?: string
          move_count?: number
          moves?: Json
          paused_until?: string | null
          result?: Json | null
          status?: string
          turn_started_at?: string
          vs_ai?: boolean
          white_id?: string | null
          winner?: string | null
        }
        Relationships: []
      }
      match_queue: {
        Row: {
          created_at: string
          heartbeat_at: string
          mmr: number
          mode: string
          user_id: string
        }
        Insert: {
          created_at?: string
          heartbeat_at?: string
          mmr?: number
          mode: string
          user_id: string
        }
        Update: {
          created_at?: string
          heartbeat_at?: string
          mmr?: number
          mode?: string
          user_id?: string
        }
        Relationships: []
      }
      notices: {
        Row: {
          content: string
          created_at: string
          from_id: string | null
          from_nickname: string | null
          id: string
          kind: string
          to_id: string | null
          to_nickname: string | null
        }
        Insert: {
          content?: string
          created_at?: string
          from_id?: string | null
          from_nickname?: string | null
          id?: string
          kind: string
          to_id?: string | null
          to_nickname?: string | null
        }
        Update: {
          content?: string
          created_at?: string
          from_id?: string | null
          from_nickname?: string | null
          id?: string
          kind?: string
          to_id?: string | null
          to_nickname?: string | null
        }
        Relationships: []
      }
      profile_colors: {
        Row: {
          color: string
          created_at: string
          user_id: string
        }
        Insert: {
          color: string
          created_at?: string
          user_id: string
        }
        Update: {
          color?: string
          created_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "profile_colors_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      profile_titles: {
        Row: {
          created_at: string
          title: string
          user_id: string
        }
        Insert: {
          created_at?: string
          title: string
          user_id: string
        }
        Update: {
          created_at?: string
          title?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "profile_titles_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          bp: number
          chat_warnings: number
          created_at: string
          equipped_color: string | null
          equipped_title: string | null
          id: string
          kicked_until: string | null
          last_seen_at: string
          loss_streak: number
          losses: number
          mmr: number
          muted_until: string | null
          nickname: string
          placement_games: number
          placement_perfect: boolean
          placement_score: number
          ranked_losses: number
          ranked_wins: number
          rating: number
          shields: number
          win_streak: number
          wins: number
        }
        Insert: {
          bp?: number
          chat_warnings?: number
          created_at?: string
          equipped_color?: string | null
          equipped_title?: string | null
          id: string
          kicked_until?: string | null
          last_seen_at?: string
          loss_streak?: number
          losses?: number
          mmr?: number
          muted_until?: string | null
          nickname: string
          placement_games?: number
          placement_perfect?: boolean
          placement_score?: number
          ranked_losses?: number
          ranked_wins?: number
          rating?: number
          shields?: number
          win_streak?: number
          wins?: number
        }
        Update: {
          bp?: number
          chat_warnings?: number
          created_at?: string
          equipped_color?: string | null
          equipped_title?: string | null
          id?: string
          kicked_until?: string | null
          last_seen_at?: string
          loss_streak?: number
          losses?: number
          mmr?: number
          muted_until?: string | null
          nickname?: string
          placement_games?: number
          placement_perfect?: boolean
          placement_score?: number
          ranked_losses?: number
          ranked_wins?: number
          rating?: number
          shields?: number
          win_streak?: number
          wins?: number
        }
        Relationships: []
      }
      redeemed_codes: {
        Row: {
          code: string
          created_at: string
          user_id: string
        }
        Insert: {
          code: string
          created_at?: string
          user_id: string
        }
        Update: {
          code?: string
          created_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "redeemed_codes_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      grant_developer_perks: { Args: { _user: string }; Returns: undefined }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      nickname_taken: { Args: { _nickname: string }; Returns: boolean }
      try_match: { Args: { _mode: string; _user: string }; Returns: string }
    }
    Enums: {
      app_role: "admin" | "user" | "developer"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "user", "developer"],
    },
  },
} as const
