# Roadmap

- [x] Redeem code RELEASE (+25 BP, once per account)
- [x] RP scaled by rating gap
- [x] Hidden MMR with streak bonus; matchmaking by MMR
- [x] Lobby options: random / friendly (by nickname invite) / AI
- [x] Sign-up: taken nickname shows "이미 사용 중인 닉네임입니다"
- [x] Titles: 불굴 (10 win streak), 불운 (5 loss streak), 개발자 (러키)
- [x] Inventory: equip owned title + nickname color
- [x] Admin console for 러키; others see "관리자가 아닙니다"
- [x] 러키 gets 개발자 title + rainbow color
- [x] Placement cap: Platinum 3 only with 5/5 wins each within 20 own moves
- [x] AI level 1 & 2 wins give reduced rewards

## Batch 3
- [ ] Placement "20수" counts all stones (both players)
- [ ] ~50 shop items (titles + colors) with rarities 희귀20/초희귀30/에픽40/전설75/시크릿175
- [ ] 태극 color (red/blue alternating) + 잭팟 title = secret, ~5% daily-shop chance
- [ ] Daily shop: 4 random items; excludes rainbow, 불굴, 불운, 개발자, 챔피언
- [ ] 챔피언 title only while #1 (developer keeps all items)
- [ ] 러키 owns every item
- [ ] Win: 0.5% chance of 150 BP
- [ ] Codes UPD1, ILOVECAT, OMOK
- [ ] Friendly matches count toward score (sender picks 경쟁전/일반전)
- [ ] Admin commands: /op /unop /clear /tier /untier /del /give…all /show /hide /call /A /k /stop
- [ ] /귓속말 for everyone + separate player command button
