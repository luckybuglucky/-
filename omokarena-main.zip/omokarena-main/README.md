# Omokarena

오케이 자 게임은 오목이고 이 게임의 방식은 경쟁전과 일반전이 있고 ai대국과 플레이어 대국을 할 수있게 해주고 경쟁전 5판을하면 배치를 받고 배치 받는 기준은 성과점수 얼마나 실력을 써서 이겼냐를 기준으로 해주고 적은 수로 이기면 성과 점수가 높아지는방식이고 티어는 아이언, 브론즈, 실버, 골드, 플레티넘, 다이아, 마스터, 그랜드 마스터, 챌린저임 그리고 모든 티어에는 1, 2, 3 단계가 있고 3단계에서 승급하면 다음 티어로 넘어가고 경쟁전 RP를 100까지 올릴때마다 단계나 티어가 올라가고 마스터부터는 150점을 올려야하게 하고 가장 RP가 높은 사람이 위에 가는 순위표를 만들고 계정 생성방식을 닉네임과 비밀번호를 만들어서 하면 되는 간단한 방식에 게임 할때 돌을 두는 소리와 잔잔한 배경 음악 대국하는 플레이어끼리 채팅이 가능하게하고 욕설은 검열되게하고 1분간 아무 행동이 없으면 자동 패배처리되며 반칙수를 하면 패배 어쨌든 모든 오목 규칙을 기반으로하며 욕설 경고가 많아지면 몇분간 채팅 금지가 되게해주고 티어 그림은 낮으면 낮을수록 별로 안예쁘고 높아지면 화려하며 닉네임의 색깔이 달라지게 그리고 순위권 10등 안은 랭커로 되며 랭커 칭호가 붙여지며 랭킹 1등은 금관 2등은 은관 3등은 동관그림이 닉네임과 칭호옆에 붙게해주고 일반전이나 경쟁전을 이기면 주는 BP를 모아서 강등 방어권을 사게해줘 그러나 쉽게 살수있는 가격은 안되고 꽤 많이 모아야함 100개 한판당 1에서 5 BP를 주게하며 개수는 랜덤으로 그리고 게임 시작했을때 음악과 로비 음악은 다르게 그리고 게임에서 나갈시 RP 소량 소모로해줘 퀄리티는 높게하고 렉을 줄여줘 그리고 게임을 되게 심플하지만 유치하지 않게 그냥 오목 아레나 이런식으로 해주고 글씨체를 깔끔하게 그냥 직선으로 해주고 티어도 플래티넘정도부턴 꽤 많이 화려하게 해주고 챌린저근처는 엄청 화려하게 그리고 티어 1, 2, 3단계에 따라 조금의 차이를 줘 게임 들어가서도 모던하게 음악도 잔잔한 음악으로 기분 좋게 그리고 친구추가 기능도 넣어줘

This project was built with [Lovable](https://lovable.dev).

**Live app**: https://omokarena.lovable.app

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/e36fa6ac-c282-4f15-b0a8-a5f85a6b795a).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
