-- Profile additions
ALTER TABLE public.profiles
  ADD COLUMN mmr integer NOT NULL DEFAULT 600,
  ADD COLUMN win_streak integer NOT NULL DEFAULT 0,
  ADD COLUMN loss_streak integer NOT NULL DEFAULT 0,
  ADD COLUMN equipped_title text,
  ADD COLUMN equipped_color text;

ALTER TABLE public.games ADD COLUMN friendly boolean NOT NULL DEFAULT false;
ALTER TABLE public.match_queue ADD COLUMN mmr integer NOT NULL DEFAULT 600;

-- Owned titles
CREATE TABLE public.profile_titles (
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  title text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, title)
);
GRANT SELECT ON public.profile_titles TO authenticated;
GRANT ALL ON public.profile_titles TO service_role;
ALTER TABLE public.profile_titles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users view own titles" ON public.profile_titles
  FOR SELECT TO authenticated USING (auth.uid() = user_id);

-- Owned nickname colors
CREATE TABLE public.profile_colors (
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  color text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, color)
);
GRANT SELECT ON public.profile_colors TO authenticated;
GRANT ALL ON public.profile_colors TO service_role;
ALTER TABLE public.profile_colors ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users view own colors" ON public.profile_colors
  FOR SELECT TO authenticated USING (auth.uid() = user_id);

-- Redeemed codes (one use per account)
CREATE TABLE public.redeemed_codes (
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  code text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, code)
);
GRANT SELECT ON public.redeemed_codes TO authenticated;
GRANT ALL ON public.redeemed_codes TO service_role;
ALTER TABLE public.redeemed_codes ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users view own redeemed codes" ON public.redeemed_codes
  FOR SELECT TO authenticated USING (auth.uid() = user_id);

-- Friendly match invites
CREATE TABLE public.game_invites (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  from_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  to_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','accepted','declined','cancelled')),
  game_id uuid,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX game_invites_to_idx ON public.game_invites (to_id, status);
CREATE INDEX game_invites_from_idx ON public.game_invites (from_id, status);
GRANT SELECT ON public.game_invites TO authenticated;
GRANT ALL ON public.game_invites TO service_role;
ALTER TABLE public.game_invites ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Players view their invites" ON public.game_invites
  FOR SELECT TO authenticated USING (auth.uid() = from_id OR auth.uid() = to_id);
ALTER PUBLICATION supabase_realtime ADD TABLE public.game_invites;

-- Roles
CREATE TYPE public.app_role AS ENUM ('admin', 'user');
CREATE TABLE public.user_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role public.app_role NOT NULL,
  UNIQUE (user_id, role)
);
GRANT SELECT ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users view own roles" ON public.user_roles
  FOR SELECT TO authenticated USING (auth.uid() = user_id);

CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role public.app_role)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role)
$$;

-- Nickname availability check for the sign-up screen
CREATE OR REPLACE FUNCTION public.nickname_taken(_nickname text)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.profiles WHERE lower(nickname) = lower(trim(_nickname)))
$$;
GRANT EXECUTE ON FUNCTION public.nickname_taken(text) TO anon, authenticated;

-- Developer perks for the developer account
CREATE OR REPLACE FUNCTION public.grant_developer_perks(_user uuid)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.user_roles (user_id, role) VALUES (_user, 'admin') ON CONFLICT DO NOTHING;
  INSERT INTO public.profile_titles (user_id, title) VALUES (_user, '개발자') ON CONFLICT DO NOTHING;
  INSERT INTO public.profile_colors (user_id, color) VALUES (_user, 'rainbow') ON CONFLICT DO NOTHING;
  UPDATE public.profiles SET equipped_title = '개발자', equipped_color = 'rainbow' WHERE id = _user;
END;
$$;
REVOKE EXECUTE ON FUNCTION public.grant_developer_perks(uuid) FROM PUBLIC, anon, authenticated;

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  _nick text := COALESCE(NULLIF(NEW.raw_user_meta_data->>'nickname', ''), 'player_' || substr(NEW.id::text, 1, 6));
BEGIN
  INSERT INTO public.profiles (id, nickname) VALUES (NEW.id, _nick);
  IF _nick = '러키' THEN
    PERFORM public.grant_developer_perks(NEW.id);
  END IF;
  RETURN NEW;
END;
$$;

SELECT public.grant_developer_perks(id) FROM public.profiles WHERE nickname = '러키';

-- MMR-aware matchmaking: closest MMR first, search window widens while waiting
CREATE OR REPLACE FUNCTION public.try_match(_user uuid, _mode text)
RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  _self public.match_queue%ROWTYPE;
  _opp uuid;
  _game uuid;
BEGIN
  SELECT * INTO _self FROM public.match_queue WHERE user_id = _user AND mode = _mode FOR UPDATE;
  IF _self.user_id IS NULL THEN
    RETURN NULL;
  END IF;
  UPDATE public.match_queue SET heartbeat_at = now() WHERE user_id = _user;
  SELECT q.user_id INTO _opp FROM public.match_queue q
    WHERE q.mode = _mode AND q.user_id <> _user AND q.heartbeat_at > now() - interval '8 seconds'
      AND abs(q.mmr - _self.mmr) <= 200 + 25 * extract(epoch FROM now() - LEAST(q.created_at, _self.created_at))
    ORDER BY abs(q.mmr - _self.mmr), q.created_at
    FOR UPDATE SKIP LOCKED
    LIMIT 1;
  IF _opp IS NULL THEN
    RETURN NULL;
  END IF;
  DELETE FROM public.match_queue WHERE user_id IN (_user, _opp);
  IF random() < 0.5 THEN
    INSERT INTO public.games (mode, vs_ai, black_id, white_id, turn_started_at)
      VALUES (_mode, false, _user, _opp, now() + interval '3 seconds') RETURNING id INTO _game;
  ELSE
    INSERT INTO public.games (mode, vs_ai, black_id, white_id, turn_started_at)
      VALUES (_mode, false, _opp, _user, now() + interval '3 seconds') RETURNING id INTO _game;
  END IF;
  RETURN _game;
END;
$$;
REVOKE EXECUTE ON FUNCTION public.try_match(uuid, text) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.try_match(uuid, text) TO service_role;
