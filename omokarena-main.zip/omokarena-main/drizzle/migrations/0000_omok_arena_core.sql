-- Profiles
CREATE TABLE public.profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  nickname text NOT NULL,
  rating integer NOT NULL DEFAULT 0,
  placement_games integer NOT NULL DEFAULT 0,
  placement_score integer NOT NULL DEFAULT 0,
  bp integer NOT NULL DEFAULT 0,
  shields integer NOT NULL DEFAULT 0,
  wins integer NOT NULL DEFAULT 0,
  losses integer NOT NULL DEFAULT 0,
  ranked_wins integer NOT NULL DEFAULT 0,
  ranked_losses integer NOT NULL DEFAULT 0,
  chat_warnings integer NOT NULL DEFAULT 0,
  muted_until timestamptz,
  last_seen_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX profiles_nickname_lower_idx ON public.profiles (lower(nickname));
CREATE INDEX profiles_rating_idx ON public.profiles (rating DESC) WHERE placement_games >= 5;

GRANT SELECT ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Signed-in users can view profiles" ON public.profiles
  FOR SELECT TO authenticated USING (true);

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.profiles (id, nickname)
  VALUES (NEW.id, COALESCE(NULLIF(NEW.raw_user_meta_data->>'nickname', ''), 'player_' || substr(NEW.id::text, 1, 6)));
  RETURN NEW;
END;
$$;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Games
CREATE TABLE public.games (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  mode text NOT NULL CHECK (mode IN ('ranked','normal')),
  vs_ai boolean NOT NULL DEFAULT false,
  ai_level text,
  black_id uuid,
  white_id uuid,
  moves jsonb NOT NULL DEFAULT '[]'::jsonb,
  move_count integer NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active','finished')),
  winner text,
  end_reason text,
  result jsonb,
  turn_started_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now(),
  finished_at timestamptz
);
CREATE INDEX games_black_idx ON public.games (black_id, status);
CREATE INDEX games_white_idx ON public.games (white_id, status);

GRANT SELECT ON public.games TO authenticated;
GRANT ALL ON public.games TO service_role;
ALTER TABLE public.games ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Players can view their games" ON public.games
  FOR SELECT TO authenticated USING (auth.uid() = black_id OR auth.uid() = white_id);

-- Matchmaking queue
CREATE TABLE public.match_queue (
  user_id uuid PRIMARY KEY,
  mode text NOT NULL CHECK (mode IN ('ranked','normal')),
  created_at timestamptz NOT NULL DEFAULT now(),
  heartbeat_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.match_queue TO authenticated;
GRANT ALL ON public.match_queue TO service_role;
ALTER TABLE public.match_queue ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can view own queue entry" ON public.match_queue
  FOR SELECT TO authenticated USING (auth.uid() = user_id);

CREATE OR REPLACE FUNCTION public.try_match(_user uuid, _mode text)
RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  _self uuid;
  _opp uuid;
  _game uuid;
BEGIN
  SELECT user_id INTO _self FROM public.match_queue WHERE user_id = _user AND mode = _mode FOR UPDATE;
  IF _self IS NULL THEN
    RETURN NULL;
  END IF;
  UPDATE public.match_queue SET heartbeat_at = now() WHERE user_id = _user;
  SELECT user_id INTO _opp FROM public.match_queue
    WHERE mode = _mode AND user_id <> _user AND heartbeat_at > now() - interval '8 seconds'
    ORDER BY created_at
    FOR UPDATE SKIP LOCKED
    LIMIT 1;
  IF _opp IS NULL THEN
    RETURN NULL;
  END IF;
  DELETE FROM public.match_queue WHERE user_id IN (_user, _opp);
  IF random() < 0.5 THEN
    INSERT INTO public.games (mode, vs_ai, black_id, white_id, turn_started_at)
      VALUES (_mode, false, _user, _opp, now() + interval '3 seconds') RETURNING id INTO _game;
  ELSE
    INSERT INTO public.games (mode, vs_ai, black_id, white_id, turn_started_at)
      VALUES (_mode, false, _opp, _user, now() + interval '3 seconds') RETURNING id INTO _game;
  END IF;
  RETURN _game;
END;
$$;
REVOKE EXECUTE ON FUNCTION public.try_match(uuid, text) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.try_match(uuid, text) TO service_role;

-- Chat messages
CREATE TABLE public.game_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  game_id uuid NOT NULL REFERENCES public.games(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  content text NOT NULL,
  censored boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX game_messages_game_idx ON public.game_messages (game_id, created_at);
GRANT SELECT ON public.game_messages TO authenticated;
GRANT ALL ON public.game_messages TO service_role;
ALTER TABLE public.game_messages ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Players can read their game chat" ON public.game_messages
  FOR SELECT TO authenticated USING (
    EXISTS (SELECT 1 FROM public.games g WHERE g.id = game_id AND (g.black_id = auth.uid() OR g.white_id = auth.uid()))
  );

-- Friendships
CREATE TABLE public.friendships (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  requester_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  addressee_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','accepted')),
  created_at timestamptz NOT NULL DEFAULT now(),
  CHECK (requester_id <> addressee_id)
);
CREATE UNIQUE INDEX friendships_pair_idx ON public.friendships (LEAST(requester_id, addressee_id), GREATEST(requester_id, addressee_id));
GRANT SELECT, INSERT, UPDATE, DELETE ON public.friendships TO authenticated;
GRANT ALL ON public.friendships TO service_role;
ALTER TABLE public.friendships ENABLE ROW LEVEL SECURITY;
CREATE POLICY "View own friendships" ON public.friendships
  FOR SELECT TO authenticated USING (auth.uid() = requester_id OR auth.uid() = addressee_id);
CREATE POLICY "Send friend requests" ON public.friendships
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = requester_id AND status = 'pending');
CREATE POLICY "Accept incoming requests" ON public.friendships
  FOR UPDATE TO authenticated USING (auth.uid() = addressee_id) WITH CHECK (auth.uid() = addressee_id AND status = 'accepted');
CREATE POLICY "Remove own friendships" ON public.friendships
  FOR DELETE TO authenticated USING (auth.uid() = requester_id OR auth.uid() = addressee_id);

-- Realtime
ALTER PUBLICATION supabase_realtime ADD TABLE public.games;
ALTER PUBLICATION supabase_realtime ADD TABLE public.game_messages;
ALTER PUBLICATION supabase_realtime ADD TABLE public.friendships;
