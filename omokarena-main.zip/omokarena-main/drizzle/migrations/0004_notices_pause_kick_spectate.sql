-- Pause + kick + friendly mode
ALTER TABLE public.games ADD COLUMN paused_until timestamptz;
ALTER TABLE public.profiles ADD COLUMN kicked_until timestamptz;
ALTER TABLE public.game_invites ADD COLUMN mode text NOT NULL DEFAULT 'normal' CHECK (mode IN ('ranked','normal'));

-- Admins can spectate any game and read its chat
CREATE POLICY "Admins can view all games" ON public.games
  FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins can read all game chat" ON public.game_messages
  FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'admin'));

-- Live notices: announcements (to everyone), whispers and kicks (to one player)
CREATE TABLE public.notices (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  kind text NOT NULL CHECK (kind IN ('call','whisper','kick')),
  from_id uuid,
  from_nickname text,
  to_id uuid,
  to_nickname text,
  content text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX notices_to_idx ON public.notices (to_id, created_at DESC);
CREATE INDEX notices_from_idx ON public.notices (from_id, created_at DESC);
GRANT SELECT ON public.notices TO authenticated;
GRANT ALL ON public.notices TO service_role;
ALTER TABLE public.notices ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Players see public notices and their own" ON public.notices
  FOR SELECT TO authenticated USING (to_id IS NULL OR to_id = auth.uid() OR from_id = auth.uid());
ALTER PUBLICATION supabase_realtime ADD TABLE public.notices;

-- Developer account: admin + developer role and signature cosmetics
CREATE OR REPLACE FUNCTION public.grant_developer_perks(_user uuid)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.user_roles (user_id, role) VALUES (_user, 'admin') ON CONFLICT DO NOTHING;
  INSERT INTO public.user_roles (user_id, role) VALUES (_user, 'developer') ON CONFLICT DO NOTHING;
  INSERT INTO public.profile_titles (user_id, title) VALUES (_user, '개발자') ON CONFLICT DO NOTHING;
  INSERT INTO public.profile_colors (user_id, color) VALUES (_user, 'rainbow') ON CONFLICT DO NOTHING;
  UPDATE public.profiles SET equipped_title = COALESCE(equipped_title, '개발자'), equipped_color = COALESCE(equipped_color, 'rainbow') WHERE id = _user;
END;
$$;
REVOKE EXECUTE ON FUNCTION public.grant_developer_perks(uuid) FROM PUBLIC, anon, authenticated;

SELECT public.grant_developer_perks(id) FROM public.profiles WHERE nickname = '러키';