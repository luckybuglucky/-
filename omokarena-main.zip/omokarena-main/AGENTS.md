<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

## Architecture rules

- Game logic is server-authoritative: moves, AI replies, timeouts, results, RP/BP and shop purchases run in `src/lib/omok/game.functions.ts` with the admin client; clients only read games/profiles via RLS. Why: prevents cheating on rank.
- Pure rules live in `src/lib/omok/{rules,ai,rank,profanity}.ts` and are covered by `src/test/omok-rules.test.ts`. Why: shared by server and UI, testable without a backend.
- Ratings are stored as one cumulative `profiles.rating`; tier/division/RP are derived by `rankFromRating`. Why: a single number keeps leaderboard ordering and promotions consistent.
- Accounts are nickname + password; the auth email is a deterministic hash of the lowercased nickname (`nicknameToEmail`) and auto-confirm is on. Why: the user wanted nickname-only sign-up.
- Matchmaking uses the `match_queue` table plus the `try_match` SQL function (row locks) which also creates the game atomically.
- Live updates use Realtime on `games`, `game_messages`; there is no server-side timer — clients claim timeouts and stale games are resolved on `getMe`.
- Music and sound effects are synthesized with Web Audio in `src/lib/omok/audio.ts` (no audio files). Why: zero download, low latency.
- Admin = `user_roles` row with role `admin` (checked via `has_role` through the caller's own client); the developer nickname gets admin + perks from the signup trigger (`grant_developer_perks`). Never derive admin from the nickname in app code.
- Titles and nickname colors are owned rows (`profile_titles`, `profile_colors`); the equipped ones live on `profiles` and are only written by server functions in `src/lib/omok/social.functions.ts`.
- Hidden `profiles.mmr` drives matchmaking (`match_queue.mmr` + widening window in `try_match`); visible `rating` drives tiers.
- Friendly matches are `games.friendly = true` created from `game_invites`; `finishGame` skips all rewards/stats for them.
- Redeem codes are a constant map in `src/lib/omok/cosmetics.ts`; per-account use is enforced by the `redeemed_codes` primary key.
